Public Class Id
   Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'UserControl1 overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
   Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
   Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
   Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
   Friend WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
   Friend WithEvents SqlDataAdapter1 As System.Data.SqlClient.SqlDataAdapter
   Friend WithEvents txtId As System.Windows.Forms.TextBox
   Friend WithEvents DstUser1 As UserManId.dstUser
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
      Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection()
      Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand()
      Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand()
      Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand()
      Me.SqlDataAdapter1 = New System.Data.SqlClient.SqlDataAdapter()
      Me.txtId = New System.Windows.Forms.TextBox()
      Me.DstUser1 = New UserManId.dstUser()
      CType(Me.DstUser1, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'SqlSelectCommand1
      '
      Me.SqlSelectCommand1.CommandText = "SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser"
      Me.SqlSelectCommand1.Connection = Me.SqlConnection1
      '
      'SqlConnection1
      '
      Me.SqlConnection1.ConnectionString = "data source=server;initial catalog=UserMan;password=userman;persist security info" & _
      "=True;user id=UserMan;workstation id=WS1;packet size=4096"
      '
      'SqlInsertCommand1
      '
      Me.SqlInsertCommand1.CommandText = "INSERT INTO tblUser(ADName, ADSID, FirstName, LastName, LoginName, Password) VALU" & _
      "ES (@ADName, @ADSID, @FirstName, @LastName, @LoginName, @Password); SELECT Id, A" & _
      "DName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser WHERE (Id = " & _
      "@@IDENTITY)"
      Me.SqlInsertCommand1.Connection = Me.SqlConnection1
      Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ADName", System.Data.SqlDbType.VarChar, 100, "ADName"))
      Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ADSID", System.Data.SqlDbType.VarChar, 50, "ADSID"))
      Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@FirstName", System.Data.SqlDbType.VarChar, 50, "FirstName"))
      Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LastName", System.Data.SqlDbType.VarChar, 50, "LastName"))
      Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LoginName", System.Data.SqlDbType.VarChar, 50, "LoginName"))
      Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Password", System.Data.SqlDbType.VarChar, 50, "Password"))
      '
      'SqlUpdateCommand1
      '
      Me.SqlUpdateCommand1.CommandText = "UPDATE tblUser SET ADName = @ADName, ADSID = @ADSID, FirstName = @FirstName, Last" & _
      "Name = @LastName, LoginName = @LoginName, Password = @Password WHERE (Id = @Orig" & _
      "inal_Id) AND (ADName = @Original_ADName OR @Original_ADName IS NULL AND ADName I" & _
      "S NULL) AND (ADSID = @Original_ADSID OR @Original_ADSID IS NULL AND ADSID IS NUL" & _
      "L) AND (FirstName = @Original_FirstName OR @Original_FirstName IS NULL AND First" & _
      "Name IS NULL) AND (LastName = @Original_LastName OR @Original_LastName IS NULL A" & _
      "ND LastName IS NULL) AND (LoginName = @Original_LoginName) AND (Password = @Orig" & _
      "inal_Password); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Passwo" & _
      "rd FROM tblUser WHERE (Id = @Id)"
      Me.SqlUpdateCommand1.Connection = Me.SqlConnection1
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ADName", System.Data.SqlDbType.VarChar, 100, "ADName"))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ADSID", System.Data.SqlDbType.VarChar, 50, "ADSID"))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@FirstName", System.Data.SqlDbType.VarChar, 50, "FirstName"))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LastName", System.Data.SqlDbType.VarChar, 50, "LastName"))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LoginName", System.Data.SqlDbType.VarChar, 50, "LoginName"))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Password", System.Data.SqlDbType.VarChar, 50, "Password"))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ADName", System.Data.SqlDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ADSID", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_FirstName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_LastName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_LoginName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Password", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id"))
      '
      'SqlDeleteCommand1
      '
      Me.SqlDeleteCommand1.CommandText = "DELETE FROM tblUser WHERE (Id = @Original_Id) AND (ADName = @Original_ADName OR @" & _
      "Original_ADName IS NULL AND ADName IS NULL) AND (ADSID = @Original_ADSID OR @Ori" & _
      "ginal_ADSID IS NULL AND ADSID IS NULL) AND (FirstName = @Original_FirstName OR @" & _
      "Original_FirstName IS NULL AND FirstName IS NULL) AND (LastName = @Original_Last" & _
      "Name OR @Original_LastName IS NULL AND LastName IS NULL) AND (LoginName = @Origi" & _
      "nal_LoginName) AND (Password = @Original_Password)"
      Me.SqlDeleteCommand1.Connection = Me.SqlConnection1
      Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ADName", System.Data.SqlDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ADSID", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_FirstName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_LastName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_LoginName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
      Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Password", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
      '
      'SqlDataAdapter1
      '
      Me.SqlDataAdapter1.DeleteCommand = Me.SqlDeleteCommand1
      Me.SqlDataAdapter1.InsertCommand = Me.SqlInsertCommand1
      Me.SqlDataAdapter1.SelectCommand = Me.SqlSelectCommand1
      Me.SqlDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "tblUser", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Id", "Id"), New System.Data.Common.DataColumnMapping("ADName", "ADName"), New System.Data.Common.DataColumnMapping("ADSID", "ADSID"), New System.Data.Common.DataColumnMapping("FirstName", "FirstName"), New System.Data.Common.DataColumnMapping("LastName", "LastName"), New System.Data.Common.DataColumnMapping("LoginName", "LoginName"), New System.Data.Common.DataColumnMapping("Password", "Password")})})
      Me.SqlDataAdapter1.UpdateCommand = Me.SqlUpdateCommand1
      '
      'txtId
      '
      Me.txtId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DstUser1, "tblUser.Id"))
      Me.txtId.Location = New System.Drawing.Point(25, 95)
      Me.txtId.Name = "txtId"
      Me.txtId.TabIndex = 0
      Me.txtId.Text = ""
      '
      'DstUser1
      '
      Me.DstUser1.DataSetName = "dstUser"
      Me.DstUser1.Locale = New System.Globalization.CultureInfo("da-DK")
      Me.DstUser1.Namespace = "http://www.tempuri.org/dstUser.xsd"
      '
      'Id
      '
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtId})
      Me.Name = "Id"
      CType(Me.DstUser1, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub UserControl1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
      SqlDataAdapter1.Fill(DstUser1)
   End Sub
End Class