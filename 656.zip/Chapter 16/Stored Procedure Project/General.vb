Option Strict On
Option Explicit On 

#Const Oracle = 0
#Const DB2 = 0
#Const SQLSERVER = 1
' Make sure you enable the correct data source, by setting it to 1

Imports System.Data.SqlClient
imports System.Data.OleDb

Module General
#If SQLSERVER Then
	' This connection string os for connecting to SQL Server
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
#ElseIf Oracle Then
   ' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN"
#ElseIf DB2 Then
   Private Const STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Listing 16-1
   Public Sub ExecuteSimpleSP()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim lngNumUsers As Long

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New SqlCommand("SimpleStoredProcedure", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure

      lngNumUsers = CLng(cmmUser.ExecuteScalar)
      MsgBox(lngNumUsers.ToString)
   End Sub

   ' Listing 16-2-1
   Public Sub ExecuteSimpleRowReturningSP()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim drdUser As SqlDataReader

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New SqlCommand("uspGetUsers", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure

      ' Retrieve all user rows
      drdUser = cmmUser.ExecuteReader()
   End Sub

   ' Listing 16-2-2
   Public Sub ExecuteSimpleRowReturningSPInDataTable()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUserMan As SqlDataAdapter
      Dim dtbUser As New DataTable()

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New SqlCommand("uspGetUsers", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure

      dadUserMan = New SqlDataAdapter("uspGetUsers", cnnUserMan)
      dadUserMan.SelectCommand = cmmUser

      ' Retrieve all user rows
      dadUserMan.Fill(dtbUser)
   End Sub

   ' Listing 16-3
   Public Sub GetUsersByLastName()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim drdUser As SqlDataReader
      Dim prmLastName As SqlParameter

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New SqlCommand("uspGetUsersByLastName", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate, initialize and add parameter to command
      prmLastName = cmmUser.Parameters.Add("@strLastName", _
         SqlDbType.VarChar, 50)
      ' Indicate this is an input parameter
      prmLastName.Direction = ParameterDirection.Input
      ' Set the value of the parameter
      prmLastName.Value = "Doe"

      ' Return all users with a last name of Doe
      drdUser = cmmUser.ExecuteReader()
   End Sub

   ' Listing 16-4
   Public Sub GetUsersAndRights()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim drdUser As SqlDataReader
      Dim prmNumRows As SqlParameter

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New SqlCommand("uspGetUsersAndRights", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate, initialize and add parameter to command
      prmNumRows = cmmUser.Parameters.Add("@lngNumRows", SqlDbType.Int)
      ' Indicate this is an output parameter
      prmNumRows.Direction = ParameterDirection.Output
      ' Get first batch of rows (users)
      drdUser = cmmUser.ExecuteReader()

      ' Display the last name of all user rows
      Do While drdUser.Read()
         MsgBox(drdUser("LastName").ToString)
      Loop

      ' Get next batch of rows (user rights)
      If drdUser.NextResult() Then
         ' Display the id of all rights
         Do While drdUser.Read()
            MsgBox(drdUser("RightsId").ToString)
         Loop
      End If
   End Sub

   ' Listing 16-5
   Public Sub GetRETURN_VALUE()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim prmNumRows As SqlParameter
      Dim lngResult As Long

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New SqlCommand("uspGetRETURN_VALUE", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate, initialize and add parameter to command
      prmNumRows = cmmUser.Parameters.Add("@RETURN_VALUE", _
         SqlDbType.Int)
      ' Indicate this is a return value parameter
      prmNumRows.Direction = ParameterDirection.ReturnValue
      ' Get RETURN_VALUE
      lngResult = CLng(cmmUser.ExecuteScalar())
   End Sub

   ' Listing 16-7
   Public Sub ExecuteSimpleOracleSF()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim prmNumRows As OleDbParameter
      Dim objReturnValue As Object

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New OleDbCommand("SimpleStoredFunction", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate output parameter and add to parameter 
      ' collection of command object
      prmNumRows = cmmUser.CreateParameter()
      prmNumRows.Direction = ParameterDirection.ReturnValue
      prmNumRows.DbType = DbType.Int64
      prmNumRows.Precision = 38
      prmNumRows.Size = 38
      cmmUser.Parameters.Add(prmNumRows)

      ' Retrieve and display value
      objReturnValue = cmmUser.ExecuteScalar()
      MsgBox(cmmUser.Parameters(0).Value.ToString())
   End Sub

   ' Listing 16-9
   Public Sub ExecuteSimpleOracleSP()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim prmNumRows As OleDbParameter
      Dim objReturnValue As Object

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New OleDbCommand("SimpleStoredProcedure", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate output parameter and add to parameter 
      ' collection of command object
      prmNumRows = cmmUser.CreateParameter()
      prmNumRows.Direction = ParameterDirection.Output
      prmNumRows.DbType = DbType.Int64
      prmNumRows.Precision = 38
      prmNumRows.Size = 38
      cmmUser.Parameters.Add(prmNumRows)

      ' Retrieve and display value
      objReturnValue = cmmUser.ExecuteScalar()
      MsgBox(cmmUser.Parameters(0).Value.ToString())
   End Sub

   ' Listing 16-11
   Public Sub OracleGetUsersByLastName()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim prmLastName As OleDbParameter
      Dim drdUser As OleDbDataReader

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New OleDbCommand("USPGETUSERSBYLASTNAME", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate, initialize and add parameter to command
      prmLastName = cmmUser.Parameters.Add("strLastName", OleDbType.VarChar, 50)
      ' Indicate this is an input parameter
      prmLastName.Direction = ParameterDirection.Input
      ' Set the type and value of the parameter
      prmLastName.Value = "Doe"

      ' Retrieve rows
      drdUser = cmmUser.ExecuteReader()
      ' Loop through the returned rows
      While drdUser.Read()
         ' Display the last name of all user rows
         MsgBox(drdUser("LastName").ToString())
      End While
   End Sub

   ' Listing 16-13
   Public Sub ExecuteSimpleDB2SPWithReturnValue()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim prmNumRows As OleDbParameter
      Dim objReturnValue As Object

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New OleDbCommand("SimpleStoredFunc", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate output parameter and add to parameter 
      ' collection of command object
      prmNumRows = cmmUser.CreateParameter()
      prmNumRows.Direction = ParameterDirection.ReturnValue
      prmNumRows.DbType = DbType.Int32
      cmmUser.Parameters.Add(prmNumRows)

      ' Retrieve and display value
      objReturnValue = cmmUser.ExecuteScalar()
      MsgBox(cmmUser.Parameters(0).Value.ToString())
   End Sub

   ' Listing 16-15
   Public Sub ExecuteSimpleDB2SP()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim prmLastName As OleDbParameter
      Dim objReturnValue As Object

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New OleDbCommand("SIMPLESTOREDPROC", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate output parameter and add to parameter 
      ' collection of command object
      prmLastName = cmmUser.CreateParameter()
      prmLastName.Direction = ParameterDirection.Output
      prmLastName.DbType = DbType.String
      prmLastName.Size = 50
      cmmUser.Parameters.Add(prmLastName)

      ' Retrieve and display value
      objReturnValue = cmmUser.ExecuteScalar()
      MsgBox(cmmUser.Parameters(0).Value.ToString())
   End Sub

   ' Listing 16-17
   Public Sub DB2GetUsersByLastName()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim prmLastName As OleDbParameter
      Dim drdUser As OleDbDataReader

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New OleDbCommand("uspGetUsersByLastName", cnnUserMan)
      cmmUser.CommandType = CommandType.StoredProcedure
      ' Instantiate, initialize and add parameter to command
      prmLastName = cmmUser.Parameters.Add("strLastName", OleDbType.VarChar, 50)
      ' Indicate this is an input parameter
      prmLastName.Direction = ParameterDirection.Input
      ' Set the type and value of the parameter
      prmLastName.Value = "Doe"

      ' Retrieve rows
      drdUser = cmmUser.ExecuteReader()
      ' Loop through the returned rows
      While drdUser.Read()
         ' Display the last name of all user rows
         MsgBox(drdUser("LastName").ToString())
      End While
   End Sub
End Module