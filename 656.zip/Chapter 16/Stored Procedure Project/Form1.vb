Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnExecuteSimpleSP As System.Windows.Forms.Button
   Friend WithEvents btnExecuteSimpleRowReturningSP As System.Windows.Forms.Button
   Friend WithEvents btnGetUsersByLastName As System.Windows.Forms.Button
   Friend WithEvents btnGetUsersAndRights As System.Windows.Forms.Button
   Friend WithEvents btnGetRETURNValue As System.Windows.Forms.Button
   Friend WithEvents btnExecuteSimpleOracleSF As System.Windows.Forms.Button
   Friend WithEvents btnExecuteSimpleOracleSP As System.Windows.Forms.Button
   Friend WithEvents btnOracleGetUsersByLastName As System.Windows.Forms.Button
   Friend WithEvents btnExecuteSimpleDB2SP As System.Windows.Forms.Button
   Friend WithEvents btnExecuteSimpleDB2SF As System.Windows.Forms.Button
   Friend WithEvents btnDB2GetUsersByLastName As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnExecuteSimpleSP = New System.Windows.Forms.Button()
      Me.btnExecuteSimpleRowReturningSP = New System.Windows.Forms.Button()
      Me.btnGetUsersByLastName = New System.Windows.Forms.Button()
      Me.btnGetUsersAndRights = New System.Windows.Forms.Button()
      Me.btnGetRETURNValue = New System.Windows.Forms.Button()
      Me.btnExecuteSimpleOracleSF = New System.Windows.Forms.Button()
      Me.btnExecuteSimpleOracleSP = New System.Windows.Forms.Button()
      Me.btnOracleGetUsersByLastName = New System.Windows.Forms.Button()
      Me.btnDB2GetUsersByLastName = New System.Windows.Forms.Button()
      Me.btnExecuteSimpleDB2SP = New System.Windows.Forms.Button()
      Me.btnExecuteSimpleDB2SF = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnExecuteSimpleSP
      '
      Me.btnExecuteSimpleSP.Location = New System.Drawing.Point(12, 8)
      Me.btnExecuteSimpleSP.Name = "btnExecuteSimpleSP"
      Me.btnExecuteSimpleSP.Size = New System.Drawing.Size(270, 23)
      Me.btnExecuteSimpleSP.TabIndex = 0
      Me.btnExecuteSimpleSP.Text = "Execute Simple Stored Procedure"
      '
      'btnExecuteSimpleRowReturningSP
      '
      Me.btnExecuteSimpleRowReturningSP.Location = New System.Drawing.Point(12, 36)
      Me.btnExecuteSimpleRowReturningSP.Name = "btnExecuteSimpleRowReturningSP"
      Me.btnExecuteSimpleRowReturningSP.Size = New System.Drawing.Size(270, 23)
      Me.btnExecuteSimpleRowReturningSP.TabIndex = 1
      Me.btnExecuteSimpleRowReturningSP.Text = "Execute Simple Row Returning Stored Procedure"
      '
      'btnGetUsersByLastName
      '
      Me.btnGetUsersByLastName.Location = New System.Drawing.Point(12, 64)
      Me.btnGetUsersByLastName.Name = "btnGetUsersByLastName"
      Me.btnGetUsersByLastName.Size = New System.Drawing.Size(270, 23)
      Me.btnGetUsersByLastName.TabIndex = 2
      Me.btnGetUsersByLastName.Text = "Get Users By Last Name"
      '
      'btnGetUsersAndRights
      '
      Me.btnGetUsersAndRights.Location = New System.Drawing.Point(12, 92)
      Me.btnGetUsersAndRights.Name = "btnGetUsersAndRights"
      Me.btnGetUsersAndRights.Size = New System.Drawing.Size(270, 23)
      Me.btnGetUsersAndRights.TabIndex = 3
      Me.btnGetUsersAndRights.Text = "Get Users and Rights"
      '
      'btnGetRETURNValue
      '
      Me.btnGetRETURNValue.Location = New System.Drawing.Point(12, 120)
      Me.btnGetRETURNValue.Name = "btnGetRETURNValue"
      Me.btnGetRETURNValue.Size = New System.Drawing.Size(270, 23)
      Me.btnGetRETURNValue.TabIndex = 4
      Me.btnGetRETURNValue.Text = "Get RETURN Value"
      '
      'btnExecuteSimpleOracleSF
      '
      Me.btnExecuteSimpleOracleSF.Location = New System.Drawing.Point(11, 148)
      Me.btnExecuteSimpleOracleSF.Name = "btnExecuteSimpleOracleSF"
      Me.btnExecuteSimpleOracleSF.Size = New System.Drawing.Size(270, 23)
      Me.btnExecuteSimpleOracleSF.TabIndex = 5
      Me.btnExecuteSimpleOracleSF.Text = "Execute Simple Oracle Stored Function"
      '
      'btnExecuteSimpleOracleSP
      '
      Me.btnExecuteSimpleOracleSP.Location = New System.Drawing.Point(11, 176)
      Me.btnExecuteSimpleOracleSP.Name = "btnExecuteSimpleOracleSP"
      Me.btnExecuteSimpleOracleSP.Size = New System.Drawing.Size(270, 23)
      Me.btnExecuteSimpleOracleSP.TabIndex = 6
      Me.btnExecuteSimpleOracleSP.Text = "Execute Simple Oracle Stored Procedure"
      '
      'btnOracleGetUsersByLastName
      '
      Me.btnOracleGetUsersByLastName.Location = New System.Drawing.Point(11, 204)
      Me.btnOracleGetUsersByLastName.Name = "btnOracleGetUsersByLastName"
      Me.btnOracleGetUsersByLastName.Size = New System.Drawing.Size(270, 23)
      Me.btnOracleGetUsersByLastName.TabIndex = 7
      Me.btnOracleGetUsersByLastName.Text = "Get Users By Last Name (Oracle)"
      '
      'btnDB2GetUsersByLastName
      '
      Me.btnDB2GetUsersByLastName.Location = New System.Drawing.Point(11, 288)
      Me.btnDB2GetUsersByLastName.Name = "btnDB2GetUsersByLastName"
      Me.btnDB2GetUsersByLastName.Size = New System.Drawing.Size(270, 23)
      Me.btnDB2GetUsersByLastName.TabIndex = 10
      Me.btnDB2GetUsersByLastName.Text = "Get Users By Last Name (DB2)"
      '
      'btnExecuteSimpleDB2SP
      '
      Me.btnExecuteSimpleDB2SP.Location = New System.Drawing.Point(11, 260)
      Me.btnExecuteSimpleDB2SP.Name = "btnExecuteSimpleDB2SP"
      Me.btnExecuteSimpleDB2SP.Size = New System.Drawing.Size(270, 23)
      Me.btnExecuteSimpleDB2SP.TabIndex = 9
      Me.btnExecuteSimpleDB2SP.Text = "Execute Simple DB2 Stored Procedure"
      '
      'btnExecuteSimpleDB2SF
      '
      Me.btnExecuteSimpleDB2SF.Location = New System.Drawing.Point(11, 232)
      Me.btnExecuteSimpleDB2SF.Name = "btnExecuteSimpleDB2SF"
      Me.btnExecuteSimpleDB2SF.Size = New System.Drawing.Size(270, 23)
      Me.btnExecuteSimpleDB2SF.TabIndex = 8
      Me.btnExecuteSimpleDB2SF.Text = "Execute Simple DB2 SP with Return Value"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(290, 319)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnExecuteSimpleDB2SF, Me.btnDB2GetUsersByLastName, Me.btnExecuteSimpleDB2SP, Me.btnOracleGetUsersByLastName, Me.btnExecuteSimpleOracleSP, Me.btnExecuteSimpleOracleSF, Me.btnGetRETURNValue, Me.btnGetUsersAndRights, Me.btnGetUsersByLastName, Me.btnExecuteSimpleRowReturningSP, Me.btnExecuteSimpleSP})
      Me.Name = "Form1"
      Me.Text = "Stored Procedure Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnExecuteSimpleSP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleSP.Click
      ExecuteSimpleSP()
   End Sub

   Private Sub btnExecuteSimpleRowReturningSP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleRowReturningSP.Click
      ExecuteSimpleRowReturningSP()
      'ExecuteSimpleRowReturningSPInDataTable()
   End Sub

   Private Sub btnGetUsersByLastName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetUsersByLastName.Click
      GetUsersByLastName()
   End Sub

   Private Sub btnGetUsersAndRights_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetUsersAndRights.Click
      GetUsersAndRights()
   End Sub

   Private Sub btnGetRETURNValue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetRETURNValue.Click
      GetRETURN_VALUE()
   End Sub

   Private Sub btnExecuteSimpleOracleSF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleOracleSF.Click
      ExecuteSimpleOracleSF()
   End Sub

   Private Sub btnExecuteSimpleOracleSP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleOracleSP.Click
      ExecuteSimpleOracleSP()
   End Sub

   Private Sub btnOracleGetUsersByLastName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOracleGetUsersByLastName.Click
      OracleGetUsersByLastName()
   End Sub

   Private Sub btnExecuteSimpleDB2SP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleDB2SP.Click
      ExecuteSimpleDB2SP()
   End Sub

   Private Sub btnExecuteSimpleDB2SF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteSimpleDB2SF.Click
      ExecuteSimpleDB2SPWithReturnValue()
   End Sub

   Private Sub btnDB2GetUsersByLastName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDB2GetUsersByLastName.Click
      DB2GetUsersByLastName()
   End Sub
End Class