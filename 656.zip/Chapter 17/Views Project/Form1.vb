Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnRetrieveRowsFromView As System.Windows.Forms.Button
   Friend WithEvents btnManipulateDataInAViewBasedOnSingleTable As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnRetrieveRowsFromView = New System.Windows.Forms.Button()
      Me.btnManipulateDataInAViewBasedOnSingleTable = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnRetrieveRowsFromView
      '
      Me.btnRetrieveRowsFromView.Location = New System.Drawing.Point(9, 16)
      Me.btnRetrieveRowsFromView.Name = "btnRetrieveRowsFromView"
      Me.btnRetrieveRowsFromView.Size = New System.Drawing.Size(275, 23)
      Me.btnRetrieveRowsFromView.TabIndex = 0
      Me.btnRetrieveRowsFromView.Text = "Retrieve Rows from a View"
      '
      'btnManipulateDataInAViewBasedOnSingleTable
      '
      Me.btnManipulateDataInAViewBasedOnSingleTable.Location = New System.Drawing.Point(8, 44)
      Me.btnManipulateDataInAViewBasedOnSingleTable.Name = "btnManipulateDataInAViewBasedOnSingleTable"
      Me.btnManipulateDataInAViewBasedOnSingleTable.Size = New System.Drawing.Size(275, 23)
      Me.btnManipulateDataInAViewBasedOnSingleTable.TabIndex = 1
      Me.btnManipulateDataInAViewBasedOnSingleTable.Text = "Manipulate Data In View"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(292, 266)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnManipulateDataInAViewBasedOnSingleTable, Me.btnRetrieveRowsFromView})
      Me.Name = "Form1"
      Me.Text = "Views Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnRetrieveRowsFromView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieveRowsFromView.Click
      RetrieveRowsFromView()
   End Sub

   Private Sub btnManipulateDataInAViewBasedOnSingleTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManipulateDataInAViewBasedOnSingleTable.Click
      ManipulateDataInAViewBasedOnSingleTable()
   End Sub
End Class
