UserMan Example Code

This document describes how to set up the UserMan database and various
other elements in order to run the example code included in the
download on different data sources. All data sources tested with the
example code have been installed on Windows 2000 and Windows XP
machines.
  You need to be aware that the example code in the various projects
differs slightly from the listings in the book.

Unzipping The UserMan.zip file
------------------------------
You need a utility that can extract files from a zipped archive
(*.zip) in order to access the files in the archive. WinZip is one
such utility and if you don't have it, you can download a shareware
version at this address: http://www.winzip.com/ddchomea.htm.
  Unzip the files with folder information, meaning that the files that
are in a subfolder in the archive must be extracted to the very same
subfolder on your disk. One such file is the "UserMan Database
Project.dbp" file which is located in the UserMan Database Project
folder. So make sure that you zip file viewer creates the folders at
extraction time. If you're using WinZip this means making sure that
the "Use folder names" check box in the Extract dialog box is checked
when you extract the files.

Setting Up the UserMan Database on SQL Server
---------------------------------------------
You can create the UserMan database by running the "Create UserMan
Database.sql" script file. This script will create the database,
tables, triggers, views and stored procedures used by the example
code. The script also inserts example data in the tables. Here are two
ways of creating the database using the script:
    1    You can choose to run this script from the SQL Server Enterprise
      Manager or the Query Analyzer. Please consult the Books Online help
      utility for information on how to do this.
    2    You can also run the script from within the UserMan Database
      Project.
      1    Open the project up in the VS .NET IDE.
      2    The script file is located in the Create Scripts folder shown in
        the Solution Explorer. Expand the Create Scripts folder.
      3    Set the database reference or the SQL Server on which you want to
        create the database. This is done by right-clicking on the project in
        the Solution Explorer and selecting Set Default Reference from the pop-
        up menu. This brings up the Set Default Reference dialog box, where
        you can click the Add Reference button to add a reference to your SQL
        Server. Please note that you need to create the reference as a user
        who has the rights to create a new database, such as sa.
      4    Right-click on the Create UserMan Database.sql file in the Create
        Scripts folder, and select Run from the pop-up menu.

Setting Up the UserMan Database on MySQL(1)
-------------------------------------------
You can create the UserMan database by running the "Create UserMan
Database-MySQL.sql" script file. This script will create the database
and the tables used by the example code. Triggers, views, and stored
procedures are not supported by version 3.23.51 or 4.0.1-alpha of
MySQL. The script inserts example data in the tables.
  Here is how you create the database using the script:
    *    From a Command Prompt in the MySQL\Bin folder (typically C:\
      MySQL\Bin) you run this command: mysql < "Path\Create UserMan Database-
      MySQL.sql", where Path\ is the full path to where you've placed the
      script file.

Setting Up the UserMan Database on Oracle(2)
--------------------------------------------
You can create the UserMan database by running the "Create UserMan
Database-Oracle 8i.sql" script file. This script will create the
tables, triggers, views, packages, stored functions, and stored
procedures used by the example code. The script also inserts example
data in the tables. Please note, that this script doesn't create the
database, only the database objects. So, if you want a new database
for your UserMan database objects, you need to create it yourself.
Please check the Oracle documentation for information on how to do
this. However, all database objects are created with the USERMAN user
as the owner, meaning you can drop this user with a cascading delete,
so that all database objects are removed from your database. You can
see the instructions fro dropping the user in the "Deleting the
UserMan Database from Oracle" section. Here is how you create the
database objects using the script:
    *    You can run this script from the SQLPlus Worksheet application.
      Please consult the Oracle documentation for information on how to do
      this.
  You need to install and configure the Oracle client tools on the
machine from which you want to connect to the Oracle server. Please
check the Oracle documentation for information on how to do this.

Setting Up the UserMan MS Access Database
-----------------------------------------
There really isn't a lot to do to set up the MS Access UserMan
database, because MS Access databases are, as I'm sure you know, file-
based. Simply unzip the UserMan.mdb file from the "UserMan Database
Setup.zip" file and place in the desired folder. The UserMan.mdb
database is an MS Access 2000 database. Please make sure you keep a
backup copy of the database file, in case you want to start from
scratch.

Setting Up the UserMan Database on IBM DB2(3)
---------------------------------------------
You can create the UserMan database by running the "Create UserMan
Database-IBM DB2.sql" script file. This script will create the
database, tables, triggers, views, and stored procedures used by the
example code. The script also inserts example data in the tables.
  Here is how you create the database using the script:
    *    You can run this script from the Script tab of the Command Center
      application. Be aware that I'm using a forward slash (/) as the
      statement termination character. However, the default termination
      character used by the Command Center application is a carriage return.
      You can and must change this from the General tab of the Tools
      Settings dialog box, in order to run the script. Please consult the
      IBM DB2 documentation for information on how to do this.

  You need to install and configure the DB2 client tools on the
machine from which you want to connect to the DB2 server. Please check
the IBM DB2 documentation for information on how to do this.

Deleting the UserMan Database from SQL Server
---------------------------------------------
You can delete the UserMan database by running the "Delete UserMan
Database.sql" script file. This script will delete the database, and
logins.
  Here are two ways of deleting the database using the script:
    1    You can choose to run this script from the SQL Server Enterprise
      Manager. Please see the Enterprise Manager documentation for
      information on how to do this.
    2    You can also run the script from within the UserMan Database
      Project.
      1    Open the project up in the VS .NET IDE.
      2    The script file is located in the Change Scripts folder shown in
        the Solution Explorer. Expand the Change Scripts folder.
      3    Set the database reference or the SQL Server on which you have
        created the database. This is done by right-clicking on the project in
        the Solution Explorer and selecting Set Default Reference from the pop-
        up menu. This brings up the Set Default Reference dialog box, where
        you can click the Add Reference button to add a reference to your SQL
        Server. Please note that you need to create the reference as a user
        who has the rights to delete a database, such as sa.
      4    Right-click on the Delete UserMan Database.sql file in the Create
        Scripts folder, and select Run from the pop-up menu.

Deleting the UserMan Database from MySQL
----------------------------------------
You can delete the UserMan database by running the "Delete UserMan
Database-MySQL.sql" script file. This script will delete the database,
and logins.
  Here is how you delete the database using the script:
    *    From a Command Prompt in the MySQL\Bin folder (typically C:\
      MySQL\Bin) you run this command: mysql < "Path\Delete UserMan Database-
      MySQL.sql", where Path\ is the full path to where you've placed the
      script file.

Deleting the UserMan Database from Oracle
-----------------------------------------
You can delete the UserMan database by running the "Delete UserMan
Database-Oracle.sql" script file. This script will delete all the
database objects belonging to the USERMAN user.
  Here is how you delete the database objects using the script:
    *    You can run this script from the SQLPlus Worksheet application.
      Please consult the Oracle documentation for information on how to do
      this.

Deleting the UserMan MS Access Database
---------------------------------------
Because the MS Access version of the UserMan database is file based,
you can simply the delete the file, which is called UserMan.mdb. Now
there's a surprise...

Deleting the UserMan Database from IBM DB2
------------------------------------------
You can delete the UserMan database by running the "Delete UserMan
Database-DB2.sql" script file. This script will delete the UserMan
database.
  Here is how you delete the database objects using the script:
    *    You can run this script from the Script tab of the Command Center
      application. Please consult the IBM DB2 documentation for information
      on how to do this.

Changing References to Your Database Server
-------------------------------------------
In all of the example code, I have used USERMANPC or an IP address as
the name of the database server to connect to, but I have a feeling
that this might be inappropriate on your system. So before you run an
example code project, please be sure to change it to the name of your
database Server. You will avoid the time-out exception if you do...

Note about the Example Code
---------------------------
The example code in some chapters comes in three variants; using the
ODBC .NET Data Provider, the OLE DB .NET Data Provider, and the SQL
Server .NET Data Provider.

Locating the Example Code
-------------------------
In Table 1 you can look up a specific listing and see what project it
is part of and the location of the project. If a particular listing,
such as Listing 5-13, 7-9, 9-1, and all listings in Chapter 24 cannot
be found, it is because it is too trivial to include, or simply a made
up listing. Please note, that there are no listings in Chapters 1, 2,
3, and 4.

Table 1. Example Code Location
------------------------------
Listing  Project / File Location
5-1	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, 
	Chapter 05\MySqlConnection_MySqlTransaction Project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-2	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, 
	Chapter 05\MySqlConnection_MySqlTransaction Project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-3	Chapter 05\OleDbconnection_OleDbTransaction project
5-4	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-5	Chapter 05\SqlConnection_SqlTransaction Project
5-6	Chapter 05\OdbcConnection_OdbcTransaction project
5-7	Chapter 05\OleDbconnection_OleDbTransaction project
5-8	Chapter 05\OleDbconnection_OleDbTransaction project
5-9	Chapter 05\SqlConnection_SqlTransaction Project
5-10	Chapter 05\OdbcConnection_OdbcTransaction project
5-11	Chapter 05\OleDbconnection_OleDbTransaction project
5-12	Chapter 05\SqlConnection_SqlTransaction Project
5-14	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, 
	Chapter 05\MySqlConnection_MySqlTransaction Project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-15	Chapter 05\SqlConnection_SqlTransaction Project
5-16	Chapter 05\SqlConnection_SqlTransaction Project
5-17	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, 
	Chapter 05\MySqlConnection_MySqlTransaction Project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-18	Chapter 05\OleDbconnection_OleDbTransaction project
5-19	Chapter 05\SqlConnection_SqlTransaction Project
5-20	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, 
	Chapter 05\MySqlConnection_MySqlTransaction Project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-21	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-22	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-23	Chapter 05\SqlConnection_SqlTransaction Project
5-24	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
5-25	Chapter 05\OdbcConnection_OdbcTransaction project, 
	Chapter 05\OleDbconnection_OleDbTransaction project, and 
	Chapter 05\SqlConnection_SqlTransaction Project
6-1	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, 
	Chapter 06\MySqlCommand_MySqlParameter Project and
	Chapter 06\SqlCommand_SqlParameter Project
6-2	Chapter 06\MySqlCommand_MySqlParameter Project
	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
6-3	Chapter 06\MySqlCommand_MySqlParameter Project
	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
6-4	Chapter 06\MySqlCommand_MySqlParameter Project
	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
6-5	Chapter 06\SqlCommand_SqlParameter Project
6-6	Chapter 06\MySqlCommand_MySqlParameter Project
	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
6-7	Chapter 06\MySqlCommand_MySqlParameter Project
	Chapter 06\OdbcCommand_OdbcParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
6-8	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
6-9	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
6-10	Chapter 06\MySqlCommand_MySqlParameter Project
	Chapter 06\OdbcCommand_OdbcParameter Project,
	Chapter 06\OleDbCommand_OleDbParameter Project, and
	Chapter 06\SqlCommand_SqlParameter Project
7-1	Chapter 07\MySqlDataReader Project,
	Chapter 07\OdbcDataReader Project,
	Chapter 07\OleDbDataReader Project, and
	Chapter 07\SqlDataReader Project
7-2	Chapter 07\MySqlDataReader Project,
	Chapter 07\OdbcDataReader Project,
	Chapter 07\OleDbDataReader Project, and
	Chapter 07\SqlDataReader Project
7-3	Chapter 07\MySqlDataReader Project,
	Chapter 07\OdbcDataReader Project,
	Chapter 07\OleDbDataReader Project, and
	Chapter 07\SqlDataReader Project
7-4	Chapter 07\MySqlDataReader Project,
	Chapter 07\OdbcDataReader Project,
	Chapter 07\OleDbDataReader Project, and
	Chapter 07\SqlDataReader Project
7-5	Chapter 07\MySqlDataReader Project,
	Chapter 07\OdbcDataReader Project,
	Chapter 07\OleDbDataReader Project, and
	Chapter 07\SqlDataReader Project
7-6	Chapter 07\MySqlDataReader Project,
	Chapter 07\OdbcDataReader Project,
	Chapter 07\OleDbDataReader Project, and
	Chapter 07\SqlDataReader Project
7-7	Chapter 07\SqlDataReader Project
7-8	Chapter 07\SqlDataReader Project
8-1	Chapter 08\MySqlDataAdapter_MySqlCommandBuilder Project
	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-2	Chapter 08\MySqlDataAdapter_MySqlCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-3	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project, and
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project
8-4	Chapter 08\MySqlDataAdapter_MySqlCommandBuilder Project
	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-5	Chapter 08\MySqlDataAdapter_MySqlCommandBuilder Project
	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-6	Chapter 08\MySqlDataAdapter_MySqlCommandBuilder Project
	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-7	Chapter 08\MySqlDataAdapter_MySqlCommandBuilder Project
	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-8	Chapter 08\MySqlDataAdapter_MySqlCommandBuilder Project
	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-9	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
8-10	Chapter 08\OdbcDataAdapter_OdbcCommandBuilder Project,
	Chapter 08\OleDbDataAdapter_OleDbCommandBuilder Project, and
	Chapter 08\SqlDataAdapter_SqlCommandBuilder Project
9-2	Chapter 09\DataSet Project
9-3	Chapter 09\DataSet Project
9-4	Chapter 09\DataSet Project
9-5	Chapter 09\DataSet Project
9-6	Chapter 09\DataSet Project
9-7	Chapter 09\DataSet Project
9-8	Chapter 09\DataSet Project
9-9	Chapter 09\DataSet Project
9-10	Chapter 09\DataSet Project
10-1	Chapter 10\DataTable_DataView Project
10-2	Chapter 10\DataTable_DataView Project
10-3	Chapter 10\DataTable_DataView Project
10-4	Chapter 10\DataTable_DataView Project
10-5	Chapter 10\DataTable_DataView Project
10-6	Chapter 10\DataTable_DataView Project
10-7	Chapter 10\DataTable_DataView Project
10-8	Chapter 10\DataTable_DataView Project
10-9	Chapter 10\DataTable_DataView Project
10-10	Chapter 10\DataTable_DataView Project
10-11	Chapter 10\DataTable_DataView Project
10-12	Chapter 10\DataTable_DataView Project
10-13	Chapter 10\DataTable_DataView Project
10-14	Chapter 10\DataTable_DataView Project
10-15	Chapter 10\DataTable_DataView Project
11-1	Chapter 11\DataRow_DataColumn Project
11-2	Chapter 11\DataRow_DataColumn Project
11-3	Chapter 11\DataRow_DataColumn Project
11-4	Chapter 11\DataRow_DataColumn Project
11-5	Chapter 11\DataRow_DataColumn Project
11-6	Chapter 11\DataRow_DataColumn Project
12-1	Chapter 12\DataRelation Project
12-2	Chapter 12\DataRelation Project
12-3	Chapter 12\DataRelation Project
12-4	Chapter 12\DataRelation Project
12-5	Chapter 12\DataRelation Project
12-6	Chapter 12\DataRelation Project
13-1	Chapter 13\Typed DataSet Project
14-2	Chapter 14\SEH Project
14-3	Chapter 14\SEH Project
14-4	Chapter 14\SEH Project
14-5	Chapter 14\SEH Project
14-6	Chapter 14\SEH Project
14-7	Chapter 14\SEH Project
14-8	Chapter 14\SEH Project
14-9	Chapter 14\SEH Project
14-10	Chapter 14\SEH Project
14-11	Chapter 14\SEH Project
14-12	Chapter 14\SEH Project
14-13	Chapter 14\SEH Project
14-14	Chapter 14\UEH Project
14-15	Chapter 14\UEH Project
14-16	Chapter 14\UEH Project
14-17	Chapter 14\UEH Project
14-18	Chapter 14\UEH Project
14-19	Chapter 14\UEH Project
14-20	Chapter 14\UEH Project
14-21	Chapter 14\UEH Project
14-22	Chapter 14\UEH Project
14-23	Chapter 14\UEH Project
14-24	Chapter 14\UEH Project
14-25	Chapter 14\UEH Project
14-26	Chapter 14\UEH Project
15-1	Chapter 15\Debug_Trace Project
15-2	Chapter 15\Debug_Trace Project
16-1	Chapter 16\Stored Procedure Project
16-2	Chapter 16\Stored Procedure Project
16-3	Chapter 16\Stored Procedure Project
16-4	Chapter 16\Stored Procedure Project
16-5	Chapter 16\Stored Procedure Project
16-6	Chapter 16\Stored Procedure Project\Oracle.txt
16-7	Chapter 16\Stored Procedure Project
16-8	Chapter 16\Stored Procedure Project\Oracle.txt
16-9	Chapter 16\Stored Procedure Project
16-10	Chapter 16\Stored Procedure Project\Oracle.txt
16-11	Chapter 16\Stored Procedure Project
16-12	Chapter 16\Stored Procedure Project\DB2.txt
16-13	Chapter 16\Stored Procedure Project
16-14	Chapter 16\Stored Procedure Project\DB2.txt
16-15	Chapter 16\Stored Procedure Project
16-16	Chapter 16\Stored Procedure Project\DB2.txt
16-17	Chapter 16\Stored Procedure Project
17-1	Chapter 17\Views Project
17-2	Chapter 17\Views Project
18-1	Chapter 18\Triggers Project\Triggers.txt
18-2	Chapter 18\Triggers Project
18-3	Chapter 18\Triggers Project
19-1	Chapter 19\Active Directory Project
19-2	Chapter 19\Active Directory Project
19-3	Chapter 19\Active Directory Project
19-4	Chapter 19\Active Directory Project
19-5	Chapter 19\Active Directory Project
19-6	Chapter 19\Active Directory Project
19-7	Chapter 19\Active Directory Project
19-8	Chapter 19\Active Directory Project
19-9	Chapter 19\Active Directory Project
20-1	Chapter 20\Exchange Server Project
20-2	Chapter 20\Exchange Server Project
20-3	Chapter 20\Exchange Server Project
20-4	Chapter 20\Exchange Server Project\LinkedServer.txt
20-5	Chapter 20\Exchange Server Project\ExchangeServerView.txt
21-1	Chapter 21\Message Queuing Project
21-2	Chapter 21\Message Queuing Project
21-3	Chapter 21\Message Queuing Project
21-4	Chapter 21\Message Queuing Project
21-5	Chapter 21\Message Queuing Project
21-6	Chapter 21\Message Queuing Project
21-7	Chapter 21\Message Queuing Project
21-8	Chapter 21\Message Queuing Project
21-9	Chapter 21\Message Queuing Project
21-10	Chapter 21\Message Queuing Project
21-11	Chapter 21\Message Queuing Project
21-12	Chapter 21\Message Queuing Project
21-13	Chapter 21\Message Queuing Project
21-14	Chapter 21\Message Queuing Project
21-15	Chapter 21\Message Queuing Project
21-16	Chapter 21\Message Queuing Project
21-17	Chapter 21\Message Queuing Project
21-18	Chapter 21\Message Queuing Project
21-19	Chapter 21\Message Queuing Project
21-20	Chapter 21\Message Queuing Project
21-21	Chapter 21\Message Queuing Project
21-22	Chapter 21\Message Queuing Project
21-23	Chapter 21\Message Queuing Project
21-24	Chapter 21\Message Queuing Project
21-25	Chapter 21\Message Queuing Project
21-26	Chapter 21\Message Queuing Project
21-27	Chapter 21\Message Queuing Project
21-28	Chapter 21\Message Queuing Project
21-29	Chapter 21\Message Queuing Project
21-30	Chapter 21\Message Queuing Project
21-31	Chapter 21\Message Queuing Project
21-32	Chapter 21\Message Queuing Project
21-33	Chapter 21\Message Queuing Project
21-34	Chapter 21\Message Queuing Project
21-35	Chapter 21\Message Queuing Project
21-36	Chapter 21\Message Queuing Project
21-37	Chapter 21\MSMQTrigger
21-38	Chapter 21\Message Queuing Project
22-4	Chapter 22\Inetpub\wwwroot\UserMan\Templates\AllUsers.xml
22-5	Chapter 22\Inetpub\wwwroot\UserMan\Templates\Users.xml
22-6	Chapter 22\Inetpub\wwwroot\UserMan\Templates\uspGetUsers.xml
22-7	Chapter 22\Inetpub\wwwroot\UserMan\Templates\AllUsers-client-side-xml.xml
22-8	Chapter 22\SQLXML 3.0 Project
22-9	Chapter 22\SQLXML 3.0 Project
22-10	Chapter 22\SQLXML 3.0 Project
22-11	Chapter 22\SQLXML 3.0 Project
22-13	Chapter 22\SQLXML 3.0 Project
22-14	Chapter 22\SQLXML 3.0 Project
22-15	Chapter 22\SQLXML 3.0 Project
22-16	Chapter 22\SQLXML 3.0 Project
22-17	Chapter 22\SQLXML 3.0 Project
22-18	Chapter 22\SQLXML 3.0 Project
22-19	Chapter 22\SQLXML 3.0 Project
22-20	Chapter 22\SQLXML 3.0 Project
22-21	Chapter 22\Inetpub\wwwroot\UserMan\Schemas\Users.xsd
22-22	Chapter 22\SQLXML 3.0 Project
22-23	Chapter 22\SQLXML 3.0 Project
22-24	Chapter 22\Inetpub\wwwroot\UserMan\Templates\UpdateUsers.xml
22-25	Chapter 22\SQLXML 3.0 Project
22-26	Chapter 22\SQLXML 3.0 Project
22-27	Chapter 22\SQLXML 3.0 Project
22-28	Chapter 22\Inetpub\wwwroot\UserMan\Schemas\Users.xsd
22-29	Chapter 22\SQLXML 3.0 Project
23-1	Chapter 23\Wrappers Project
23-2	Chapter 23\Wrappers Project
23-3	Chapter 23\Wrappers Project
23-4	Chapter 23\Wrappers Project
23-5	Chapter 23\Wrappers Project
23-6	Chapter 23\UserMan
23-7	Chapter 23\UserMan
23-8	Chapter 23\UserMan
23-9	Chapter 23\UserMan
23-10	Chapter 23\UserMan
23-11	Chapter 23\UserMan
23-12	Chapter 23\UserMan
23-13	Chapter 23\UserMan
23-14	Chapter 23\UserMan
23-15	Chapter 23\UserMan
23-16	Chapter 23\UserMan
23-17	Chapter 23\UserMan
23-18	Chapter 23\UserManTest
23-19	Chapter 23\UserManTest
23-20	Chapter 23\UserMan
25-1	Chapter 25\WebFormDataBoundControls
25-2	Chapter 25\WebFormDataBoundControls
25-3	Chapter 25\WebFormDataBoundControls
25-4	Chapter 25\WebFormDataBoundControls
26-1	Chapter 26\UserMan
26-2	Chapter 26\UserMan
26-3	Chapter 26\UserMan
26-4	Chapter 26\UserMan
26-5	Chapter 26\UserMan
26-6	Chapter 26\UserMan
26-7	Chapter 26\UserMan
26-8	Chapter 26\UserMan
26-9	Chapter 26\UserMan
26-10	Chapter 26\UserMan
26-11	Chapter 26\UserMan
26-12	Chapter 26\UserMan
26-13	Chapter 26\UserMan
26-14	Chapter 26\UserMan
A-1	Appendix A\Locking_Concurrency Project
A-2	Appendix A\Locking_Concurrency Project
A-3	Appendix A\Locking_Concurrency Project
A-4	Appendix A\Locking_Concurrency Project

  The example code for inserting rows in an Oracle database uses the
NEWVAL method of the Oracle SEQUENCE object. If you look at the
example code for creating the Oracle database objects, you'll notice
that I create a SEQUENCE object on the three database tables that has
an IDENTITY column in SQL Server, or an AutoNumber column in MS
Access. Oracle doesn't support auto numbering of column values this
way, which is why I've created the SEQUENCE objects. However, you need
to be aware of this when inserting values in to the tables, because
otherwise you'll insert a NULL value and the insert will fail.
  Log on to the UserMan site, http://www.userman.dk, if you want
download example code updates or subscribe to update notifications.
Then you'll automatically receive a notification about the updated
example code when available!
  All example code has been tested more than once, but this doesn't
guarantee that you won't have any problems running it. I will be
pleased to help you out, if you think there's something wrong or
missing. Just send me an email at this address:

carstent@dotnetservices.biz.


Enjoy

Carsten Thomsen
Esbjerg, Denmark, October 2002
_______________________________
1 Only version 3.23.51 and later are supported
2 Only version 7.3 or later is supported. The example code has been
tested against Oracle 9i Enterprise.
3 The script and example code has been tested with IBM DB2 Universal
Database 7.2 Enterprise Edition.