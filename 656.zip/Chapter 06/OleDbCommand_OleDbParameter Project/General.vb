Option Strict On

Imports System.Data.OleDb
Imports System.Xml
Imports ADODB

'#Const Oracle = 1
'#Const DB2 = 1
#Const MSAccess = 1
'#Const SQLSERVER = 1
' You simply uncomment the line above for the DBMS you want to use

Module General
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = "Provider=SQLOLEDB;Data Source=USERMANPC;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
#ElseIf MSAccess Then
   ' This connection string os for connecting to an Access mdb
   ' I'm not using any security, hence the blank User Id and password. I'm also
   ' Opening the mdb in shared mode. You must edit the path to your database file
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\DBPWVBNET\UserMan.mdb;" & _
      "Mode=Share Deny None;"
#ElseIf Oracle Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
	Private Const PR_STR_CONNECTION_STRING as String  = _
		"Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#ElseIf DB2 Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Listing 6-1
   Public Sub InstantiateCommandObject()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
   End Sub

   ' Listing 6-2
   Public Sub ExecuteNonQueryCommand()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build delete query string
      strSQL = "DELETE FROM tblUser WHERE LoginName='User99'"
      ' Instantiate and execute the delete command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      cmmUserMan.ExecuteNonQuery()
      ' Build insert query string
      strSQL = "INSERT INTO tblUser (LoginName) VALUES('User99')"
      ' Instantiate and execute the insert command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      cmmUserMan.ExecuteNonQuery()
   End Sub

   ' Listing 6-3
   Public Sub ExecuteReaderCommand()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim drdTest As OleDbDataReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate and execute the command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      drdTest = cmmUserMan.ExecuteReader()
   End Sub

   ' Listing 6-4
   Public Sub ExecuteScalarCommand()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim intNumRows As Integer
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT COUNT(*) FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      ' Save the number of rows in the table
      intNumRows = CInt(cmmUserMan.ExecuteScalar().ToString)
   End Sub

   ' Listing 6-6
   Public Sub CheckCommandTimeoutPropertyException()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
         ' Change command timeout
         cmmUserMan.CommandTimeout = -1
      Catch objException As ArgumentException
         ' Check if we tried to set command timeout to an invalid value
         If objException.TargetSite.Name = "set_CommandTimeout" Then
            ' You can choose to have the user set a new timeout value,
            ' set it to the default value, or just leave it as it is as
            ' it hasn't changed
            ' ...
         End If
      End Try
   End Sub

   ' Listing 6-8
   Public Sub CheckPrepareMethodException()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         ' If the following line is commented out, the ValidateCommand exception will be thrown
         'cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
         ' Prepare command
         cmmUserMan.Prepare()
      Catch objException As InvalidOperationException
         ' Check if we tried to prepare the command on an invalid connection
         If objException.TargetSite.Name = "SetStateExecuting" Then
            ' Open the connection and try again
            cnnUserMan.Open()
            cmmUserMan.Prepare()
         End If
      End Try
   End Sub

   ' Listing 6-9
   Public Sub CheckUpdatedRowSourcePropertyException()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
         ' Change Row source Update
         ' You need to turn Option Strict Off for this to compile
         'cmmUserMan.UpdatedRowSource = 5
      Catch objException As ArgumentException
         ' Check if we tried to set the row source update to an invalid value
         If objException.TargetSite.Name = "set_UpdatedRowSource" Then
            ' Ask the user or simply set to a valid value. Was the current value okay?
            ' ...
         End If
      End Try
   End Sub

   ' Listing 6-10
   Public Sub InstantiateParameterObject()
      Dim prmNoArguments As New OleDbParameter()
      Dim prmNameValueArguments As New OleDbParameter("Id", 3)
      Dim prmNameDataTypeArguments As New OleDbParameter("Id", OleDbType.Integer)
      Dim prmNameDataTypeSizeArguments As New OleDbParameter("LoginName", _
         OleDbType.VarChar, 50)
      Dim prmNameDataTypeSizeSourceColumnArguments As New OleDbParameter( _
         "LoginName", OleDbType.VarChar, 50, "LoginName")
      Dim prmNameDataTypeSizeDirNullPrecisionScaleSrcColSrcVersionValueArgs _
         As New OleDbParameter("LoginName", OleDbType.VarChar, 50, _
         ParameterDirection.Input, True, 0, 0, "LoginName", _
         DataRowVersion.Current, 3)
   End Sub
End Module