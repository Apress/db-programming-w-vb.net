Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnInstantiateCommandObject As System.Windows.Forms.Button
   Friend WithEvents btnExecuteNonQueryCommand As System.Windows.Forms.Button
   Friend WithEvents btnExecuteReaderCommand As System.Windows.Forms.Button
   Friend WithEvents btnExecuteScalarCommand As System.Windows.Forms.Button
   Friend WithEvents btnCheckCommandTimeoutPropertyException As System.Windows.Forms.Button
   Friend WithEvents btnCheckPrepareMethodException As System.Windows.Forms.Button
   Friend WithEvents btnCheckUpdatedRowSourcePropertyException As System.Windows.Forms.Button
   Friend WithEvents btnInstantiateParameterObject As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnInstantiateCommandObject = New System.Windows.Forms.Button()
      Me.btnExecuteNonQueryCommand = New System.Windows.Forms.Button()
      Me.btnExecuteReaderCommand = New System.Windows.Forms.Button()
      Me.btnExecuteScalarCommand = New System.Windows.Forms.Button()
      Me.btnCheckCommandTimeoutPropertyException = New System.Windows.Forms.Button()
      Me.btnCheckPrepareMethodException = New System.Windows.Forms.Button()
      Me.btnCheckUpdatedRowSourcePropertyException = New System.Windows.Forms.Button()
      Me.btnInstantiateParameterObject = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnInstantiateCommandObject
      '
      Me.btnInstantiateCommandObject.Location = New System.Drawing.Point(20, 33)
      Me.btnInstantiateCommandObject.Name = "btnInstantiateCommandObject"
      Me.btnInstantiateCommandObject.Size = New System.Drawing.Size(202, 23)
      Me.btnInstantiateCommandObject.TabIndex = 1
      Me.btnInstantiateCommandObject.Text = "Instantiate Command Object"
      '
      'btnExecuteNonQueryCommand
      '
      Me.btnExecuteNonQueryCommand.Location = New System.Drawing.Point(20, 62)
      Me.btnExecuteNonQueryCommand.Name = "btnExecuteNonQueryCommand"
      Me.btnExecuteNonQueryCommand.Size = New System.Drawing.Size(202, 23)
      Me.btnExecuteNonQueryCommand.TabIndex = 2
      Me.btnExecuteNonQueryCommand.Text = "Execute Non Query Command"
      '
      'btnExecuteReaderCommand
      '
      Me.btnExecuteReaderCommand.Location = New System.Drawing.Point(20, 90)
      Me.btnExecuteReaderCommand.Name = "btnExecuteReaderCommand"
      Me.btnExecuteReaderCommand.Size = New System.Drawing.Size(202, 23)
      Me.btnExecuteReaderCommand.TabIndex = 3
      Me.btnExecuteReaderCommand.Text = "Execute Reader Command"
      '
      'btnExecuteScalarCommand
      '
      Me.btnExecuteScalarCommand.Location = New System.Drawing.Point(20, 118)
      Me.btnExecuteScalarCommand.Name = "btnExecuteScalarCommand"
      Me.btnExecuteScalarCommand.Size = New System.Drawing.Size(202, 23)
      Me.btnExecuteScalarCommand.TabIndex = 7
      Me.btnExecuteScalarCommand.Text = "Execute Scalar Command"
      '
      'btnCheckCommandTimeoutPropertyException
      '
      Me.btnCheckCommandTimeoutPropertyException.Location = New System.Drawing.Point(242, 34)
      Me.btnCheckCommandTimeoutPropertyException.Name = "btnCheckCommandTimeoutPropertyException"
      Me.btnCheckCommandTimeoutPropertyException.Size = New System.Drawing.Size(250, 23)
      Me.btnCheckCommandTimeoutPropertyException.TabIndex = 8
      Me.btnCheckCommandTimeoutPropertyException.Text = "Check CommandTimeout Property Exception"
      '
      'btnCheckPrepareMethodException
      '
      Me.btnCheckPrepareMethodException.Location = New System.Drawing.Point(242, 62)
      Me.btnCheckPrepareMethodException.Name = "btnCheckPrepareMethodException"
      Me.btnCheckPrepareMethodException.Size = New System.Drawing.Size(250, 23)
      Me.btnCheckPrepareMethodException.TabIndex = 9
      Me.btnCheckPrepareMethodException.Text = "Check Prepare Method Exception"
      '
      'btnCheckUpdatedRowSourcePropertyException
      '
      Me.btnCheckUpdatedRowSourcePropertyException.Location = New System.Drawing.Point(242, 90)
      Me.btnCheckUpdatedRowSourcePropertyException.Name = "btnCheckUpdatedRowSourcePropertyException"
      Me.btnCheckUpdatedRowSourcePropertyException.Size = New System.Drawing.Size(250, 23)
      Me.btnCheckUpdatedRowSourcePropertyException.TabIndex = 10
      Me.btnCheckUpdatedRowSourcePropertyException.Text = "Check UpdatedRowSource Property Exception"
      '
      'btnInstantiateParameterObject
      '
      Me.btnInstantiateParameterObject.Location = New System.Drawing.Point(244, 146)
      Me.btnInstantiateParameterObject.Name = "btnInstantiateParameterObject"
      Me.btnInstantiateParameterObject.Size = New System.Drawing.Size(250, 23)
      Me.btnInstantiateParameterObject.TabIndex = 11
      Me.btnInstantiateParameterObject.Text = "Instantiate Parameter Object"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(520, 174)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnInstantiateParameterObject, Me.btnCheckUpdatedRowSourcePropertyException, Me.btnCheckPrepareMethodException, Me.btnCheckCommandTimeoutPropertyException, Me.btnExecuteScalarCommand, Me.btnExecuteReaderCommand, Me.btnExecuteNonQueryCommand, Me.btnInstantiateCommandObject})
      Me.Name = "Form1"
      Me.Text = "OleDbCommand_OleDbParameter Project"
      Me.ResumeLayout(False)

   End Sub

#End Region


   Private Sub btnInstantiateCommandObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateCommandObject.Click
      InstantiateCommandObject()
   End Sub

   Private Sub btnExecuteNonQueryCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteNonQueryCommand.Click
      ExecuteNonQueryCommand()
   End Sub

   Private Sub btnExecuteReaderCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteReaderCommand.Click
      ExecuteReaderCommand()
   End Sub

   Private Sub btnExecuteScalarCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteScalarCommand.Click
      ExecuteScalarCommand()
   End Sub

   Private Sub btnCheckCommandTimeoutPropertyException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckCommandTimeoutPropertyException.Click
      CheckCommandTimeoutPropertyException()
   End Sub

   Private Sub btnCheckPrepareMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckPrepareMethodException.Click
      CheckPrepareMethodException()
   End Sub

   Private Sub btnCheckUpdatedRowSourcePropertyException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckUpdatedRowSourcePropertyException.Click
      CheckUpdatedRowSourcePropertyException()
   End Sub

   Private Sub btnInstantiateParameterObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateParameterObject.Click
      InstantiateParameterObject()
   End Sub
End Class