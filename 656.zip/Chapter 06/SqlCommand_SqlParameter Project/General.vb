'Option Strict On

Imports System.Data.SqlClient
Imports System.Xml

Module General
   Private Const PR_STR_CONNECTION_STRING As String = "Address=10.8.1.11;" & _
      "UID=UserMan;Pwd=userman;Database=UserMan"

   ' Listing 6-1
   Public Sub InstantiateCommandObject()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
   End Sub

   ' Listing 6-2
   Public Sub ExecuteNonQueryCommand()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build delete query string
      strSQL = "DELETE FROM tblUser WHERE LoginName='User99'"
      ' Instantiate and execute the delete command
      cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
      cmmUserMan.ExecuteNonQuery()
      ' Build insert query string
      strSQL = "INSERT INTO tblUser (LoginName) VALUES('User99')"
      ' Instantiate and execute the insert command
      cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
      cmmUserMan.ExecuteNonQuery()
   End Sub

   ' Listing 6-3
   Public Sub ExecuteReaderCommand()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim drdTest As SqlDataReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate and execute the command
      cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
      drdTest = cmmUserMan.ExecuteReader()
   End Sub

   ' Listing 6-4
   Public Sub ExecuteScalarCommand()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim intNumRows As Integer
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT COUNT(*) FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
      ' Save the number of rows in the table
      intNumRows = CInt(cmmUserMan.ExecuteScalar().ToString)
   End Sub

   ' Listing 6-5
   Public Sub ExecuteXmlReaderCommand()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim drdTest As XmlReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string to return result set as XML
      strSQL = "SELECT * FROM tblUser FOR XML AUTO"
      ' Instantiate the command
      cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
      ' Retrieve the rows as XML
      drdTest = cmmUserMan.ExecuteXmlReader()
   End Sub

   ' Listing 6-6
   Public Sub CheckCommandTimeoutPropertyException()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
         ' Change command timeout
         cmmUserMan.CommandTimeout = -1
      Catch objException As ArgumentException
         ' Check if we tried to set command timeout to an invalid value
         If objException.TargetSite.Name = "set_CommandTimeout" Then
            ' You can choose to have the user set a new timeout value,
            ' set it to the default value, or just leave it as it is as
            ' it hasn't changed
            ' ...
         End If
      End Try
   End Sub

   ' Listing 6-7
   Public Sub CheckCommandTypePropertyException()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
         ' Change command type
         cmmUserMan.CommandType = CommandType.TableDirect
      Catch objException As ArgumentException
         ' Check if tried to set command type to an invalid value
         If objException.TargetSite.Name = "set_CommandType" Then
            ' Perhaps ask the user, or since we know this is because
            ' we're trying to use a OLE DB .NET Data Provider only
            ' supported setting, we can change the SQL statement and 
            ' set the CommandType property to Text
            cmmUserMan.CommandType = CommandType.Text
            cmmUserMan.CommandText = "SELECT * FROM " & _
               cmmUserMan.CommandText
         End If
      End Try
   End Sub

   ' Listing 6-8
   Public Sub CheckPrepareMethodException()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         ' If the following line is commented out, the ValidateCommand exception will be thrown
         'cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
         ' Prepare command
         cmmUserMan.Prepare()
      Catch objException As InvalidOperationException
         ' Check if we tried to prepare the command on an invalid connection
         If objException.TargetSite.Name = "ValidateCommand" Then
            ' Open the connection and try again
            cnnUserMan.Open()
            cmmUserMan.Prepare()
         End If
      End Try
   End Sub

   ' Listing 6-9
   Public Sub CheckUpdatedRowSourcePropertyException()
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
         ' Change Row source Update
         ' You need to turn Option Strict Off for this to compile
         cmmUserMan.UpdatedRowSource = 5
      Catch objException As ArgumentException
         ' Check if we tried to set the row source update to an invalid value
         If objException.TargetSite.Name = "set_UpdatedRowSource" Then
            ' Ask the user or simply set to a valid value. Was the current value okay?
            ' ...
         End If
      End Try
   End Sub

   ' Listing 6-10
   Public Sub InstantiateParameterObject()
      Dim prmNoArguments As New SqlParameter()
      Dim prmNameValueArguments As New SqlParameter("Id", 3)
      Dim prmNameDataTypeArguments As New SqlParameter("Id", SqlDbType.Int)
      Dim prmNameDataTypeSizeArguments As New SqlParameter("LoginName", _
         SqlDbType.VarChar, 50)
      Dim prmNameDataTypeSizeSourceColumnArguments As New SqlParameter( _
         "LoginName", SqlDbType.VarChar, 50, "LoginName")
      Dim prmNameDataTypeSizeDirNullPrecisionScaleSrcColSrcVersionValueArgs _
         As New SqlParameter("LoginName", SqlDbType.VarChar, 50, _
         ParameterDirection.Input, True, 0, 0, "LoginName", _
         DataRowVersion.Current, 3)
   End Sub
End Module