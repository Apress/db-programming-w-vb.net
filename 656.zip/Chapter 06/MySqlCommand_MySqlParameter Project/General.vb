'Option Strict On

Imports eInfoDesigns.dbProvider.MySqlClient
Imports System.Xml

Module General
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.32;" & _
      "User ID=UserMan;Password=userman;Database=UserMan"

   ' Listing 6-1
   Public Sub InstantiateCommandObject()
      Dim cnnUserMan As MySqlConnection
      Dim cmmUserMan As MySqlCommand
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New MySqlCommand(strSQL, cnnUserMan)
   End Sub

   ' Listing 6-2
   Public Sub ExecuteNonQueryCommand()
      Dim cnnUserMan As MySqlConnection
      Dim cmmUserMan As MySqlCommand
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build delete query string
      strSQL = "DELETE FROM tblUser WHERE LoginName='User99'"
      ' Instantiate and execute the delete command
      cmmUserMan = New MySqlCommand(strSQL, cnnUserMan)
      cmmUserMan.ExecuteNonQuery()
      ' Build insert query string
      strSQL = "INSERT INTO tblUser (LoginName) VALUES('User99')"
      ' Instantiate and execute the insert command
      cmmUserMan = New MySqlCommand(strSQL, cnnUserMan)
      cmmUserMan.ExecuteNonQuery()
   End Sub

   ' Listing 6-3
   Public Sub ExecuteReaderCommand()
      Dim cnnUserMan As MySqlConnection
      Dim cmmUserMan As MySqlCommand
      Dim drdTest As MySqlDataReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate and execute the command
      cmmUserMan = New MySqlCommand(strSQL, cnnUserMan)
      drdTest = cmmUserMan.ExecuteReader()
   End Sub

   ' Listing 6-4
   Public Sub ExecuteScalarCommand()
      Dim cnnUserMan As MySqlConnection
      Dim cmmUserMan As MySqlCommand
      Dim intNumRows As Integer
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT COUNT(*) FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New MySqlCommand(strSQL, cnnUserMan)
      ' Save the number of rows in the table
      intNumRows = CInt(cmmUserMan.ExecuteScalar().ToString)
   End Sub

   ' Listing 6-6
   Public Sub CheckCommandTimeoutPropertyException()
      Dim cnnUserMan As MySqlConnection
      Dim cmmUserMan As MySqlCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New MySqlCommand(strSQL, cnnUserMan)
         ' Change command timeout
         cmmUserMan.CommandTimeout = -1
      Catch objException As ArgumentException
         ' Check if we tried to set command timeout to an invalid value
         If objException.TargetSite.Name = "set_CommandTimeout" Then
            ' You can choose to have the user set a new timeout value,
            ' set it to the default value, or just leave it as it is as
            ' it hasn't changed
            ' ...
         End If
      End Try
   End Sub

   ' Listing 6-7
   Public Sub CheckCommandTypePropertyException()
      Dim cnnUserMan As MySqlConnection
      Dim cmmUserMan As MySqlCommand
      Dim strSQL As String

      Try
         ' Instantiate the connection
         cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Build query string
         strSQL = "SELECT * FROM tblUser"
         ' Instantiate the command
         cmmUserMan = New MySqlCommand(strSQL, cnnUserMan)
         ' Change command type
         cmmUserMan.CommandType = CommandType.TableDirect
      Catch objException As ArgumentException
         ' Check if tried to set command type to an invalid value
         If objException.TargetSite.Name = "set_CommandType" Then
            ' Perhaps ask the user, or since we know this is because
            ' we're trying to use a OLE DB .NET Data Provider only
            ' supported setting, we can change the SQL statement and 
            ' set the CommandType property to Text
            cmmUserMan.CommandType = CommandType.Text
            cmmUserMan.CommandText = "SELECT * FROM " & _
               cmmUserMan.CommandText
         End If
      End Try
   End Sub

   ' Listing 6-10
   Public Sub InstantiateParameterObject()
      Dim prmNoArguments As New MySqlParameter()
      Dim prmNameValueArguments As New MySqlParameter("Id", 3)
      Dim prmNameDataTypeArguments As New MySqlParameter("Id", SqlDbType.Int)
      Dim prmNameDataTypeSizeSourceColumnArguments As New MySqlParameter( _
         "LoginName", DbType.AnsiString, "LoginName")
   End Sub
End Module