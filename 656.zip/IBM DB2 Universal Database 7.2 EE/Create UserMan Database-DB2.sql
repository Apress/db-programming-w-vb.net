-- Drop existing UserMan database 
DROP DATABASE UserMan /

-- Create UserMan database 
CREATE DATABASE UserMan /

-- Connect to UserMan database 
CONNECT TO UserMan /

-- Create tables 
CREATE TABLE tblRights (
   Id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1) CONSTRAINT "PK_tblRights" PRIMARY KEY, 
   Name VARCHAR(50) NOT NULL,
   Description VARCHAR(255) NOT NULL) /

CREATE TABLE tblUser (
   Id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1) CONSTRAINT "PK_tblUser" PRIMARY KEY,
   ADName VARCHAR(100),
   ADSID VARCHAR(50),
   FirstName VARCHAR(50),
   LastName VARCHAR(50),
   LoginName VARCHAR(50) NOT NULL CONSTRAINT "IX_tblUser" UNIQUE,
   Password VARCHAR(50) NOT NULL DEFAULT 'password') /

CREATE TABLE tblLog (
   Id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1) CONSTRAINT "PK_tblLog" PRIMARY KEY, 
   Logged DATE NOT NULL,
   Description VARCHAR(255) NOT NULL,
   UserId INTEGER NOT NULL) /

CREATE TABLE tblUserRights (
   UserId INTEGER NOT NULL,
   RightsId INTEGER NOT NULL) /

-- Add two column PK to tblUserRights
ALTER TABLE tblUserRights ADD 
   CONSTRAINT PK_tblUserRights PRIMARY KEY (
      UserId,
      RightsId) /

-- Add foreign keys 
ALTER TABLE tblLog ADD 
   CONSTRAINT FK_tblLog_tblUser FOREIGN KEY (UserId) 
   REFERENCES tblUser (Id) 
   ON DELETE CASCADE /

ALTER TABLE tblUserRights ADD 
   CONSTRAINT "FK_tblUR_tblRights" FOREIGN KEY (RightsId) 
   REFERENCES tblRights (Id) ON DELETE CASCADE /
ALTER TABLE tblUserRights ADD 
   CONSTRAINT "FK_tblUR_tblUser" FOREIGN KEY (UserId) 
   REFERENCES tblUser (Id) ON DELETE CASCADE /

-- Create views 
CREATE VIEW viwUser
AS
SELECT Id, FirstName, LastName, LoginName
FROM tblUser /

CREATE VIEW viwUserInfo
AS
SELECT tblUser.LoginName, tblUser.LastName, tblUser.FirstName, tblRights.Name
FROM tblUser 
INNER JOIN tblRights ON tblUser.Id = tblRights.Id 
   INNER JOIN tblUserRights ON tblUser.Id = tblUserRights.UserId AND tblRights.Id = tblUserRights.RightsId /

-- Create stored procedures 
CREATE PROCEDURE SimpleStoredFunc()
LANGUAGE SQL
   RETURN (SELECT COUNT(*) FROM tblUser) /

CREATE PROCEDURE SimpleStoredProc(OUT strLastName VARCHAR(50))
   READS SQL DATA
   LANGUAGE SQL
BEGIN
   DECLARE v_LastName VARCHAR(50);
   SELECT LastName INTO v_LastName FROM tblUser WHERE Id=1;
   SET strLastName = v_LastName;
END /

CREATE PROCEDURE uspGetUsersByLastName(IN strLastName VARCHAR(50))
   DYNAMIC RESULT SETS 1
   LANGUAGE SQL
   BEGIN
      DECLARE UserCursor CURSOR WITH RETURN TO CALLER
          FOR SELECT * FROM tblUser
          WHERE LastName=strLastName;
      OPEN UserCursor;
   END /

-- Create trigger
CREATE TRIGGER tblUser_Update 
NO CASCADE BEFORE UPDATE ON tblUser 
REFERENCING NEW AS NEWUSER 
FOR EACH ROW MODE DB2SQL 
WHEN (NEWUSER.LastName IS NULL OR NEWUSER.FirstName IS NULL) 
   SIGNAL SQLSTATE '75002' ('You must supply both LastName and FirstName') /

-- Insert example data into tables 
INSERT INTO UserMan.tblUser (FirstName, LastName, LoginName, Password)
	VALUES ('John', 'Doe', 'UserMan', 'userman') /
INSERT INTO UserMan.tblUser (LoginName, Password)
	VALUES ('User1', 'password') /
INSERT INTO UserMan.tblUser (LoginName, Password)
	VALUES ('User2', 'password') /
INSERT INTO UserMan.tblUser (LoginName, Password)
	VALUES ('User3', 'password') /
INSERT INTO UserMan.tblUser (LoginName, Password)
	VALUES ('User99', 'password') /
INSERT INTO UserMan.tblRights (Name, Description)
	VALUES ('AddUser', 'Gives the user the right to add users to the database') /
INSERT INTO UserMan.tblRights (Name, Description)
	VALUES ('DeleteUser', 'Gives the user the right to delete users from the database') /
INSERT INTO UserMan.tblRights (Name, Description)
	VALUES ('ClearLog', 'Gives the user the right to clear the log') /
INSERT INTO UserMan.tblUserRights (UserId, RightsId)
	VALUES (1, 1) /
INSERT INTO UserMan.tblUserRights (UserId, RightsId)
	VALUES (1, 2) /
INSERT INTO UserMan.tblUserRights (UserId, RightsId)
	VALUES (1, 3) /