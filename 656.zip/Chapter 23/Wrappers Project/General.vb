Module General
   ' Listing 23-3-2
   Public Sub InstantiateMustInheritClass()
      'Dim objMustInherit As New CMustInherit()
   End Sub

   ' Listing 23-4-2
   Public Sub InstantiateMustInheritClassWrapper()
      Dim objMustInherit As New CWrapper()
   End Sub

   ' To be used with Listing 23-5
   Public Sub OverridePropertyInOverridableClass()
      Dim objOverridable As New CWrapper1()
   End Sub

   ' Listing 23-1-1
   Public Interface IUserMan
      Property TestProperty() As String
      Sub TestMethod()
   End Interface

   ' Listing 23-1-3
   Public Sub CreateUserManObject()
      Dim objUserMan As New CUserMan()
   End Sub
End Module