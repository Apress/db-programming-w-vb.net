' Listing 23-1-2
Public Class CUserMan
   Implements IUserMan

   Private prstrUserName As String

   Public Property UserName() As String _
      Implements IUserMan.TestProperty
      Get
         UserName = prstrUserName
      End Get

      Set(ByVal vstrUserName As String)
         prstrUserName = vstrUserName
      End Set
   End Property

   Public Sub CalculateOnlineTime() _
      Implements IUserMan.TestMethod
   End Sub
End Class