' Listing 23-4-1
Public Class CWrapper
   Inherits CMustInherit

End Class

' Listing 23-5-2
Public Class CWrapper1
   Inherits COverridable

   Private prstrTest As String

   Public Overrides Property Test() As String
      Get
         Test = prstrTest & "Overridden"
      End Get

      Set(ByVal vstrTest As String)
         prstrTest = vstrTest
      End Set
   End Property
End Class