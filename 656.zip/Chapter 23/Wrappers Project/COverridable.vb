' Listing 23-5-1
Public Class COverridable
   Private prstrTest As String

   Public Overridable Property Test() As String
      Get
         Test = prstrTest
      End Get

      Set(ByVal vstrTest As String)
         prstrTest = vstrTest
      End Set
   End Property
End Class