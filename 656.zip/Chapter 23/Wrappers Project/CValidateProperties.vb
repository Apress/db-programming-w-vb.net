Public Class CValidateProperties
   Private prstrTest As String

   Public Property Test() As String
      Get
         Test = prstrTest
      End Get

      ' Listing 23-2
      Set(ByVal vstrTest As String)
         ' Check if the string contains any invalid chars
         If vstrTest.IndexOf("@") = -1 Then
            prstrTest = vstrTest
         End If
      End Set
   End Property
End Class