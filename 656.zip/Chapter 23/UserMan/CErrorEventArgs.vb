' Listing 23-15
Public Class CErrorEventArgs
   Inherits EventArgs

   Public Enum ErrorStatusEnum As Integer
      NoError = 0
      ServerDown = 1
      TimeOut = 2
      InvalidLoginName = 3
   End Enum

   Private printErrorStatus As ErrorStatusEnum = ErrorStatusEnum.NoError
   Private prstrErrorMessage As String

   ' Class constructor
   Public Sub New(ByVal enuErrorStatus As ErrorStatusEnum)
      ' Save the error status
      printErrorStatus = enuErrorStatus

      ' Set the error message
      Select Case printErrorStatus
         Case ErrorStatusEnum.NoError
            prstrErrorMessage = "No error"
         Case ErrorStatusEnum.InvalidLoginName
            prstrErrorMessage = _
               "There are invalid characters in the LoginName!"
         Case ErrorStatusEnum.ServerDown
            prstrErrorMessage = _
               "The database server is currently unavailable!"
         Case ErrorStatusEnum.TimeOut
            prstrErrorMessage = _
               "A timeout connecting to the server has occurred!"
         Case Else
            prstrErrorMessage = "Unknown error!"
      End Select
   End Sub

   ' Returns the error status
   Public ReadOnly Property Status() As ErrorStatusEnum
      Get
         Return printErrorStatus
      End Get
   End Property

   ' Returns the error message
   Public ReadOnly Property Message() As String
      Get
         Return prstrErrorMessage
      End Get
   End Property
End Class