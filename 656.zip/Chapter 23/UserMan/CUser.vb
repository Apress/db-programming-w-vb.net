Public Class CUser
   ' Listing 23-14-1
   Implements IDisposable

   ' Listing 23-6
   ' User table column values
   Private prlngId As Long
   Private prstrADName As String
   Private prstrADSID As String
   Private prstrFirstName As String
   Private prstrLastName As String
   Private prstrLoginName As String
   Private prstrPassword As String

   ' Listing 23-9
   ' User table column max lengths
   Private printADNameMaxLen As Integer
   Private printADSIDMaxLen As Integer
   Private printFirstNameMaxLen As Integer
   Private printLastNameMaxLen As Integer
   Private printLoginNameMaxLen As Integer
   Private printPasswordMaxLen As Integer

   ' Listing 23-16
   ' Declare delegate for hooking up error notifications
   Public Delegate Sub ErrorEventHandler(ByVal sender As Object, _
      ByVal e As CErrorEventArgs)

   ' Listin 23-17
   Public Event OnError(ByVal sender As Object, _
      ByVal e As CErrorEventArgs)

   ' Listing 23-12
   Public Sub New()
      MyBase.New()
   End Sub

   ' Listing 23-13
   Protected Overrides Sub Finalize()
      ' Do your house keeping here
      ' ...
      ' Call the base class' destructor
      MyBase.Finalize()
   End Sub

   ' Listing 21-14-2
   Public Overloads Sub Dispose() Implements IDisposable.Dispose
      ' Do your house keeping here
      ' ...
      ' Now you need to make sure the Finalize method isn't
      ' called as well, because you've already done
      ' the house keeping
      GC.SuppressFinalize(Me)
      ' Always call this method on the base class, 
      ' if it implements one
      'MyBase.Dispose()
   End Sub

   ' Listing 23-7
   Public ReadOnly Property Id() As Long
      Get
         Return prlngId
      End Get
   End Property

   ' Listing 23-8 & Listing 23-10
   Public Property ADName() As String
      Get
         Return prstrADName
      End Get

      Set(ByVal vstrADName As String)
         If vstrADName.Length <= printADNameMaxLen Then
            prstrADName = vstrADName
         Else
            prstrADName = vstrADName.Substring(0, printADNameMaxLen)
         End If
      End Set
   End Property

   Public Property ADSID() As String
      Get
         Return prstrADSID
      End Get

      Set(ByVal vstrADSID As String)
         If vstrADSID.Length <= printADSIDMaxLen Then
            prstrADSID = vstrADSID
         Else
            prstrADSID = vstrADSID.Substring(0, printADSIDMaxLen)
         End If
      End Set
   End Property

   Public Property FirstName() As String
      Get
         Return prstrFirstName
      End Get

      Set(ByVal vstrFirstName As String)
         If vstrFirstName.Length <= printFirstNameMaxLen Then
            prstrFirstName = vstrFirstName
         Else
            prstrFirstName = vstrFirstName.Substring(0, printFirstNameMaxLen)
         End If
      End Set
   End Property

   Public Property LastName() As String
      Get
         Return prstrLastName
      End Get

      Set(ByVal vstrLastName As String)
         If vstrLastName.Length <= printLastNameMaxLen Then
            prstrLastName = vstrLastName
         Else
            prstrLastName = vstrLastName.Substring(0, printLastNameMaxLen)
         End If
      End Set
   End Property

   ' Listing 23-11
   Public Property LoginName() As String
      Get
         Return prstrLoginName
      End Get

      Set(ByVal vstrLoginName As String)
         ' Check if the string contains any spaces
         If vstrLoginName.IndexOf(" ") = -1 Then
            If vstrLoginName.Length <= printLoginNameMaxLen Then
               prstrLoginName = vstrLoginName
            Else
               prstrLoginName = vstrLoginName.Substring(0, printLoginNameMaxLen)
            End If
            ' Listing 23-20
         Else
            ' Instantiates the event source
            Dim objErrorEvent As New _
            CErrorEventArgs(CErrorEventArgs.ErrorStatusEnum.InvalidLoginName)
            ' Triggers the error event
            RaiseEvent OnError(Me, objErrorEvent)
         End If
      End Set
   End Property

   Public Property Password() As String
      Get
         Return prstrPassword
      End Get

      Set(ByVal vstrPassword As String)
         If vstrPassword.Length <= printPasswordMaxLen Then
            prstrPassword = vstrPassword
         Else
            prstrPassword = vstrPassword.Substring(0, printPasswordMaxLen)
         End If
      End Set
   End Property
End Class