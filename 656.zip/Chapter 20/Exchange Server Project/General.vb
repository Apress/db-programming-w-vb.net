Imports ADODB
Imports System.Data
Imports System.Data.OleDb
Imports System.Windows.Forms
imports System.Web.Mail

Module General
   ' Listing 20-1
   Public Sub SendMessageUsingCDOSYS()
      Dim msgMail As New MailMessage()

      ' Prepare message
      msgMail.From = "UserMan <userman@dotnetservices.biz>"
      msgMail.To = "Carsten Thomsen <carstent@dotnetservices.biz>"
      msgMail.Body = "This is the e-mail body"
      msgMail.Subject = "This is the e-mail subject"

      ' Set the SMTP server (you can use an IP address,
      ' NETBIOS name or a FQDN)
      SmtpMail.SmtpServer = "EXCHANGESERVER"
      SmtpMail.SmtpServer = "exchangeserver.userman.dk"
      SmtpMail.SmtpServer = "server"

      ' Send the prepared message using the 
      ' specified SMTP server
      SmtpMail.Send(msgMail)
   End Sub

   ' Listing 20-2
   ' This procedure must run on the machine that hosts Exchange Server
   Public Sub RetrieveContactsUsingExOLEDB()
      Dim cnnExchange As New ADODB.Connection()
      Dim rstExchange As New ADODB.RecordsetClass()
      Dim strFile As String = "file://./backofficestorage/userman.dk/mbx/userman"

      cnnExchange.Provider = "ExOLEDB.DataSource"

      Try
         ' Open the connection, keeping in mind that
         ' the ExOLEDB provider doesn't authenticate
         ' the passed user id and password arguments
         cnnExchange.Open(strFile, , , -1)
         ' Open the recordset
         rstExchange.Open("SELECT ""DAV:displayname"" AS Name " & _
            "FROM SCOPE('shallow traversal of ""Contacts""')", cnnExchange, _
            CursorTypeEnum.adOpenForwardOnly, LockTypeEnum.adLockReadOnly, 0)
         ' Loop through all the returned rows (contacts)
         While Not rstExchange.EOF
            ' Display Contact name
            MsgBox(rstExchange.Fields("Name").Value.ToString())
            ' Move to the next row
            rstExchange.MoveNext()
         End While
      Catch objE As Exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 20-3
   Public Sub MSDAIPPShowFolderProperties()
      Dim cnnExchange As New OleDbConnection()
      Dim cmmExchange As New OleDbCommand()
      Dim drdExchange As OleDbDataReader

      Dim strFolder As String
      Dim intColumn As Integer

      ' Setup connection string to bind to the userman folder
      cnnExchange.ConnectionString = "Provider=MSDAIPP.dso;Data Source=" & _
         "http://exchangeserver/exchange/userman;User ID='Administrator';Password=AdminPwd;"

      ' Open the connection
      cnnExchange.Open()
      ' Initialize the command
      cmmExchange.Connection = cnnExchange
      cmmExchange.CommandType = CommandType.TableDirect
      ' Return all rows
      drdExchange = cmmExchange.ExecuteReader()

      ' Loop through all the returned rows (folders)
      While drdExchange.Read()
         ' Initialize folder string
         strFolder = ""
         ' Loop through all the columns (properties)
         For intColumn = 0 To drdExchange.FieldCount - 1
            ' Read folder property name and value
            strFolder += drdExchange.GetName(intColumn) & _
               "=" & drdExchange(intColumn).ToString & vbCrLf
         Next

         ' Display folder properties
         MsgBox(strFolder)
      End While
   End Sub
End Module