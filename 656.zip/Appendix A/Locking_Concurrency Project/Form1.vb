Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnLockDataSourceRowsUsingTransactions As System.Windows.Forms.Button
   Friend WithEvents btnTriggerConcurrencyViolation As System.Windows.Forms.Button
   Friend WithEvents btnIgnoreConcurrencyViolations As System.Windows.Forms.Button
   Friend WithEvents btnHandleConcurrencyViolations As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnLockDataSourceRowsUsingTransactions = New System.Windows.Forms.Button()
      Me.btnTriggerConcurrencyViolation = New System.Windows.Forms.Button()
      Me.btnIgnoreConcurrencyViolations = New System.Windows.Forms.Button()
      Me.btnHandleConcurrencyViolations = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnLockDataSourceRowsUsingTransactions
      '
      Me.btnLockDataSourceRowsUsingTransactions.Location = New System.Drawing.Point(12, 12)
      Me.btnLockDataSourceRowsUsingTransactions.Name = "btnLockDataSourceRowsUsingTransactions"
      Me.btnLockDataSourceRowsUsingTransactions.Size = New System.Drawing.Size(337, 23)
      Me.btnLockDataSourceRowsUsingTransactions.TabIndex = 0
      Me.btnLockDataSourceRowsUsingTransactions.Text = "Lock Data Source Rows Using Transactions"
      '
      'btnTriggerConcurrencyViolation
      '
      Me.btnTriggerConcurrencyViolation.Location = New System.Drawing.Point(12, 40)
      Me.btnTriggerConcurrencyViolation.Name = "btnTriggerConcurrencyViolation"
      Me.btnTriggerConcurrencyViolation.Size = New System.Drawing.Size(337, 23)
      Me.btnTriggerConcurrencyViolation.TabIndex = 1
      Me.btnTriggerConcurrencyViolation.Text = "Trigger Concurrency Violation"
      '
      'btnIgnoreConcurrencyViolations
      '
      Me.btnIgnoreConcurrencyViolations.Location = New System.Drawing.Point(12, 68)
      Me.btnIgnoreConcurrencyViolations.Name = "btnIgnoreConcurrencyViolations"
      Me.btnIgnoreConcurrencyViolations.Size = New System.Drawing.Size(337, 23)
      Me.btnIgnoreConcurrencyViolations.TabIndex = 2
      Me.btnIgnoreConcurrencyViolations.Text = "Ignore Concurrency Violations"
      '
      'btnHandleConcurrencyViolations
      '
      Me.btnHandleConcurrencyViolations.Location = New System.Drawing.Point(12, 96)
      Me.btnHandleConcurrencyViolations.Name = "btnHandleConcurrencyViolations"
      Me.btnHandleConcurrencyViolations.Size = New System.Drawing.Size(337, 23)
      Me.btnHandleConcurrencyViolations.TabIndex = 3
      Me.btnHandleConcurrencyViolations.Text = "Handle Concurrency Violations"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(356, 133)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnHandleConcurrencyViolations, Me.btnIgnoreConcurrencyViolations, Me.btnTriggerConcurrencyViolation, Me.btnLockDataSourceRowsUsingTransactions})
      Me.Name = "Form1"
      Me.Text = "Locking_Concurrency Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnLockDataSourceRowsUsingTransactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLockDataSourceRowsUsingTransactions.Click
      LockDataSourceRowsUsingTransactions()
   End Sub

   Private Sub btnTriggerConcurrencyViolation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerConcurrencyViolation.Click
      TriggerConcurrencyViolation()
   End Sub

   Private Sub btnIgnoreConcurrencyViolations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIgnoreConcurrencyViolations.Click
      IgnoreConcurrencyViolations()
   End Sub

   Private Sub btnHandleConcurrencyViolations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHandleConcurrencyViolations.Click
      HandleConcurrencyViolations()
   End Sub
End Class
