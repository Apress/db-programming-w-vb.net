Imports System.Data.SqlClient

#Const Oracle = 0
#Const DB2 = 0
#Const SQLSERVER = 1

Module General
#If SQLSERVER Then
	' This connection string os for connecting to SQL Server
   ' You must change the Data Source value
   Public Const PR_STR_CONNECTION_STRING As String = _
      "Data Source=USERMANPC;User Id=UserMan;Password=userman;Initial Catalog=UserMan"
#ElseIf Oracle Then
   ' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN"
#ElseIf DB2 Then
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Listing A-1
   Public Sub LockDataSourceRowsUsingTransactions()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

      Dim cnnLocked, cnnUnlocked As SqlConnection
      Dim dadLocked, dadUnlocked As SqlDataAdapter
      Dim traUserMan As SqlTransaction
      Dim cmdSelectUsers As SqlCommand
      Dim dstLocked As New DataSet("Locked DataSet")
      Dim dstUnlocked As New DataSet("Unlocked DataSet")

      ' Instantiate and open the connections
      cnnLocked = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnLocked.Open()
      cnnUnlocked = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUnlocked.Open()
      ' Begin transaction
      traUserMan = cnnLocked.BeginTransaction(IsolationLevel.Serializable)
      ' Set up select command
      cmdSelectUsers = New SqlCommand(STR_SQL_USER_SELECT, cnnLocked, traUserMan)

      ' Instantiate and initialize data adapters
      dadLocked = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnLocked)
      dadLocked.SelectCommand = cmdSelectUsers
      dadUnlocked = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUnlocked)
      ' Declare and instantiate command builders
      Dim cmbUser1 As New SqlCommandBuilder(dadLocked)
      Dim cmbUser2 As New SqlCommandBuilder(dadUnlocked)

      ' Populate the data sets
      dadLocked.Fill(dstLocked, "tblUser")
      dadUnlocked.Fill(dstUnlocked, "tblUser")

      ' Update an existing row in unlocked data set
      dstUnlocked.Tables("tblUser").Rows(2)("FirstName") = "FirstName"

      Try
         ' Update the unlocked data source
         dadUnlocked.Update(dstUnlocked, "tblUser")
         ' Commit transaction
         traUserMan.Commit()
      Catch objE As SqlException
         ' Roll back transaction
         traUserMan.Rollback()
         MessageBox.Show(objE.Message)
      Finally
         ' Close connections
         cnnLocked.Close()
         cnnUnlocked.Close()
      End Try
   End Sub

   ' Listing A-2
   Public Sub TriggerConcurrencyViolation()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

      Dim cnnUser1, cnnUser2 As SqlConnection
      Dim dadUser1, dadUser2 As SqlDataAdapter
      Dim dstUser1 As New DataSet("User1 DataSet")
      Dim dstUser2 As New DataSet("User2 DataSet")

      ' Instantiate and open the connections
      cnnUser1 = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUser1.Open()
      cnnUser2 = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUser2.Open()

      ' Instantiate and initialize data adapters
      dadUser1 = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1)
      dadUser2 = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser2)
      Dim cmbUser1 As New SqlCommandBuilder(dadUser1)
      Dim cmbUser2 As New SqlCommandBuilder(dadUser2)

      ' Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser")
      dadUser2.Fill(dstUser2, "tblUser")

      ' Update an existing row in first data set
      dstUser1.Tables("tblUser").Rows(2)("FirstName") = "FirstName"
      ' Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser")
      ' Update an existing row in second data set
      dstUser2.Tables("tblUser").Rows(2)("ADName") = "ADName"

      Try
         ' Update the data source with changes to the second data set
         dadUser2.Update(dstUser2, "tblUser")

      Catch objE As DBConcurrencyException
         MessageBox.Show(objE.Message)
      Finally
         ' Close connections
         cnnUser1.Close()
         cnnUser2.Close()
      End Try
   End Sub

   ' Listing A-3
   Public Sub IgnoreConcurrencyViolations()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
      Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET ADName=@ADName, ADSID=@ADSID, FirstName=" & _
         "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id"

      Dim cmmUserUpdate1, cmmUserUpdate2 As SqlCommand
      Dim prmSQLUpdate As SqlParameter

      Dim cnnUser1 As SqlConnection
      Dim dadUser1, dadUser2 As SqlDataAdapter
      Dim dstUser1 As New DataSet("User DataSet1")
      Dim dstUser2 As New DataSet("User DataSet2")

      ' Instantiate and open the connection
      cnnUser1 = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUser1.Open()

      ' Instantiate the update commands
      cmmUserUpdate1 = New SqlCommand(STR_SQL_USER_UPDATE, cnnUser1)
      cmmUserUpdate2 = New SqlCommand(STR_SQL_USER_UPDATE, cnnUser1)

      ' Instantiate and initialize data adapters
      dadUser1 = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1)
      dadUser2 = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1)

      ' Set data adapters update command property
      dadUser1.UpdateCommand = cmmUserUpdate1
      dadUser2.UpdateCommand = cmmUserUpdate2

      ' Add Update command parameters
      cmmUserUpdate1.Parameters.Add("@ADName", SqlDbType.VarChar, 100, "ADName")
      cmmUserUpdate1.Parameters.Add("@ADSID", SqlDbType.VarChar, 50, "ADSID")
      cmmUserUpdate1.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
      cmmUserUpdate1.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
      cmmUserUpdate1.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
      cmmUserUpdate1.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")

      prmSQLUpdate = dadUser1.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 4, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original

      cmmUserUpdate2.Parameters.Add("@ADName", SqlDbType.VarChar, 100, "ADName")
      cmmUserUpdate2.Parameters.Add("@ADSID", SqlDbType.VarChar, 50, "ADSID")
      cmmUserUpdate2.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName")
      cmmUserUpdate2.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName")
      cmmUserUpdate2.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName")
      cmmUserUpdate2.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password")

      prmSQLUpdate = dadUser2.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 4, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original

      ' Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser")
      dadUser2.Fill(dstUser2, "tblUser")

      ' Update an existing row in first data set
      dstUser1.Tables("tblUser").Rows(2)("FirstName") = "FirstName"
      ' Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser")
      ' Update an existing row in second data set
      dstUser2.Tables("tblUser").Rows(2)("FirstName") = "FName"
      ' Update the data source with changes to the second data set
      dadUser2.Update(dstUser2, "tblUser")
   End Sub

   ' Listing A-4
   Public Sub HandleConcurrencyViolations()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

      Dim cnnUser1 As SqlConnection
      Dim dadUser1, dadUser2 As SqlDataAdapter
      Dim dstUser1 = New DataSet("User DataSet1")
      Dim dstUser2 = New DataSet("User DataSet2")

      ' Instantiate and open the connection
      cnnUser1 = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUser1.Open()

      ' Instantiate and initialize data adapters
      dadUser1 = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1)
      dadUser2 = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1)
      ' Declare and instantiate command builder
      Dim cmbUser1 As New SqlCommandBuilder(dadUser1)
      Dim cmbUser2 As New SqlCommandBuilder(dadUser2)

      ' Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser")
      dadUser2.Fill(dstUser2, "tblUser")

      ' Update an existing row in first data set
      dstUser1.Tables("tblUser").Rows(2)("FirstName") = "FirstName"
      ' Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser")
      ' Update an existing row in second data set
      dstUser2.Tables("tblUser").Rows(2)("FirstName") = "FName"

      Try
         ' Update the data source with changes to the second data set
         dadUser2.Update(dstUser2, "tblUser")
      Catch objE As DBConcurrencyException
         Dim objResult As MsgBoxResult
         Dim strCurrentDataSourceFirstName As String
         ' Instantiate command to find the current data source value
         Dim cmdCurrentDataSourceValue As New _
            SqlCommand("SELECT FirstName FROM tblUser WHERE Id=" & _
            objE.Row("Id", DataRowVersion.Original).ToString(), cnnUser1)

         ' Find current value in data source
         strCurrentDataSourceFirstName = CStr(cmdCurrentDataSourceValue.ExecuteScalar())

         ' Prompt the user about which value to save
         objResult = MsgBox("A concurrency violation exception was thrown when updating the source." & _
            "These are the values for the column in error:\n\n" & _
            "Original DataSet Value: " & objE.Row("FirstName", DataRowVersion.Original).ToString() & ControlChars.CrLf & _
            "Current Data Source Value: " & strCurrentDataSourceFirstName & ControlChars.CrLf & _
            "Current DataSet Value: " & objE.Row("FirstName", DataRowVersion.Current).ToString() & ControlChars.CrLf & _
            "Do you want to overwrite the current data source value?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, _
            "Concurrency Violation")
         ' Does the user want to overwrite the current data source value?
         If objResult = MsgBoxResult.Yes Then
            ' Merge the content of the data source with the dataset in error
            dstUser2.Merge(dstUser1, True)
            dadUser2.Update(dstUser2, "tblUser")
         End If
      Finally
         ' Close connection
         cnnUser1.Close()
      End Try
   End Sub
End Module