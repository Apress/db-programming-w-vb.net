Public Class frmUser
   Inherits System.Web.UI.Page

   Protected WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
   Protected WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
   Protected WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
   Protected WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
   Protected WithEvents objUser As WebFormDataBoundControls.User
   Protected WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
   Protected WithEvents OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter
   Protected WithEvents masterDataGrid As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
      Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.objUser = New WebFormDataBoundControls.User()
      Me.OleDbDataAdapter1 = New System.Data.OleDb.OleDbDataAdapter()
      CType(Me.objUser, System.ComponentModel.ISupportInitialize).BeginInit()
      '
      'OleDbSelectCommand1
      '
      Me.OleDbSelectCommand1.CommandText = "SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser"
      Me.OleDbSelectCommand1.Connection = Me.OleDbConnection1
      '
      'OleDbConnection1
      '
      Me.OleDbConnection1.ConnectionString = "Provider=SQLOLEDB.1;Password=userman;Persist Security Info=True;User ID=UserMan;I" & _
      "nitial Catalog=UserMan;Data Source=USERMANPC;Use Procedure for Prepare=1;Auto Trans" & _
      "late=True;Packet Size=4096;Workstation ID=WS1;Use Encryption for Data=False;Tag " & _
      "with column collation when possible=False"
      '
      'OleDbInsertCommand1
      '
      Me.OleDbInsertCommand1.CommandText = "INSERT INTO tblUser(ADName, ADSID, FirstName, LastName, LoginName, Password) VALU" & _
      "ES (?, ?, ?, ?, ?, ?); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName," & _
      " Password FROM tblUser WHERE (Id = @@IDENTITY)"
      Me.OleDbInsertCommand1.Connection = Me.OleDbConnection1
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, "ADName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.VarChar, 50, "ADSID"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, "FirstName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, "LastName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, "LoginName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, "Password"))
      '
      'OleDbUpdateCommand1
      '
      Me.OleDbUpdateCommand1.CommandText = "UPDATE tblUser SET ADName = ?, ADSID = ?, FirstName = ?, LastName = ?, LoginName " & _
      "= ?, Password = ? WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NULL" & _
      ") AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NULL" & _
      " AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AND" & _
      " (LoginName = ?) AND (Password = ?); SELECT Id, ADName, ADSID, FirstName, LastNa" & _
      "me, LoginName, Password FROM tblUser WHERE (Id = ?)"
      Me.OleDbUpdateCommand1.Connection = Me.OleDbConnection1
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, "ADName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.VarChar, 50, "ADSID"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, "FirstName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, "LastName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, "LoginName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, "Password"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Select_Id", System.Data.OleDb.OleDbType.Integer, 4, "Id"))
      '
      'OleDbDeleteCommand1
      '
      Me.OleDbDeleteCommand1.CommandText = "DELETE FROM tblUser WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NUL" & _
      "L) AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NUL" & _
      "L AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AN" & _
      "D (LoginName = ?) AND (Password = ?)"
      Me.OleDbDeleteCommand1.Connection = Me.OleDbConnection1
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
      '
      'objUser
      '
      Me.objUser.DataSetName = "User"
      Me.objUser.Locale = New System.Globalization.CultureInfo("da-DK")
      Me.objUser.Namespace = "http://www.tempuri.org/User.xsd"
      '
      'OleDbDataAdapter1
      '
      Me.OleDbDataAdapter1.DeleteCommand = Me.OleDbDeleteCommand1
      Me.OleDbDataAdapter1.InsertCommand = Me.OleDbInsertCommand1
      Me.OleDbDataAdapter1.SelectCommand = Me.OleDbSelectCommand1
      Me.OleDbDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "tblUser", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Id", "Id"), New System.Data.Common.DataColumnMapping("ADName", "ADName"), New System.Data.Common.DataColumnMapping("ADSID", "ADSID"), New System.Data.Common.DataColumnMapping("FirstName", "FirstName"), New System.Data.Common.DataColumnMapping("LastName", "LastName"), New System.Data.Common.DataColumnMapping("LoginName", "LoginName"), New System.Data.Common.DataColumnMapping("Password", "Password")})})
      Me.OleDbDataAdapter1.UpdateCommand = Me.OleDbUpdateCommand1
      CType(Me.objUser, System.ComponentModel.ISupportInitialize).EndInit()

   End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

   ' Listing 25-4
   Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Try
         Me.LoadDataSet()
         Me.masterDataGrid.SelectedIndex = -1
         Me.masterDataGrid.DataBind()
      Catch eLoad As System.Exception
         Me.Response.Write(eLoad.Message)
      End Try
   End Sub

   Private Sub buttonLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
      Try
         Me.LoadDataSet()
         Me.masterDataGrid.SelectedIndex = -1
         Me.masterDataGrid.DataBind()
      Catch eLoad As System.Exception
         Me.Response.Write(eLoad.Message)
      End Try
   End Sub

   Public Sub LoadDataSet()
      'Create a new dataset to hold the records returned from the call to FillDataSet.
      'A temporary dataset is used because filling the existing dataset would
      'require the databindings to be rebound.
      Dim objDataSetTemp As WebFormDataBoundControls.User
      objDataSetTemp = New WebFormDataBoundControls.User()
      Try
         'Attempt to fill the temporary dataset.
         Me.FillDataSet(objDataSetTemp)
      Catch eFillDataSet As System.Exception
         'Add your error handling code here.
         Throw eFillDataSet
      End Try
      Try
         'Empty the old records from the dataset.
         objUser.Clear()
         'Merge the records into the main dataset.
         objUser.Merge(objDataSetTemp)
      Catch eLoadMerge As System.Exception
         'Add your error handling code here.
         Throw eLoadMerge
      End Try
   End Sub

   Public Sub FillDataSet(ByVal dataSet As WebFormDataBoundControls.User)
      'Turn off constraint checking before the dataset is filled.
      'This allows the adapters to fill the dataset without concern
      'for dependencies between the tables.
      dataSet.EnforceConstraints = False
      Try
         'Open the connection.
         Me.OleDbConnection1.Open()
         'Attempt to fill the dataset through the OleDbDataAdapter1.
         Me.OleDbDataAdapter1.Fill(dataSet)
      Catch fillException As System.Exception
         'Add your error handling code here.
         Throw fillException
      Finally
         'Turn constraint checking back on.
         dataSet.EnforceConstraints = True
         'Close the connection whether or not the exception was thrown.
         Me.OleDbConnection1.Close()
      End Try
   End Sub

   ' Listing 25-2
   Private Sub masterDataGrid_CancelCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles masterDataGrid.CancelCommand
      masterDataGrid.EditItemIndex = -1
      masterDataGrid.DataBind()
   End Sub

   ' Listing 25-1
   Private Sub masterDataGrid_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles masterDataGrid.EditCommand
      LoadDataSet()
      masterDataGrid.EditItemIndex = e.Item.ItemIndex
      masterDataGrid.DataBind()
   End Sub

   ' Listing 25-3
   Private Sub masterDataGrid_UpdateCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles masterDataGrid.UpdateCommand
      Dim drwUser As User.tblUserRow
      Dim txtEdit As TextBox
      Dim intKey As Integer

      ' Save the key field of edited row
      intKey = CInt(masterDataGrid.DataKeys(e.Item.ItemIndex))

      ' Locate the row in the the dataset that has been edited
      ' by using the saved key as an argument for the FindById
      ' procedure
      drwUser = objUser.tblUser.FindById(intKey)

      ' Update the DataSet with the changed values, through
      ' the located data row
      txtEdit = CType(e.Item.Cells(1).Controls(0), TextBox)
      drwUser.ADName = txtEdit.Text
      txtEdit = CType(e.Item.Cells(2).Controls(0), TextBox)
      drwUser.ADSID = txtEdit.Text
      txtEdit = CType(e.Item.Cells(3).Controls(0), TextBox)
      drwUser.FirstName = txtEdit.Text
      txtEdit = CType(e.Item.Cells(4).Controls(0), TextBox)
      drwUser.LastName = txtEdit.Text
      txtEdit = CType(e.Item.Cells(5).Controls(0), TextBox)
      drwUser.LoginName = txtEdit.Text
      txtEdit = CType(e.Item.Cells(6).Controls(0), TextBox)
      drwUser.Password = txtEdit.Text

      ' Update the data source
      OleDbDataAdapter1.Update(objUser)

      ' Take the DataGrid out of editing mode and rebind
      masterDataGrid.EditItemIndex = -1
      masterDataGrid.DataBind()
   End Sub
End Class