Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnInstantiateDataReaderObject As System.Windows.Forms.Button
   Friend WithEvents btnReadRowsFromDataReader As System.Windows.Forms.Button
   Friend WithEvents btnCheckForNullValueInColumn As System.Windows.Forms.Button
   Friend WithEvents btnReadImageFromDataReader As System.Windows.Forms.Button
   Friend WithEvents btnExtractColumnInformation As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnInstantiateDataReaderObject = New System.Windows.Forms.Button()
      Me.btnReadRowsFromDataReader = New System.Windows.Forms.Button()
      Me.btnCheckForNullValueInColumn = New System.Windows.Forms.Button()
      Me.btnReadImageFromDataReader = New System.Windows.Forms.Button()
      Me.btnExtractColumnInformation = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnInstantiateDataReaderObject
      '
      Me.btnInstantiateDataReaderObject.Location = New System.Drawing.Point(18, 27)
      Me.btnInstantiateDataReaderObject.Name = "btnInstantiateDataReaderObject"
      Me.btnInstantiateDataReaderObject.Size = New System.Drawing.Size(202, 23)
      Me.btnInstantiateDataReaderObject.TabIndex = 1
      Me.btnInstantiateDataReaderObject.Text = "Instantiate DataReader Object"
      '
      'btnReadRowsFromDataReader
      '
      Me.btnReadRowsFromDataReader.Location = New System.Drawing.Point(18, 56)
      Me.btnReadRowsFromDataReader.Name = "btnReadRowsFromDataReader"
      Me.btnReadRowsFromDataReader.Size = New System.Drawing.Size(202, 23)
      Me.btnReadRowsFromDataReader.TabIndex = 2
      Me.btnReadRowsFromDataReader.Text = "Read Rows From DataReader"
      '
      'btnCheckForNullValueInColumn
      '
      Me.btnCheckForNullValueInColumn.Location = New System.Drawing.Point(18, 84)
      Me.btnCheckForNullValueInColumn.Name = "btnCheckForNullValueInColumn"
      Me.btnCheckForNullValueInColumn.Size = New System.Drawing.Size(202, 23)
      Me.btnCheckForNullValueInColumn.TabIndex = 3
      Me.btnCheckForNullValueInColumn.Text = "Check For Null Value In Column"
      '
      'btnReadImageFromDataReader
      '
      Me.btnReadImageFromDataReader.Location = New System.Drawing.Point(18, 112)
      Me.btnReadImageFromDataReader.Name = "btnReadImageFromDataReader"
      Me.btnReadImageFromDataReader.Size = New System.Drawing.Size(202, 23)
      Me.btnReadImageFromDataReader.TabIndex = 4
      Me.btnReadImageFromDataReader.Text = "Read Image From DataReader"
      '
      'btnExtractColumnInformation
      '
      Me.btnExtractColumnInformation.Location = New System.Drawing.Point(18, 140)
      Me.btnExtractColumnInformation.Name = "btnExtractColumnInformation"
      Me.btnExtractColumnInformation.Size = New System.Drawing.Size(202, 23)
      Me.btnExtractColumnInformation.TabIndex = 5
      Me.btnExtractColumnInformation.Text = "Extract Column Information"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(241, 183)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnExtractColumnInformation, Me.btnReadImageFromDataReader, Me.btnCheckForNullValueInColumn, Me.btnReadRowsFromDataReader, Me.btnInstantiateDataReaderObject})
      Me.Name = "Form1"
      Me.Text = "OleDbDataReader Project"
      Me.ResumeLayout(False)

   End Sub

#End Region


   Private Sub btnInstantiateDataReaderObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataReaderObject.Click
      InstantiateDataReader()
   End Sub

   Private Sub btnReadRowsFromDataReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadRowsFromDataReader.Click
      ReadRowsFromDataReader()
   End Sub

   Private Sub btnCheckForNullValueInColumn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckForNullValueInColumn.Click
      CheckForNullValueInColumn(0)
   End Sub

   Private Sub btnReadImageFromDataReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReadImageFromDataReader.Click
      'ReadImageFromDataReader(6)
      ReadImageFromDataReaderInChunks(6)
   End Sub

   Private Sub btnExtractColumnInformation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExtractColumnInformation.Click
      ExtractColumnInformation()
   End Sub
End Class