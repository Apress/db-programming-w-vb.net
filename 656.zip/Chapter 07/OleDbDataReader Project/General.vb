Option Strict On

Imports System.Data.OleDb
Imports System.Xml
Imports ADODB
Imports System.IO

'#Const Oracle = 1
'#Const DB2 = 1
#Const MSAccess = 1
'#Const SQLSERVER = 1
' You simply uncomment the line above for the DBMS you want to use

Module General
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = "Provider=SQLOLEDB;Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
#ElseIf MSAccess Then
   ' This connection string os for connecting to an Access mdb
   ' I'm not using any security, hence the blank User Id and password. I'm also
   ' Opening the mdb in shared mode. You must edit the path to your database file
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\DBPWVBNET\UserMan.mdb;" & _
      "Mode=Share Deny None;"
#ElseIf Oracle Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
	Private Const PR_STR_CONNECTION_STRING as String  = _
		"Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#ElseIf DB2 Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Listing 7-1
   Public Sub InstantiateDataReader()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim drdUserMan As OleDbDataReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      ' Instantiate data reader using the ExecuteReader method 
      ' of the command class
      drdUserMan = cmmUserMan.ExecuteReader()
   End Sub

   ' Listing 7-2
   Public Sub ReadRowsFromDataReader()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim drdUser As OleDbDataReader
      Dim strSQL As String
      Dim lngCounter As Long = 0

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      ' Execute command and return rows in data reader
      drdUser = cmmUserMan.ExecuteReader()
      ' Loop through all the returned rows
      Do While drdUser.Read
         ' Display Id of current row
         MsgBox(drdUser.GetInt32(0).ToString)
         ' Increment number of rows
         lngCounter = lngCounter + 1
      Loop

      ' Display the number of rows returned
      MsgBox(CStr(lngCounter))
   End Sub

   ' Listing 7-3
   Public Sub CheckForNullValueInColumn(ByVal intColumn As Integer)
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim drdUser As OleDbDataReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      ' Execute command and return rows in data reader
      drdUser = cmmUserMan.ExecuteReader()
      ' Advance reader to first row
      drdUser.Read()
      ' Check if the column contains a NULL value
      If drdUser.IsDBNull(intColumn) Then
         MsgBox("Column " & CStr(intColumn) & " contains a NULL value!")
      Else
         MsgBox("Column " & CStr(intColumn) & " does not contain a NULL value!")
      End If
   End Sub

   ' Listing 7-4
   Public Sub ReadImageFromDataReader(ByVal intImageId As Integer)
      Dim cnnImage As OleDbConnection
      Dim cmmImage As OleDbCommand
      Dim drdTest As OleDbDataReader
      Dim strSQL As String
      Dim fstImage As FileStream
      Dim bwrTest As BinaryWriter
      Dim lngTotalNumBytes As Long
      Dim strFileName As String = "Image.bmp"

      ' Instantiate the connection
      cnnImage = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnImage.Open()
      ' Build query string
      strSQL = "SELECT Picture FROM tblImage WHERE Id=" & intImageId.ToString()
      ' Instantiate the command
      cmmImage = New OleDbCommand(strSQL, cnnImage)
      ' Execute command and return row in data reader
      drdTest = cmmImage.ExecuteReader(CommandBehavior.SequentialAccess)

      ' Check if a row was returned
      If drdTest.Read() Then
         ' Get size of image
         lngTotalNumBytes = drdTest.GetBytes(0, 0, Nothing, 0, Integer.MaxValue)

         ' Create a new file to hold the output
         fstImage = New FileStream(strFileName, FileMode.CreateNew, FileAccess.Write)
         bwrTest = New BinaryWriter(fstImage)

         ' Create byte array with the exact size of the picture
         Dim arrbytImage(CInt(lngTotalNumBytes)) As Byte
         ' Save picture in byte array
         drdTest.GetBytes(0, 0, arrbytImage, 0, CInt(lngTotalNumBytes))

         ' Write the buffer to file
         bwrTest.Write(arrbytImage)
         bwrTest.Flush()

         ' Close the output file
         bwrTest.Close()
         fstImage.Close()
      End If

      ' Close connection
      cnnImage.Close()
   End Sub

   ' Listing 7-5
   Public Sub ReadImageFromDataReaderInChunks(ByVal intImageId As Integer)
      Const INT_IMAGE_BUFFER_SIZE As Integer = 128

      Dim cnnImage As OleDbConnection
      Dim cmmImage As OleDbCommand
      Dim drdTest As OleDbDataReader
      Dim strSQL As String
      Dim fstImage As FileStream
      Dim bwrTest As BinaryWriter
      Dim lngTotalNumBytes As Long
      Dim strFileName As String = "Image.bmp"
      Dim lngNumBytesReturned As Long
      Dim arrbytImage(INT_IMAGE_BUFFER_SIZE - 1) As Byte
      Dim intImagePos As Integer = 0

      ' Instantiate the connection
      cnnImage = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnImage.Open()
      ' Build query string
      strSQL = "SELECT Picture FROM tblImage WHERE PictureId=" & intImageId.ToString()
      ' Instantiate the command
      cmmImage = New OleDbCommand(strSQL, cnnImage)
      ' Execute command and return row in data reader
      drdTest = cmmImage.ExecuteReader(CommandBehavior.SequentialAccess)

      ' Create a new file to hold the output
      fstImage = New FileStream(strFileName, FileMode.CreateNew, FileAccess.Write)
      bwrTest = New BinaryWriter(fstImage)

      ' Check if a row was returned
      If drdTest.Read() Then
         ' Save image chunk in byte array and save the number of bytes returned
         lngNumBytesReturned = drdTest.GetBytes(0, 0, arrbytImage, 0, _
            INT_IMAGE_BUFFER_SIZE)

         ' Keep reading chunks of the image until only the last chunk remains
         Do While lngNumBytesReturned = INT_IMAGE_BUFFER_SIZE
            bwrTest.Write(arrbytImage)
            bwrTest.Flush()

            ' Move the position of where the image should be read from to the 
            ' byte following the last byte read
            intImagePos = intImagePos + INT_IMAGE_BUFFER_SIZE
            ' Save image chunk in byte array and save the number of bytes returned
            lngNumBytesReturned = drdTest.GetBytes(0, intImagePos, _
               arrbytImage, 0, INT_IMAGE_BUFFER_SIZE)
         Loop

         ' Write the remaining buffer
         bwrTest.Write(arrbytImage)
         bwrTest.Flush()

         ' Close the output file
         bwrTest.Close()
         fstImage.Close()
      End If

      ' Close connection
      cnnImage.Close()
   End Sub

   ' Listing 7-6
   Public Sub ExtractColumnInformation()
      Dim cnnUserMan As OleDbConnection
      Dim cmmUserMan As OleDbCommand
      Dim drdUserMan As OleDbDataReader
      Dim dtbUser As DataTable
      Dim dtcColumnInfo As DataColumn
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OleDbCommand(strSQL, cnnUserMan)
      ' Instantiate data reader using the ExecuteReader method 
      ' of the command class and return column information only
      drdUserMan = cmmUserMan.ExecuteReader(CommandBehavior.SchemaOnly)
      ' Save the column information to a DataTable
      dtbUser = drdUserMan.GetSchemaTable()

      ' Display some column information
      MsgBox("Name = " & dtbUser.Rows(0)("ColumnName").ToString() & vbCrLf & _
         "Ordinal = " & dtbUser.Rows(0)("ColumnOrdinal").ToString() & vbCrLf & _
         "Size = " & dtbUser.Rows(0)("ColumnSize").ToString() & vbCrLf & _
         "Data Type = " & dtbUser.Rows(0)("DataType").ToString() & vbCrLf & _
         "Key = " & dtbUser.Rows(0)("IsKey").ToString(), _
         MsgBoxStyle.Information, "Column Information")
   End Sub
End Module