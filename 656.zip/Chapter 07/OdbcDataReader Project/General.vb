Option Strict On

Imports Microsoft.Data.Odbc
Imports System.IO

#Const MySQL = 1
'#Const Oracle = 1
'#Const MSAccess = 1
'#Const SQLSERVER = 1
'#Const DB2 = 1
' You simply uncomment the line above for the DBMS you want to use

Module General
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = "DRIVER={SQL Server};SERVER=USERMANPC;" & _
      "UID=UserMan;PWD=userman;DATABASE=UserMan"
#ElseIf MSAccess Then
	' This connection string os for connecting to an Access mdb
   ' I'm not using any security, hence no specification of User Id and password. 
   ' You must edit the path to your database file
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={Microsoft Access Driver (*.mdb)};DBQ=C:\DBPWVBNET\UserMan.mdb;"
#ElseIf MySQL Then
   ' This connection string os for connecting to MySQL 3.23.49 or later
   ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={MySQL};SERVER=10.8.1.32;UID=UserMan;PWD=userman;DATABASE=UserMan"
#ElseIf Oracle Then
	' This connection string os for connecting to Oracle
   ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={Microsoft ODBC for Oracle};PWD=userman;UID=USERMAN;SERVER=USERMAN"
#ElseIf DB2 Then
   ' This connection string os for connecting to IBM DB2 Universal Database 7.2 EE
   ' You must change the DBALIAS value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={IBM DB2 ODBC DRIVER};PWD=userman;UID=USERMAN;DBALIAS=USERMAN;"
#End If

   ' Listing 7-1
   Public Sub InstantiateDataReader()
      Dim cnnUserMan As OdbcConnection
      Dim cmmUserMan As OdbcCommand
      Dim drdUserMan As OdbcDataReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OdbcCommand(strSQL, cnnUserMan)
      ' Instantiate data reader using the ExecuteReader method 
      ' of the command class
      drdUserMan = cmmUserMan.ExecuteReader()
   End Sub

   ' Listing 7-2
   Public Sub ReadRowsFromDataReader()
      Dim cnnUserMan As OdbcConnection
      Dim cmmUserMan As OdbcCommand
      Dim drdUser As OdbcDataReader
      Dim strSQL As String
      Dim lngCounter As Long = 0

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OdbcCommand(strSQL, cnnUserMan)
      ' Execute command and return rows in data reader
      drdUser = cmmUserMan.ExecuteReader()
      ' Loop through all the returned rows
      Do While drdUser.Read
         ' Display Id of current row
         MsgBox(drdUser.GetInt32(0).ToString)
         ' Increment number of rows
         lngCounter = lngCounter + 1
      Loop

      ' Display the number of rows returned
      MsgBox(CStr(lngCounter))
   End Sub

   ' Listing 7-3
   Public Sub CheckForNullValueInColumn(ByVal intColumn As Integer)
      Dim cnnUserMan As OdbcConnection
      Dim cmmUserMan As OdbcCommand
      Dim drdUser As OdbcDataReader
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OdbcCommand(strSQL, cnnUserMan)
      ' Execute command and return rows in data reader
      drdUser = cmmUserMan.ExecuteReader()
      ' Advance reader to first row
      drdUser.Read()
      ' Check if the column contains a NULL value
      If drdUser.IsDBNull(intColumn) Then
         MsgBox("Column " & CStr(intColumn) & " contains a NULL value!")
      Else
         MsgBox("Column " & CStr(intColumn) & " does not contain a NULL value!")
      End If
   End Sub

   ' Listing 7-4
   Public Sub ReadImageFromDataReader(ByVal intImageId As Integer)
      Dim cnnImage As OdbcConnection
      Dim cmmImage As OdbcCommand
      Dim drdTest As OdbcDataReader
      Dim strSQL As String
      Dim fstImage As FileStream
      Dim bwrTest As BinaryWriter
      Dim lngTotalNumBytes As Long
      Dim strFileName As String = "Image.bmp"

      ' Instantiate the connection
      cnnImage = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnImage.Open()
      ' Build query string
      strSQL = "SELECT Picture FROM tblImage WHERE Id=" & intImageId.ToString()
      ' Instantiate the command
      cmmImage = New OdbcCommand(strSQL, cnnImage)
      ' Execute command and return row in data reader
      drdTest = cmmImage.ExecuteReader(CommandBehavior.SequentialAccess)

      ' Check if a row was returned
      If drdTest.Read() Then
         ' Get size of image
         lngTotalNumBytes = drdTest.GetBytes(0, 0, Nothing, 0, Integer.MaxValue)

         ' Create a new file to hold the output
         fstImage = New FileStream(strFileName, FileMode.CreateNew, FileAccess.Write)
         bwrTest = New BinaryWriter(fstImage)

         ' Create byte array with the exact size of the picture
         Dim arrbytImage(CInt(lngTotalNumBytes)) As Byte
         ' Save picture in byte array
         drdTest.GetBytes(0, 0, arrbytImage, 0, CInt(lngTotalNumBytes))

         ' Write the buffer to file
         bwrTest.Write(arrbytImage)
         bwrTest.Flush()

         ' Close the output file
         bwrTest.Close()
         fstImage.Close()
      End If

      ' Close connection
      cnnImage.Close()
   End Sub

   ' Listing 7-5
   Public Sub ReadImageFromDataReaderInChunks(ByVal intImageId As Integer)
      Const INT_IMAGE_BUFFER_SIZE As Integer = 128

      Dim cnnImage As OdbcConnection
      Dim cmmImage As OdbcCommand
      Dim drdTest As OdbcDataReader
      Dim strSQL As String
      Dim fstImage As FileStream
      Dim bwrTest As BinaryWriter
      Dim lngTotalNumBytes As Long
      Dim strFileName As String = "Image.bmp"
      Dim lngNumBytesReturned As Long
      Dim arrbytImage(INT_IMAGE_BUFFER_SIZE - 1) As Byte
      Dim intImagePos As Integer = 0

      ' Instantiate the connection
      cnnImage = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnImage.Open()
      ' Build query string
      strSQL = "SELECT Picture FROM tblImage WHERE Id=" & intImageId.ToString()
      ' Instantiate the command
      cmmImage = New OdbcCommand(strSQL, cnnImage)
      ' Execute command and return row in data reader
      drdTest = cmmImage.ExecuteReader(CommandBehavior.SequentialAccess)

      ' Create a new file to hold the output
      fstImage = New FileStream(strFileName, FileMode.CreateNew, FileAccess.Write)
      bwrTest = New BinaryWriter(fstImage)

      ' Check if a row was returned
      If drdTest.Read() Then
         ' Save image chunk in byte array and save the number of bytes returned
         lngNumBytesReturned = drdTest.GetBytes(0, 0, arrbytImage, 0, _
            INT_IMAGE_BUFFER_SIZE)

         ' Keep reading chunks of the image until only the last chunk remains
         Do While lngNumBytesReturned = INT_IMAGE_BUFFER_SIZE
            bwrTest.Write(arrbytImage)
            bwrTest.Flush()

            ' Move the position of where the image should be read from to the 
            ' byte following the last byte read
            intImagePos = intImagePos + INT_IMAGE_BUFFER_SIZE
            ' Save image chunk in byte array and save the number of bytes returned
            lngNumBytesReturned = drdTest.GetBytes(0, intImagePos, _
               arrbytImage, 0, INT_IMAGE_BUFFER_SIZE)
         Loop

         ' Write the remaining buffer
         bwrTest.Write(arrbytImage)
         bwrTest.Flush()

         ' Close the output file
         bwrTest.Close()
         fstImage.Close()
      End If

      ' Close connection
      cnnImage.Close()
   End Sub

   ' Listing 7-6
   Public Sub ExtractColumnInformation()
      Dim cnnUserMan As OdbcConnection
      Dim cmmUserMan As OdbcCommand
      Dim drdUserMan As OdbcDataReader
      Dim dtbUser As DataTable
      Dim dtcColumnInfo As DataColumn
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build query string
      strSQL = "SELECT * FROM tblUser"
      ' Instantiate the command
      cmmUserMan = New OdbcCommand(strSQL, cnnUserMan)
      ' Instantiate data reader using the ExecuteReader method 
      ' of the command class and return column information only
      drdUserMan = cmmUserMan.ExecuteReader(CommandBehavior.KeyInfo)
      ' Save the column information to a DataTable
      dtbUser = drdUserMan.GetSchemaTable()

      ' Display some column information
      MsgBox("Name = " & dtbUser.Rows(0)("ColumnName").ToString() & vbCrLf & _
         "Ordinal = " & dtbUser.Rows(0)("ColumnOrdinal").ToString() & vbCrLf & _
         "Size = " & dtbUser.Rows(0)("ColumnSize").ToString() & vbCrLf & _
         "Data Type = " & dtbUser.Rows(0)("DataType").ToString() & vbCrLf & _
         "Key = " & dtbUser.Rows(0)("IsKey").ToString(), _
         MsgBoxStyle.Information, "Column Information")
   End Sub
End Module