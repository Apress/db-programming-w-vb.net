Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnTestDebugAssert As System.Windows.Forms.Button
   Friend WithEvents btnTestDebugFail As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnTestDebugAssert = New System.Windows.Forms.Button()
      Me.btnTestDebugFail = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnTestDebugAssert
      '
      Me.btnTestDebugAssert.Location = New System.Drawing.Point(13, 17)
      Me.btnTestDebugAssert.Name = "btnTestDebugAssert"
      Me.btnTestDebugAssert.Size = New System.Drawing.Size(264, 23)
      Me.btnTestDebugAssert.TabIndex = 0
      Me.btnTestDebugAssert.Text = "Test Debug Assert"
      '
      'btnTestDebugFail
      '
      Me.btnTestDebugFail.Location = New System.Drawing.Point(14, 46)
      Me.btnTestDebugFail.Name = "btnTestDebugFail"
      Me.btnTestDebugFail.Size = New System.Drawing.Size(264, 23)
      Me.btnTestDebugFail.TabIndex = 1
      Me.btnTestDebugFail.Text = "Test Debug Fail"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(292, 266)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnTestDebugFail, Me.btnTestDebugAssert})
      Me.Name = "Form1"
      Me.Text = "Debug_Trace Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnTestDebugAssert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestDebugAssert.Click
      TestDebugAssert()
   End Sub

   Private Sub btnTestDebugFail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestDebugFail.Click
      TestDebugFail()
   End Sub
End Class
