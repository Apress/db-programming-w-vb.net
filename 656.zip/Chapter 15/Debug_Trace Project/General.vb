#Const DEBUG = True

Imports System.Diagnostics

Module General
   Public Const STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   Private Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

   ' Listing 15-1
   Public Sub TestDebugAssert()
      Dim dstUser As New DataSet()
      Dim dstLog As New DataSet()

      Try
         ' Do your stuff
         ' ...
         ' Destroy Log dataset
         dstLog.Dispose()
         dstLog = Nothing
         ' This obviously throws the
         ' NullReferenceException exception
         MsgBox(dstLog.DataSetName)
      Catch objNullReference As NullReferenceException
         ' Check if both our object instances are null
         Debug.Assert((dstUser Is Nothing And dstLog Is Nothing), _
            "Assert Message")
      Catch objE As Exception
         ' Handle all other exceptions here
      End Try
   End Sub

   ' Listing 15-2
   Public Sub TestDebugFail()
      Try
         ' Do your stuff here
         ' ...
         Throw New Exception("I'm not really expected!")
      Catch objNullReference As NullReferenceException
         ' Handle the NullReferenceException here
      Catch objIndexOutOfRange As IndexOutOfRangeException
         ' Handle the IndexOutOfRangeException here
      Catch objE As Exception
         Debug.Fail("Fail Message", _
            "An unexpected exception has been thrown." & _
            vbCrLf & vbCrLf & objE.Message)
      End Try
   End Sub
End Module