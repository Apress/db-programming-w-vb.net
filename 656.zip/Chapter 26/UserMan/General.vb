Module General
   ' This is the admin User object for administrating other users
   Public objAdminUser As New CUser()
   ' This object holds the details for the user being "administrated"
   Public objUser As CUser
   ' Is the user logged on?
   Public LoggedOn As Boolean = False
End Module