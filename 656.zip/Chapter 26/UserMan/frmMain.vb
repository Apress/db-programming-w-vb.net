Public Class frmMain
   Inherits System.Windows.Forms.Form

   Dim frmProp As frmProperties

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents lblUserManWebSite As System.Windows.Forms.LinkLabel
   Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
   Friend WithEvents mnuAdmin As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminProperties As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminLogOn As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminLogOff As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminExit As System.Windows.Forms.MenuItem
   Friend WithEvents mnuUser As System.Windows.Forms.MenuItem
   Friend WithEvents mnuUserViewAll As System.Windows.Forms.MenuItem
   Friend WithEvents mnuUserADInfo As System.Windows.Forms.MenuItem
   Friend WithEvents mnuWindow As System.Windows.Forms.MenuItem
   Friend WithEvents mnuWindowArrangeAll As System.Windows.Forms.MenuItem
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
      Me.lblUserManWebSite = New System.Windows.Forms.LinkLabel()
      Me.mnuMain = New System.Windows.Forms.MainMenu()
      Me.mnuAdmin = New System.Windows.Forms.MenuItem()
      Me.mnuAdminProperties = New System.Windows.Forms.MenuItem()
      Me.menuItem1 = New System.Windows.Forms.MenuItem()
      Me.mnuAdminLogOn = New System.Windows.Forms.MenuItem()
      Me.mnuAdminLogOff = New System.Windows.Forms.MenuItem()
      Me.menuItem2 = New System.Windows.Forms.MenuItem()
      Me.mnuAdminExit = New System.Windows.Forms.MenuItem()
      Me.mnuUser = New System.Windows.Forms.MenuItem()
      Me.mnuUserViewAll = New System.Windows.Forms.MenuItem()
      Me.mnuUserADInfo = New System.Windows.Forms.MenuItem()
      Me.mnuWindow = New System.Windows.Forms.MenuItem()
      Me.mnuWindowArrangeAll = New System.Windows.Forms.MenuItem()
      Me.SuspendLayout()
      '
      'lblUserManWebSite
      '
      Me.lblUserManWebSite.AccessibleRole = System.Windows.Forms.AccessibleRole.Link
      Me.lblUserManWebSite.Anchor = System.Windows.Forms.AnchorStyles.None
      Me.lblUserManWebSite.BackColor = System.Drawing.SystemColors.AppWorkspace
      Me.lblUserManWebSite.CausesValidation = False
      Me.lblUserManWebSite.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.lblUserManWebSite.Image = CType(resources.GetObject("lblUserManWebSite.Image"), System.Drawing.Bitmap)
      Me.lblUserManWebSite.Location = New System.Drawing.Point(278, 195)
      Me.lblUserManWebSite.Name = "lblUserManWebSite"
      Me.lblUserManWebSite.Size = New System.Drawing.Size(172, 75)
      Me.lblUserManWebSite.TabIndex = 3
      Me.lblUserManWebSite.TabStop = True
      Me.lblUserManWebSite.Text = "http://www.userman.dk"
      Me.lblUserManWebSite.TextAlign = System.Drawing.ContentAlignment.BottomCenter
      Me.lblUserManWebSite.UseMnemonic = False
      '
      'mnuMain
      '
      Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdmin, Me.mnuUser, Me.mnuWindow})
      '
      'mnuAdmin
      '
      Me.mnuAdmin.Index = 0
      Me.mnuAdmin.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdminProperties, Me.menuItem1, Me.mnuAdminLogOn, Me.mnuAdminLogOff, Me.menuItem2, Me.mnuAdminExit})
      Me.mnuAdmin.MergeType = System.Windows.Forms.MenuMerge.MergeItems
      Me.mnuAdmin.Text = "&Admin"
      '
      'mnuAdminProperties
      '
      Me.mnuAdminProperties.Enabled = False
      Me.mnuAdminProperties.Index = 0
      Me.mnuAdminProperties.MergeType = System.Windows.Forms.MenuMerge.MergeItems
      Me.mnuAdminProperties.Text = "&Properties..."
      '
      'menuItem1
      '
      Me.menuItem1.Index = 1
      Me.menuItem1.Text = "-"
      '
      'mnuAdminLogOn
      '
      Me.mnuAdminLogOn.Index = 2
      Me.mnuAdminLogOn.Text = "Log &On..."
      '
      'mnuAdminLogOff
      '
      Me.mnuAdminLogOff.Enabled = False
      Me.mnuAdminLogOff.Index = 3
      Me.mnuAdminLogOff.Text = "Log O&ff"
      '
      'menuItem2
      '
      Me.menuItem2.Index = 4
      Me.menuItem2.Text = "-"
      '
      'mnuAdminExit
      '
      Me.mnuAdminExit.Index = 5
      Me.mnuAdminExit.Text = "E&xit"
      '
      'mnuUser
      '
      Me.mnuUser.Enabled = False
      Me.mnuUser.Index = 1
      Me.mnuUser.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuUserViewAll, Me.mnuUserADInfo})
      Me.mnuUser.Text = "&User"
      '
      'mnuUserViewAll
      '
      Me.mnuUserViewAll.Index = 0
      Me.mnuUserViewAll.Text = "&View All"
      '
      'mnuUserADInfo
      '
      Me.mnuUserADInfo.Index = 1
      Me.mnuUserADInfo.Text = "Retrieve User Info from &Active Directory"
      '
      'mnuWindow
      '
      Me.mnuWindow.Index = 2
      Me.mnuWindow.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuWindowArrangeAll})
      Me.mnuWindow.Text = "&Window"
      '
      'mnuWindowArrangeAll
      '
      Me.mnuWindowArrangeAll.Index = 0
      Me.mnuWindowArrangeAll.Text = "&Arrange All"
      '
      'frmMain
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(728, 465)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblUserManWebSite})
      Me.IsMdiContainer = True
      Me.Menu = Me.mnuMain
      Me.Name = "frmMain"
      Me.Text = "UserMan Example Application [Not Logged On]"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub mnuUserADInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUserADInfo.Click
      Try
         objAdminUser.GetADUserInfo()
      Catch objE As Exception
         MsgBox(objE.Message & Constants.vbCrLf & objE.InnerException.Message)
      End Try
   End Sub

   Private Sub mnuUserViewAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUserViewAll.Click
      Dim frmU As New frmUsers()

      ' Make the users form an MDI child of this form
      frmU.MdiParent = Me
      frmU.Show()
   End Sub

   Private Sub mnuWindowArrangeAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuWindowArrangeAll.Click
      Me.LayoutMdi(System.Windows.Forms.MdiLayout.TileHorizontal)
   End Sub

   Private Sub mnuAdminExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminExit.Click
      ' Unload application
      Me.Close()
   End Sub

   Private Sub mnuAdminLogOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminLogOff.Click
      LoggedOn = False
      objAdminUser = Nothing
      objAdminUser = New CUser()
      Me.Text = "UserMan Example Application [Not Logged On]"
      ' Update the menus
      prEnableMenus(False)
   End Sub

   Private Sub mnuAdminLogOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminLogOn.Click
      Dim frmLog As New frmLogOn()

      ' Show logon form as modal dialog
      frmLog.ShowDialog()

      ' Check if the user was logged on
      If LoggedOn Then
         Me.Text = "UserMan Example Application [" & objAdminUser.LoginName & "]"
         ' Update the menus
         prEnableMenus(True)
      End If
   End Sub

   Private Sub mnuAdminProperties_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminProperties.Click
      Try
         ' This will fail if the form isn't already shown
         frmProp.Activate()
      Catch
         frmProp = New frmProperties(True)

         ' Make the properties form an MDI child of this form
         frmProp.MdiParent = Me
         frmProp.Show()
      End Try
   End Sub

   Private Sub prEnableMenus(ByVal blnLoggedOn As Boolean)
      mnuAdminLogOff.Enabled = blnLoggedOn
      mnuAdminProperties.Enabled = blnLoggedOn
      mnuUser.Enabled = blnLoggedOn
   End Sub

   Private Sub lblUserManWebSite_LinkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lblUserManWebSite.LinkClicked
      ' Change appearance of the link label
      lblUserManWebSite.LinkVisited = True
      ' Open the default browser 
      System.Diagnostics.Process.Start("http://www.userman.dk")
   End Sub

   Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
      ' Check if the user was logged on
      If Not LoggedOn Then
         ' Display logon form
         mnuAdminLogOn.PerformClick()
      End If
   End Sub

   Private Sub frmMain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
      ' Center the link label
      lblUserManWebSite.Top = (Me.ClientSize.Height - lblUserManWebSite.Height) / 2
      lblUserManWebSite.Left = (Me.ClientSize.Width - lblUserManWebSite.Width) / 2
   End Sub
End Class