Imports System.Data
Imports System.Data.SqlClient

Public Class CLog
   Implements IDisposable

   ' Database constants
   Private Const PR_STR_CONNECTION As String = "Data Source=SERVER;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   Private Const PR_STR_SQL_TABLE_NAME As String = "tblLog"
   Private Const PR_STR_SQL_TABLE_LOG_FIELD_ID As String = "Id"

   Private Const PR_STR_SQL_LOG_SELECT As String = "SELECT * FROM " & PR_STR_SQL_TABLE_NAME
   Private Const PR_STR_SQL_LOG_DELETE As String = "DELETE FROM " & PR_STR_SQL_TABLE_NAME & _
      " WHERE " & PR_STR_SQL_TABLE_LOG_FIELD_ID & "=@" & PR_STR_SQL_TABLE_LOG_FIELD_ID
   Private Const PR_STR_SQL_LOG_INSERT As String = "INSERT INTO " & PR_STR_SQL_TABLE_NAME & _
      "(Logged, Description, UserId) VALUES(@Logged, @Description, @UserId)"
   Private Const PR_STR_SQL_LOG_UPDATE As String = "UPDATE " & PR_STR_SQL_TABLE_NAME & _
      " SET Logged=@Logged, Description=@Description, UserId=@UserId WHERE " & _
      PR_STR_SQL_TABLE_LOG_FIELD_ID & "=@" & PR_STR_SQL_TABLE_LOG_FIELD_ID

   ' Log table column values
   Private prlngId As Long
   Private prstrDescription As String
   Private prdtmLogged As DateTime
   Private prlngUserId As Long

   ' Log table column max lengths
   Private printDescriptionMaxLen As Integer

   ' Database variables
   Private Shared prshcnnUserMan As SqlConnection
   Private prdadUserMan As SqlDataAdapter
   Private prdstUserMan As DataSet

   ' For direct log table manipulation
   Private prcmmLog As SqlCommand
   ' The command objects for the dataset manipulation
   Private prcmmLogSelect As SqlCommand
   Private prcmmLogDelete As SqlCommand
   Private prcmmLogInsert As SqlCommand
   Private prcmmLogUpdate As SqlCommand

   ' Parameter objects for the data set manipulation
   Private prprmSQLDelete, prprmSQLUpdate, prprmSQLInsert As SqlParameter

   Sub New()
      ' Open the connection to the database
      OpenDatabaseConnection()
      ' Instantiate the command objects
      InstantiateCommands()
      ' Instantiate the dataset
      InstantiateDataSet()
      ' Instantiate and populate the data adapter
      InstantiateAndInitializeDataAdapter()
      ' Add paramerts to the command objects
      AddCommandObjectParameters()
      ' Populate the data set with data
      PopulateDataSet()
      ' Get source table schema
      prSetColumnMaxLength()
      ' Save the dataset valuies
      SaveDataSetValues()
   End Sub

   Protected Overrides Sub Finalize()
      ' Close the database connection
      CloseDatabaseConnection()
      ' Call the base class' destructor
      MyBase.Finalize()
   End Sub

   Public Overloads Sub Dispose() Implements IDisposable.Dispose
      ' Close the database connection
      CloseDatabaseConnection()
      ' Now you need to make sure the Finalize method isn't
      ' called as well, because you've already done
      ' the house keeping
      GC.SuppressFinalize(Me)
      ' Always call this method on the base class, 
      ' if it implements one
      'MyBase.Dispose()
   End Sub

   Private Sub OpenDatabaseConnection()
      Try
         ' Check if the connection has already been instantiated
         If prshcnnUserMan Is Nothing Then
            ' Instantiate the connection
            prshcnnUserMan = New SqlConnection(PR_STR_CONNECTION)
            ' Check if the connection is closed
            If prshcnnUserMan.State = ConnectionState.Closed Then
               ' Open the connection
               prshcnnUserMan.Open()
            End If
         End If
      Catch objSqlException As SqlException
         ' A Connection low-level exception was thrown. Add a description and re-throw
         ' the exception to the caller of this class
         Throw New Exception("The connection to the UserMan database could not be " & _
            "established, due to a connection low-level error", objSqlException)
      Catch objE As Exception
         ' Any other exception thrown is handled here
         Throw New Exception("The connection to the UserMan database could not be " & _
            "established.", objE)
      End Try
   End Sub

   Private Sub CloseDatabaseConnection()
      Try
         ' Close the connection
         prshcnnUserMan.Close()
      Catch objE As Exception
         Throw New Exception("The connection to the UserMan database could not be closed properly.", objE)
      End Try
   End Sub

   Private Sub InstantiateCommands()
      ' Instantiate the data set command objects
      prcmmLogSelect = New SqlCommand(PR_STR_SQL_LOG_SELECT, prshcnnUserMan)
      prcmmLogDelete = New SqlCommand(PR_STR_SQL_LOG_DELETE, prshcnnUserMan)
      prcmmLogInsert = New SqlCommand(PR_STR_SQL_LOG_INSERT, prshcnnUserMan)
      prcmmLogUpdate = New SqlCommand(PR_STR_SQL_LOG_UPDATE, prshcnnUserMan)
      ' Instantiate and initialize generic command object
      prcmmLog = New SqlCommand()
      prcmmLog.Connection = prshcnnUserMan
   End Sub

   Private Sub InstantiateDataSet()
      prdstUserMan = New DataSet()
   End Sub

   Private Sub InstantiateAndInitializeDataAdapter()
      prdadUserMan = New SqlDataAdapter()
      prdadUserMan.SelectCommand = prcmmLogSelect
      prdadUserMan.InsertCommand = prcmmLogInsert
      prdadUserMan.DeleteCommand = prcmmLogDelete
      prdadUserMan.UpdateCommand = prcmmLogUpdate
   End Sub

   Private Sub AddCommandObjectParameters()
      ' Add delete command parameters
      prcmmLogDelete.Parameters.Add("@Logged", SqlDbType.SmallDateTime, 0, "Logged")
      prcmmLogDelete.Parameters.Add("@Description", SqlDbType.VarChar, 255, "Description")
      prcmmLogDelete.Parameters.Add("@UserId", SqlDbType.Int, 0, "UserId")

      prprmSQLDelete = prdadUserMan.DeleteCommand.Parameters.Add("@" & PR_STR_SQL_TABLE_LOG_FIELD_ID, _
         SqlDbType.Int, 0, PR_STR_SQL_TABLE_LOG_FIELD_ID)
      prprmSQLDelete.Direction = ParameterDirection.Input
      prprmSQLDelete.SourceVersion = DataRowVersion.Original

      ' Add update command parameters
      prcmmLogUpdate.Parameters.Add("@Logged", SqlDbType.SmallDateTime, 0, "Logged")
      prcmmLogUpdate.Parameters.Add("@Description", SqlDbType.VarChar, 255, "Description")
      prcmmLogUpdate.Parameters.Add("@UserId", SqlDbType.Int, 0, "UserId")

      prprmSQLUpdate = prdadUserMan.UpdateCommand.Parameters.Add("@" & PR_STR_SQL_TABLE_LOG_FIELD_ID, _
         SqlDbType.Int, 0, PR_STR_SQL_TABLE_LOG_FIELD_ID)
      prprmSQLUpdate.Direction = ParameterDirection.Input
      prprmSQLUpdate.SourceVersion = DataRowVersion.Original

      ' Add insert command parameters
      prcmmLogInsert.Parameters.Add("@Logged", SqlDbType.SmallDateTime, 0, "Logged")
      prcmmLogInsert.Parameters.Add("@Description", SqlDbType.VarChar, 255, "Description")
      prcmmLogInsert.Parameters.Add("@UserId", SqlDbType.Int, 0, "UserId")
   End Sub

   Private Sub PopulateDataSet()
      Try
         prdadUserMan.Fill(prdstUserMan, "tblLog")
      Catch objSystemException As SystemException
         Throw New Exception("The dataset could not be populated, " & _
            "because the source table was invalid.", objSystemException)
      Catch objE As Exception
         Throw New Exception("The dataset could not be populated.", objE)
      End Try
   End Sub

   Private Sub SaveDataSetValues()
      ' Check if the dataset is empty
      If prdstUserMan.Tables("tblLog").Rows.Count > 0 Then
         ' Save log id
         prlngId = CLng(prdstUserMan.Tables("tblLog").Rows(0)(PR_STR_SQL_TABLE_LOG_FIELD_ID))
         ' Save description
         prstrDescription = prdstUserMan.Tables("tblLog").Rows(0)("Description").ToString()
         ' Save log date and time
         prdtmLogged = CDate(prdstUserMan.Tables("tblLog").Rows(0)("Logged"))
         ' Save user id
         prlngUserId = CLng(prdstUserMan.Tables("tblLog").Rows(0)("UserId"))
      End If
   End Sub

   Public Sub SetUserProperties(ByVal lngLogId As Long, ByVal strDescription As String, _
      ByVal dtmLogged As DateTime, ByVal lngUserId As Long)
      prlngId = lngLogId
      prstrDescription = strDescription
      prdtmLogged = dtmLogged
      prlngUserId = lngUserId
   End Sub

   Public ReadOnly Property IsDBOpen() As Boolean
      Get
         Return prshcnnUserMan.State = ConnectionState.Open
      End Get
   End Property

   Public ReadOnly Property Id() As Long
      Get
         Return prlngId
      End Get
   End Property

   Public Property Description() As String
      Get
         Return prstrDescription
      End Get

      Set(ByVal Value As String)
         If Value.Length <= printDescriptionMaxLen Then
            prstrDescription = Value
         Else
            prstrDescription = Value.Substring(0, printDescriptionMaxLen)
         End If
      End Set
   End Property

   Public Property Logged() As DateTime
      Get
         Return prdtmLogged
      End Get

      Set(ByVal Value As DateTime)
         prdtmLogged = Value
      End Set
   End Property

   Public Property UserId() As Long
      Get
         Return prlngUserId
      End Get

      Set(ByVal Value As Long)
         prlngUserId = Value
      End Set
   End Property

   Public Function AddLogEntry() As Boolean
      Dim intResult As Integer

      prcmmLog.CommandType = CommandType.Text
      prcmmLog.CommandText = "INSERT INTO " & PR_STR_SQL_TABLE_NAME & "(Description, Logged, UserId) VALUES('" & _
         prstrDescription & "','" & prdtmLogged.ToString("M/d/yyyy H:mm") & "', " & prlngUserId.ToString() & ")"

      intResult = prcmmLog.ExecuteNonQuery()

      ' Examine return result from query
      Return intResult = 1
   End Function

   Private Sub prSetColumnMaxLength()
      Dim drdSchema As SqlDataReader
      Dim dtbSchema As DataTable

      prcmmLog.CommandType = CommandType.Text
      prcmmLog.Connection = prshcnnUserMan
      prcmmLog.CommandText = "SELECT * FROM " & PR_STR_SQL_TABLE_NAME

      ' Return data reader
      drdSchema = prcmmLog.ExecuteReader()

      ' Read schema from source table
      dtbSchema = drdSchema.GetSchemaTable()

      ' Save the maxlength values
      printDescriptionMaxLen = CInt(dtbSchema.Rows(2)("ColumnSize"))

      ' Close datareader
      drdSchema.Close()
   End Sub
End Class