Imports System.Data
Imports System.Data.SqlClient

Public Class CUser
   Inherits Object
   Implements IDisposable

   ' Listing 26-1
   ' Database constants
   Private Const PR_STR_CONNECTION As String = "Data Source=10.8.1.11;" & _
     "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   Private Const PR_STR_SQL_TABLE_NAME As String = "tblUser"

   Private Const PR_STR_SQL_FIELD_ID_NAME As String = "Id"
   Private Const PR_STR_SQL_FIELD_FIRST_NAME As String = "FirstName"
   Private Const PR_STR_SQL_FIELD_LAST_NAME As String = "LastName"
   Private Const PR_STR_SQL_FIELD_LOGIN_NAME As String = "LoginName"
   Private Const PR_STR_SQL_FIELD_PASSWORD_NAME As String = "Password"
   Private Const PR_STR_SQL_FIELD_ADSID_NAME As String = "ADSID"
   Private Const PR_STR_SQL_FIELD_ADNAME_NAME As String = "ADName"

   Private Const PR_STR_SQL_USER_SELECT As String = "SELECT * FROM " & _
      PR_STR_SQL_TABLE_NAME
   Private Const PR_STR_SQL_USER_DELETE As String = "DELETE FROM " & _
    PR_STR_SQL_TABLE_NAME & " WHERE " & PR_STR_SQL_FIELD_ID_NAME & "=@" & _
    PR_STR_SQL_FIELD_ID_NAME
   Private Const PR_STR_SQL_USER_INSERT As String = "INSERT INTO " & _
      PR_STR_SQL_TABLE_NAME & "(" & PR_STR_SQL_FIELD_FIRST_NAME & ", " & _
      PR_STR_SQL_FIELD_LAST_NAME & ", " & PR_STR_SQL_FIELD_LOGIN_NAME & ", " & _
      PR_STR_SQL_FIELD_PASSWORD_NAME & ") VALUES(@" & _
      PR_STR_SQL_FIELD_FIRST_NAME & ", @" & PR_STR_SQL_FIELD_LAST_NAME & ", @" & _
      PR_STR_SQL_FIELD_LOGIN_NAME & ", @" & PR_STR_SQL_FIELD_PASSWORD_NAME & _
      ")"
   Private Const PR_STR_SQL_USER_UPDATE As String = "UPDATE " & _
      PR_STR_SQL_TABLE_NAME & " SET " & PR_STR_SQL_FIELD_FIRST_NAME & "=@" & _
      PR_STR_SQL_FIELD_FIRST_NAME & ", " & PR_STR_SQL_FIELD_LAST_NAME & "=@" & _
      PR_STR_SQL_FIELD_LAST_NAME & ", " & PR_STR_SQL_FIELD_LOGIN_NAME & "=@" & _
      PR_STR_SQL_FIELD_LOGIN_NAME & ", " & PR_STR_SQL_FIELD_PASSWORD_NAME & _
      "=@" & PR_STR_SQL_FIELD_PASSWORD_NAME & " WHERE " & _
      PR_STR_SQL_FIELD_ID_NAME & "=@" & PR_STR_SQL_FIELD_ID_NAME
   Private Const PR_STR_SQL_TABLE_USER_FIELD_ID As String = "Id"

   ' Database variables
   Private Shared prshcnnUserMan As SqlConnection
   Private prdadUserMan As SqlDataAdapter
   Private prdstUserMan As DataSet

   ' For direct user table manipulation
   Private prcmmUser As SqlCommand
   ' The command objects for the dataset manipulation
   Private prcmmUserSelect, prcmmUserDelete, prcmmUserInsert, _
      prcmmUserUpdate As SqlCommand
   ' Parameter objects for the data set manipulation
   Private prprmSQLDelete, prprmSQLUpdate, prprmSQLInsert As SqlParameter

   ' User table column values
   Private prlngId As Long = 0
   Private prstrADName As String
   Private prstrADSID As String
   Private prstrFirstName As String
   Private prstrLastName As String
   Private prstrLoginName As String
   Private prstrPassword As String

   ' User table column max lengths
   Private printADNameMaxLen As Integer
   Private printADSIDMaxLen As Integer
   Private printFirstNameMaxLen As Integer
   Private printLastNameMaxLen As Integer
   Private printLoginNameMaxLen As Integer
   Private printPasswordMaxLen As Integer

   ' For logging user activity
   Private probjLog As New CLog()

   ' For Accessing Active Directory
   Private probjActiveDirectory As CActiveDirectory

   ' Listing 26-4
   'Public Sub New()
   '   MyBase.New()
   '   ' Open the database connection
   '   prOpenDatabaseConnection()
   'End Sub

   Public Sub New()
      MyBase.New()

      prOpenDatabaseConnection()
      prInstantiateCommands()
      prInstantiateDataSet()
      prInstantiateAndInitializeDataAdapter()
      prAddCommandObjectParameters()
      prPopulateDataSet()
      prSetColumnMaxLength()
   End Sub

   ' Listing 26-2
   Private Sub prSetColumnMaxLength()
      Const STR_COLUMN_SIZE As String = "ColumnSize"

      Dim drdSchema As SqlDataReader
      Dim dtbSchema As DataTable
      Dim cmmUserSchema = New SqlCommand()

      cmmUserSchema.CommandType = CommandType.Text
      cmmUserSchema.Connection = prshcnnUserMan
      cmmUserSchema.CommandText = "SELECT * FROM " & PR_STR_SQL_TABLE_NAME

      ' Return data reader
      drdSchema = cmmUserSchema.ExecuteReader()

      ' Read schema from source table
      dtbSchema = drdSchema.GetSchemaTable()

      ' Save the maxlength values
      printFirstNameMaxLen = CInt(dtbSchema.Rows(3)(STR_COLUMN_SIZE))
      printLastNameMaxLen = CInt(dtbSchema.Rows(4)(STR_COLUMN_SIZE))
      printLoginNameMaxLen = CInt(dtbSchema.Rows(5)(STR_COLUMN_SIZE))
      printPasswordMaxLen = CInt(dtbSchema.Rows(6)(STR_COLUMN_SIZE))

      ' Close datareader
      drdSchema.Close()
   End Sub

   ' Listing 26-3
   Private Sub prOpenDatabaseConnection()
      Try
         ' Check if the connection has already been instantiated
         If prshcnnUserMan Is Nothing Then
            ' Instantiate the connection
            prshcnnUserMan = New SqlConnection(PR_STR_CONNECTION)
            ' Check if the connection is closed
            If (prshcnnUserMan.State = ConnectionState.Closed) Then
               ' Open the connection
               prshcnnUserMan.Open()
               ' Log activity if the user has already been logged on
               If prlngId > 0 Then
                  probjLog.Logged = DateTime.Now
                  probjLog.Description = "Database connection opened."
                  probjLog.UserId = prlngId
                  probjLog.AddLogEntry()
               End If
            End If
         End If
      Catch objSqlException As SqlException
         ' A Connection low-level exception was thrown. Add a description and re-throw
         ' the exception to the caller of this class
         Throw New Exception("The connection to the UserMan database could not be " & _
            "established, due to a connection low-level error", objSqlException)
      Catch objE As Exception
         ' Any other exception thrown is handled here
         Throw New Exception("The connection to the UserMan database could not be " & _
            "established.", objE)
      End Try
   End Sub

   ' Listing 26-5
   Private Sub prCloseDatabaseConnection()
      Try
         ' Close the connection
         prshcnnUserMan.Close()
         ' Log activity if the user has already been logged on
         If prlngId > 0 Then
            probjLog.Logged = DateTime.Now
            probjLog.Description = "Database connection closed."
            probjLog.UserId = prlngId
            probjLog.AddLogEntry()
         End If
      Catch objE As Exception
         Throw New Exception("The connection to the UserMan database could " & _
            "not be closed properly.", objE)
      End Try
   End Sub

   ' Declare delegate for hooking up error notifications
   Public Delegate Sub ErrorEventHandler(ByVal sender As Object, _
      ByVal e As CErrorEventArgs)

   Public Event OnError(ByVal sender As Object, _
       ByVal e As CErrorEventArgs)


   ' Listing 26-6
   Protected Overrides Sub Finalize()
      ' Do your house keeping here
      prCloseDatabaseConnection()
      ' Call the base class' destructor
      MyBase.Finalize()
   End Sub

   Public Overloads Sub Dispose() Implements IDisposable.Dispose
      ' Do your house keeping here
      prCloseDatabaseConnection()
      ' Now you need to make sure the Finalize method isn't
      ' called as well, because you've already done
      ' the house keeping
      GC.SuppressFinalize(Me)
      ' Always call this method on the base class, 
      ' if it implements one
      'MyBase.Dispose()
   End Sub

   ' Listing 26-7
   Private Sub prInstantiateCommands()
      ' Instantiate the data set command objects
      prcmmUserSelect = New SqlCommand(PR_STR_SQL_USER_SELECT, prshcnnUserMan)
      prcmmUserDelete = New SqlCommand(PR_STR_SQL_USER_DELETE, prshcnnUserMan)
      prcmmUserInsert = New SqlCommand(PR_STR_SQL_USER_INSERT, prshcnnUserMan)
      prcmmUserUpdate = New SqlCommand(PR_STR_SQL_USER_UPDATE, prshcnnUserMan)
      ' Instantiate and initialize generic command object
      prcmmUser = New SqlCommand()
      prcmmUser.Connection = prshcnnUserMan
   End Sub

   ' Listing 26-8
   Private Sub prInstantiateDataSet()
      prdstUserMan = New DataSet()
   End Sub

   ' Listing 26-9
   Private Sub prInstantiateAndInitializeDataAdapter()
      prdadUserMan = New SqlDataAdapter()
      prdadUserMan.SelectCommand = prcmmUserSelect
      prdadUserMan.InsertCommand = prcmmUserInsert
      prdadUserMan.DeleteCommand = prcmmUserDelete
      prdadUserMan.UpdateCommand = prcmmUserUpdate
   End Sub

   ' Listing 26-10
   Private Sub prAddCommandObjectParameters()
      ' Add delete command parameters
      prprmSQLDelete = prdadUserMan.DeleteCommand.Parameters.Add("@" & _
         PR_STR_SQL_FIELD_ID_NAME, SqlDbType.Int, 0, PR_STR_SQL_FIELD_ID_NAME)
      prprmSQLDelete.Direction = ParameterDirection.Input
      prprmSQLDelete.SourceVersion = DataRowVersion.Original

      ' Add update command parameters
      prcmmUserUpdate.Parameters.Add("@" & PR_STR_SQL_FIELD_FIRST_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_FIRST_NAME)
      prcmmUserUpdate.Parameters.Add("@" & PR_STR_SQL_FIELD_LAST_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LAST_NAME)
      prcmmUserUpdate.Parameters.Add("@" & PR_STR_SQL_FIELD_LOGIN_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LOGIN_NAME)
      prcmmUserUpdate.Parameters.Add("@" & PR_STR_SQL_FIELD_PASSWORD_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_PASSWORD_NAME)
      prprmSQLUpdate = prdadUserMan.UpdateCommand.Parameters.Add("@" & _
         PR_STR_SQL_FIELD_ID_NAME, SqlDbType.Int, 0, PR_STR_SQL_FIELD_ID_NAME)
      prprmSQLUpdate.Direction = ParameterDirection.Input
      prprmSQLUpdate.SourceVersion = DataRowVersion.Original

      ' Add insert command parameters
      prcmmUserInsert.Parameters.Add(PR_STR_SQL_FIELD_FIRST_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_FIRST_NAME)
      prcmmUserInsert.Parameters.Add("@" & PR_STR_SQL_FIELD_LAST_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LAST_NAME)
      prcmmUserInsert.Parameters.Add("@" & PR_STR_SQL_FIELD_LOGIN_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LOGIN_NAME)
      prcmmUserInsert.Parameters.Add("@" & PR_STR_SQL_FIELD_PASSWORD_NAME, _
         SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_PASSWORD_NAME)
   End Sub

   ' Listing 26-11
   Private Sub prPopulateDataSet()
      Try
         prdadUserMan.Fill(prdstUserMan, PR_STR_SQL_TABLE_NAME)
      Catch objSystemException As SystemException
         Throw New Exception("The DataSet could not be populated, " & _
            "because the source table was invalid.", objSystemException)
      Catch objE As Exception
         Throw New Exception("The DataSet could not be populated.", objE)
      End Try
   End Sub

   ' Listing 26-12
   Private Sub prSaveDataSetValues()
      ' Save user id
      prlngId = CLng(prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
         (PR_STR_SQL_FIELD_ID_NAME))
      ' Check if ADName is Null
      If prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0). _
         IsNull(PR_STR_SQL_FIELD_ADNAME_NAME) Then
         prstrADName = ""
      Else
         prstrADName = prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_ADNAME_NAME).ToString()
      End If
      ' Check if ADSID is Null
      If prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0). _
         IsNull(PR_STR_SQL_FIELD_ADSID_NAME) Then
         prstrADSID = ""
      Else
         prstrADSID = prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_ADSID_NAME).ToString()
      End If
      ' Check if first name is Null
      If prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0). _
         IsNull(PR_STR_SQL_FIELD_FIRST_NAME) Then
         prstrFirstName = ""
      Else
         prstrFirstName = prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_FIRST_NAME).ToString()
      End If
      ' Check if last name is Null
      If prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0). _
         IsNull(PR_STR_SQL_FIELD_LAST_NAME) Then
         prstrLastName = ""
      Else
         prstrLastName = prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_LAST_NAME).ToString()
      End If
      ' Check if login name is Null
      If prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0). _
         IsNull(PR_STR_SQL_FIELD_LOGIN_NAME) Then
         prstrLoginName = ""
      Else
         prstrLoginName = prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_LOGIN_NAME).ToString()
      End If
      ' Check if password is Null
      If prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0). _
         IsNull(PR_STR_SQL_FIELD_PASSWORD_NAME) Then
         prstrPassword = ""
      Else
         prstrPassword = prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_PASSWORD_NAME).ToString()
      End If
   End Sub

   Public ReadOnly Property Id() As Long
      Get
         Id = prlngId
      End Get
   End Property

   Public Property ADName() As String
      Get
         ADName = prstrADName
      End Get

      Set(ByVal vstrADName As String)
         If vstrADName.Length <= printADNameMaxLen Then
            prstrADName = vstrADName
         Else
            prstrADName = vstrADName.Substring(0, printADNameMaxLen)
         End If
      End Set
   End Property

   Public Property ADSID() As String
      Get
         ADSID = prstrADSID
      End Get

      Set(ByVal vstrADSID As String)
         If vstrADSID.Length <= printADSIDMaxLen Then
            prstrADSID = vstrADSID
         Else
            prstrADSID = vstrADSID.Substring(0, printADSIDMaxLen)
         End If
      End Set
   End Property

   Public Property FirstName() As String
      Get
         FirstName = prstrFirstName
      End Get

      Set(ByVal vstrFirstName As String)
         If vstrFirstName.Length <= printFirstNameMaxLen Then
            prstrFirstName = vstrFirstName
         Else
            prstrFirstName = vstrFirstName.Substring(0, printFirstNameMaxLen)
         End If
      End Set
   End Property

   Public Property LastName() As String
      Get
         LastName = prstrLastName
      End Get

      Set(ByVal vstrLastName As String)
         If vstrLastName.Length <= printLastNameMaxLen Then
            prstrLastName = vstrLastName
         Else
            prstrLastName = vstrLastName.Substring(0, printLastNameMaxLen)
         End If
      End Set
   End Property

   Public Property LoginName() As String
      Get
         LoginName = prstrLoginName
      End Get

      Set(ByVal vstrLoginName As String)
         ' Check if the string contains any spaces
         If vstrLoginName.IndexOf(" ") = -1 Then
            If vstrLoginName.Length <= printLoginNameMaxLen Then
               prstrLoginName = vstrLoginName
            Else
               prstrLoginName = vstrLoginName.Substring(0, printLoginNameMaxLen)
            End If
         Else
            ' Instantiates the event source
            Dim objErrorEvent As New _
            CErrorEventArgs(CErrorEventArgs.ErrorStatusEnum.InvalidLoginName)
            ' Triggers the error event
            RaiseEvent OnError(Me, objErrorEvent)
         End If
      End Set
   End Property

   Public Property Password() As String
      Get
         Password = prstrPassword
      End Get

      Set(ByVal vstrPassword As String)
         If vstrPassword.Length <= printPasswordMaxLen Then
            prstrPassword = vstrPassword
         Else
            prstrPassword = vstrPassword.Substring(0, printPasswordMaxLen)
         End If
      End Set
   End Property

   Public Sub UpdateDataSource()
      Try
         prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_ADNAME_NAME) = prstrADName
         prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_ADSID_NAME) = prstrADSID
         prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_FIRST_NAME) = prstrFirstName
         prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_LAST_NAME) = prstrLastName
         prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_LOGIN_NAME) = prstrLoginName
         prdstUserMan.Tables(PR_STR_SQL_TABLE_NAME).Rows(0) _
            (PR_STR_SQL_FIELD_PASSWORD_NAME) = prstrPassword
         prdadUserMan.Update(prdstUserMan, PR_STR_SQL_TABLE_NAME)
      Catch objE As Exception
         ' An exception has been thrown, so re-throw with original exception
         Throw New Exception("The UserMan database could not be updated.", objE)
      End Try
   End Sub

   Public Sub SetUserProperties(ByVal strADName As Object, ByVal strADSID As Object, _
      ByVal lngId As Long, ByVal strLoginName As String, ByVal strFirstName As Object, _
      ByVal strLastName As Object, ByVal strPassword As String)

      If strADName Is Nothing Then
         prstrADName = ""
      Else
         prstrADName = strADName.ToString()
      End If

      If strADSID Is Nothing Then
         prstrADSID = ""
      Else
         prstrADSID = strADSID.ToString()
      End If

      prlngId = lngId

      If strFirstName Is Nothing Then
         prstrFirstName = ""
      Else
         prstrFirstName = strFirstName.ToString()
      End If

      If strLastName Is Nothing Then
         prstrLastName = ""
      Else
         prstrLastName = strLastName.ToString()
      End If

      prstrLoginName = strLoginName
      prstrPassword = strPassword
   End Sub

   ' Listing 26-14
   Public Sub GetADUserInfo()
      probjActiveDirectory = New CActiveDirectory(prstrLoginName) 'prstrFirstName & " " & prstrLastName)
      prstrADName = probjActiveDirectory.ADName
      prstrADSID = probjActiveDirectory.ADSID
   End Sub
End Class