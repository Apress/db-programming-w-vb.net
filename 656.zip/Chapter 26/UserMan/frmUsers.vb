Public Class frmUsers
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
   Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
   Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
   Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
   Friend WithEvents objUser As UserMan.User
   Friend WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
   Friend WithEvents OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter
   Friend WithEvents btnLoad As System.Windows.Forms.Button
   Friend WithEvents btnUpdate As System.Windows.Forms.Button
   Friend WithEvents btnCancelAll As System.Windows.Forms.Button
   Friend WithEvents lblId As System.Windows.Forms.Label
   Friend WithEvents lblADName As System.Windows.Forms.Label
   Friend WithEvents lblADSID As System.Windows.Forms.Label
   Friend WithEvents lblFirstName As System.Windows.Forms.Label
   Friend WithEvents editId As System.Windows.Forms.TextBox
   Friend WithEvents editADName As System.Windows.Forms.TextBox
   Friend WithEvents editADSID As System.Windows.Forms.TextBox
   Friend WithEvents editFirstName As System.Windows.Forms.TextBox
   Friend WithEvents lblLastName As System.Windows.Forms.Label
   Friend WithEvents lblLoginName As System.Windows.Forms.Label
   Friend WithEvents lblPassword As System.Windows.Forms.Label
   Friend WithEvents editLastName As System.Windows.Forms.TextBox
   Friend WithEvents editLoginName As System.Windows.Forms.TextBox
   Friend WithEvents editPassword As System.Windows.Forms.TextBox
   Friend WithEvents btnNavFirst As System.Windows.Forms.Button
   Friend WithEvents btnNavPrev As System.Windows.Forms.Button
   Friend WithEvents lblNavLocation As System.Windows.Forms.Label
   Friend WithEvents btnNavNext As System.Windows.Forms.Button
   Friend WithEvents btnLast As System.Windows.Forms.Button
   Friend WithEvents btnAdd As System.Windows.Forms.Button
   Friend WithEvents btnDelete As System.Windows.Forms.Button
   Friend WithEvents btnCancel As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
      Me.objUser = New UserMan.User()
      Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
      Me.OleDbDataAdapter1 = New System.Data.OleDb.OleDbDataAdapter()
      Me.btnLoad = New System.Windows.Forms.Button()
      Me.btnUpdate = New System.Windows.Forms.Button()
      Me.btnCancelAll = New System.Windows.Forms.Button()
      Me.lblId = New System.Windows.Forms.Label()
      Me.lblADName = New System.Windows.Forms.Label()
      Me.lblADSID = New System.Windows.Forms.Label()
      Me.lblFirstName = New System.Windows.Forms.Label()
      Me.editId = New System.Windows.Forms.TextBox()
      Me.editADName = New System.Windows.Forms.TextBox()
      Me.editADSID = New System.Windows.Forms.TextBox()
      Me.editFirstName = New System.Windows.Forms.TextBox()
      Me.lblLastName = New System.Windows.Forms.Label()
      Me.lblLoginName = New System.Windows.Forms.Label()
      Me.lblPassword = New System.Windows.Forms.Label()
      Me.editLastName = New System.Windows.Forms.TextBox()
      Me.editLoginName = New System.Windows.Forms.TextBox()
      Me.editPassword = New System.Windows.Forms.TextBox()
      Me.btnNavFirst = New System.Windows.Forms.Button()
      Me.btnNavPrev = New System.Windows.Forms.Button()
      Me.lblNavLocation = New System.Windows.Forms.Label()
      Me.btnNavNext = New System.Windows.Forms.Button()
      Me.btnLast = New System.Windows.Forms.Button()
      Me.btnAdd = New System.Windows.Forms.Button()
      Me.btnDelete = New System.Windows.Forms.Button()
      Me.btnCancel = New System.Windows.Forms.Button()
      CType(Me.objUser, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'OleDbSelectCommand1
      '
      Me.OleDbSelectCommand1.CommandText = "SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser"
      Me.OleDbSelectCommand1.Connection = Me.OleDbConnection1
      '
      'OleDbInsertCommand1
      '
      Me.OleDbInsertCommand1.CommandText = "INSERT INTO tblUser(ADName, ADSID, FirstName, LastName, LoginName, Password) VALU" & _
      "ES (?, ?, ?, ?, ?, ?); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName," & _
      " Password FROM tblUser WHERE (Id = @@IDENTITY)"
      Me.OleDbInsertCommand1.Connection = Me.OleDbConnection1
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, "ADName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.VarChar, 50, "ADSID"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, "FirstName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, "LastName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, "LoginName"))
      Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, "Password"))
      '
      'OleDbUpdateCommand1
      '
      Me.OleDbUpdateCommand1.CommandText = "UPDATE tblUser SET ADName = ?, ADSID = ?, FirstName = ?, LastName = ?, LoginName " & _
      "= ?, Password = ? WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NULL" & _
      ") AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NULL" & _
      " AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AND" & _
      " (LoginName = ?) AND (Password = ?); SELECT Id, ADName, ADSID, FirstName, LastNa" & _
      "me, LoginName, Password FROM tblUser WHERE (Id = ?)"
      Me.OleDbUpdateCommand1.Connection = Me.OleDbConnection1
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, "ADName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.VarChar, 50, "ADSID"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, "FirstName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, "LastName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, "LoginName"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, "Password"))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Select_Id", System.Data.OleDb.OleDbType.Integer, 4, "Id"))
      '
      'OleDbDeleteCommand1
      '
      Me.OleDbDeleteCommand1.CommandText = "DELETE FROM tblUser WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NUL" & _
      "L) AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NUL" & _
      "L AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AN" & _
      "D (LoginName = ?) AND (Password = ?)"
      Me.OleDbDeleteCommand1.Connection = Me.OleDbConnection1
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Id", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ADSID", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "FirstName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LastName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "LoginName", System.Data.DataRowVersion.Original, Nothing))
      Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Password", System.Data.DataRowVersion.Original, Nothing))
      '
      'objUser
      '
      Me.objUser.DataSetName = "User"
      Me.objUser.Locale = New System.Globalization.CultureInfo("da-DK")
      Me.objUser.Namespace = "http://www.tempuri.org/User.xsd"
      '
      'OleDbConnection1
      '
      Me.OleDbConnection1.ConnectionString = "Provider=SQLOLEDB.1;Password=userman;Persist Security Info=True;User ID=UserMan;I" & _
      "nitial Catalog=UserMan;Data Source=server;Use Procedure for Prepare=1;Auto Trans" & _
      "late=True;Packet Size=4096;Workstation ID=WS1;Use Encryption for Data=False;Tag " & _
      "with column collation when possible=False"
      '
      'OleDbDataAdapter1
      '
      Me.OleDbDataAdapter1.DeleteCommand = Me.OleDbDeleteCommand1
      Me.OleDbDataAdapter1.InsertCommand = Me.OleDbInsertCommand1
      Me.OleDbDataAdapter1.SelectCommand = Me.OleDbSelectCommand1
      Me.OleDbDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "tblUser", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Id", "Id"), New System.Data.Common.DataColumnMapping("ADName", "ADName"), New System.Data.Common.DataColumnMapping("ADSID", "ADSID"), New System.Data.Common.DataColumnMapping("FirstName", "FirstName"), New System.Data.Common.DataColumnMapping("LastName", "LastName"), New System.Data.Common.DataColumnMapping("LoginName", "LoginName"), New System.Data.Common.DataColumnMapping("Password", "Password")})})
      Me.OleDbDataAdapter1.UpdateCommand = Me.OleDbUpdateCommand1
      '
      'btnLoad
      '
      Me.btnLoad.Location = New System.Drawing.Point(10, 10)
      Me.btnLoad.Name = "btnLoad"
      Me.btnLoad.Size = New System.Drawing.Size(83, 23)
      Me.btnLoad.TabIndex = 0
      Me.btnLoad.Text = "&Load"
      '
      'btnUpdate
      '
      Me.btnUpdate.Location = New System.Drawing.Point(357, 10)
      Me.btnUpdate.Name = "btnUpdate"
      Me.btnUpdate.Size = New System.Drawing.Size(83, 23)
      Me.btnUpdate.TabIndex = 1
      Me.btnUpdate.Text = "&Update"
      '
      'btnCancelAll
      '
      Me.btnCancelAll.Location = New System.Drawing.Point(357, 43)
      Me.btnCancelAll.Name = "btnCancelAll"
      Me.btnCancelAll.Size = New System.Drawing.Size(83, 23)
      Me.btnCancelAll.TabIndex = 2
      Me.btnCancelAll.Text = "Ca&ncel All"
      '
      'lblId
      '
      Me.lblId.Location = New System.Drawing.Point(10, 76)
      Me.lblId.Name = "lblId"
      Me.lblId.TabIndex = 3
      Me.lblId.Text = "Id"
      '
      'lblADName
      '
      Me.lblADName.Location = New System.Drawing.Point(10, 109)
      Me.lblADName.Name = "lblADName"
      Me.lblADName.TabIndex = 4
      Me.lblADName.Text = "ADName"
      '
      'lblADSID
      '
      Me.lblADSID.Location = New System.Drawing.Point(10, 142)
      Me.lblADSID.Name = "lblADSID"
      Me.lblADSID.TabIndex = 5
      Me.lblADSID.Text = "ADSID"
      '
      'lblFirstName
      '
      Me.lblFirstName.Location = New System.Drawing.Point(10, 175)
      Me.lblFirstName.Name = "lblFirstName"
      Me.lblFirstName.TabIndex = 6
      Me.lblFirstName.Text = "FirstName"
      '
      'editId
      '
      Me.editId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.Id"))
      Me.editId.Location = New System.Drawing.Point(120, 76)
      Me.editId.Name = "editId"
      Me.editId.TabIndex = 7
      Me.editId.Text = ""
      '
      'editADName
      '
      Me.editADName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.ADName"))
      Me.editADName.Location = New System.Drawing.Point(120, 109)
      Me.editADName.Name = "editADName"
      Me.editADName.TabIndex = 8
      Me.editADName.Text = ""
      '
      'editADSID
      '
      Me.editADSID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.ADSID"))
      Me.editADSID.Location = New System.Drawing.Point(120, 142)
      Me.editADSID.Name = "editADSID"
      Me.editADSID.TabIndex = 9
      Me.editADSID.Text = ""
      '
      'editFirstName
      '
      Me.editFirstName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.FirstName"))
      Me.editFirstName.Location = New System.Drawing.Point(120, 175)
      Me.editFirstName.Name = "editFirstName"
      Me.editFirstName.TabIndex = 10
      Me.editFirstName.Text = ""
      '
      'lblLastName
      '
      Me.lblLastName.Location = New System.Drawing.Point(230, 76)
      Me.lblLastName.Name = "lblLastName"
      Me.lblLastName.TabIndex = 11
      Me.lblLastName.Text = "LastName"
      '
      'lblLoginName
      '
      Me.lblLoginName.Location = New System.Drawing.Point(230, 109)
      Me.lblLoginName.Name = "lblLoginName"
      Me.lblLoginName.TabIndex = 12
      Me.lblLoginName.Text = "LoginName"
      '
      'lblPassword
      '
      Me.lblPassword.Location = New System.Drawing.Point(230, 142)
      Me.lblPassword.Name = "lblPassword"
      Me.lblPassword.TabIndex = 13
      Me.lblPassword.Text = "Password"
      '
      'editLastName
      '
      Me.editLastName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.LastName"))
      Me.editLastName.Location = New System.Drawing.Point(340, 76)
      Me.editLastName.Name = "editLastName"
      Me.editLastName.TabIndex = 14
      Me.editLastName.Text = ""
      '
      'editLoginName
      '
      Me.editLoginName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.LoginName"))
      Me.editLoginName.Location = New System.Drawing.Point(340, 109)
      Me.editLoginName.Name = "editLoginName"
      Me.editLoginName.TabIndex = 15
      Me.editLoginName.Text = ""
      '
      'editPassword
      '
      Me.editPassword.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objUser, "tblUser.Password"))
      Me.editPassword.Location = New System.Drawing.Point(340, 142)
      Me.editPassword.Name = "editPassword"
      Me.editPassword.TabIndex = 16
      Me.editPassword.Text = ""
      '
      'btnNavFirst
      '
      Me.btnNavFirst.Location = New System.Drawing.Point(195, 208)
      Me.btnNavFirst.Name = "btnNavFirst"
      Me.btnNavFirst.Size = New System.Drawing.Size(40, 23)
      Me.btnNavFirst.TabIndex = 17
      Me.btnNavFirst.Text = "<<"
      '
      'btnNavPrev
      '
      Me.btnNavPrev.Location = New System.Drawing.Point(235, 208)
      Me.btnNavPrev.Name = "btnNavPrev"
      Me.btnNavPrev.Size = New System.Drawing.Size(35, 23)
      Me.btnNavPrev.TabIndex = 18
      Me.btnNavPrev.Text = "<"
      '
      'lblNavLocation
      '
      Me.lblNavLocation.BackColor = System.Drawing.Color.White
      Me.lblNavLocation.Location = New System.Drawing.Point(270, 208)
      Me.lblNavLocation.Name = "lblNavLocation"
      Me.lblNavLocation.Size = New System.Drawing.Size(95, 23)
      Me.lblNavLocation.TabIndex = 19
      Me.lblNavLocation.Text = "No Records"
      Me.lblNavLocation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'btnNavNext
      '
      Me.btnNavNext.Location = New System.Drawing.Point(365, 208)
      Me.btnNavNext.Name = "btnNavNext"
      Me.btnNavNext.Size = New System.Drawing.Size(35, 23)
      Me.btnNavNext.TabIndex = 20
      Me.btnNavNext.Text = ">"
      '
      'btnLast
      '
      Me.btnLast.Location = New System.Drawing.Point(400, 208)
      Me.btnLast.Name = "btnLast"
      Me.btnLast.Size = New System.Drawing.Size(40, 23)
      Me.btnLast.TabIndex = 21
      Me.btnLast.Text = ">>"
      '
      'btnAdd
      '
      Me.btnAdd.Location = New System.Drawing.Point(195, 241)
      Me.btnAdd.Name = "btnAdd"
      Me.btnAdd.TabIndex = 22
      Me.btnAdd.Text = "&Add"
      '
      'btnDelete
      '
      Me.btnDelete.Location = New System.Drawing.Point(280, 241)
      Me.btnDelete.Name = "btnDelete"
      Me.btnDelete.TabIndex = 23
      Me.btnDelete.Text = "&Delete"
      '
      'btnCancel
      '
      Me.btnCancel.Location = New System.Drawing.Point(365, 241)
      Me.btnCancel.Name = "btnCancel"
      Me.btnCancel.TabIndex = 24
      Me.btnCancel.Text = "&Cancel"
      '
      'frmUsers
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(442, 276)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnLoad, Me.btnUpdate, Me.btnCancelAll, Me.lblId, Me.lblADName, Me.lblADSID, Me.lblFirstName, Me.editId, Me.editADName, Me.editADSID, Me.editFirstName, Me.lblLastName, Me.lblLoginName, Me.lblPassword, Me.editLastName, Me.editLoginName, Me.editPassword, Me.btnNavFirst, Me.btnNavPrev, Me.lblNavLocation, Me.btnNavNext, Me.btnLast, Me.btnAdd, Me.btnDelete, Me.btnCancel})
      Me.Name = "frmUsers"
      Me.ShowInTaskbar = False
      Me.Text = "Users"
      CType(Me.objUser, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      Me.BindingContext(objUser, "tblUser").CancelCurrentEdit()
      Me.objUser_PositionChanged()
   End Sub

   Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
      If (Me.BindingContext(objUser, "tblUser").Count > 0) Then
         Me.BindingContext(objUser, "tblUser").RemoveAt(Me.BindingContext(objUser, "tblUser").Position)
         Me.objUser_PositionChanged()
      End If
   End Sub

   Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
      Try
         'Clear out the current edits
         Me.BindingContext(objUser, "tblUser").EndCurrentEdit()
         Me.BindingContext(objUser, "tblUser").AddNew()
      Catch eEndEdit As System.Exception
         System.Windows.Forms.MessageBox.Show(eEndEdit.Message)
      End Try

      Me.objUser_PositionChanged()
   End Sub

   Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
      Try
         'Attempt to update the datasource.
         Me.UpdateDataSet()
      Catch eUpdate As System.Exception
         'Add your error handling code here.
         'Display error message, if any.
         System.Windows.Forms.MessageBox.Show(eUpdate.Message)
      End Try

      Me.objUser_PositionChanged()
   End Sub

   Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
      Try
         'Attempt to load the dataset.
         Me.LoadDataSet()
      Catch eLoad As System.Exception
         'Add your error handling code here.
         'Display error message, if any.
         System.Windows.Forms.MessageBox.Show(eLoad.Message)
      End Try

      Me.objUser_PositionChanged()
   End Sub

   Private Sub btnNavFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNavFirst.Click
      Me.BindingContext(objUser, "tblUser").Position = 0
      Me.objUser_PositionChanged()
   End Sub

   Private Sub btnLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLast.Click
      Me.BindingContext(objUser, "tblUser").Position = (Me.objUser.Tables("tblUser").Rows.Count - 1)
      Me.objUser_PositionChanged()
   End Sub

   Private Sub btnNavPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNavPrev.Click
      Me.BindingContext(objUser, "tblUser").Position = (Me.BindingContext(objUser, "tblUser").Position - 1)
      Me.objUser_PositionChanged()
   End Sub

   Private Sub btnNavNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNavNext.Click
      Me.BindingContext(objUser, "tblUser").Position = (Me.BindingContext(objUser, "tblUser").Position + 1)
      Me.objUser_PositionChanged()
   End Sub

   Private Sub objUser_PositionChanged()
      Me.lblNavLocation.Text = (((Me.BindingContext(objUser, "tblUser").Position + 1).ToString & " of  ") _
         & Me.BindingContext(objUser, "tblUser").Count.ToString)
   End Sub

   Private Sub btnCancelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAll.Click
      Me.objUser.RejectChanges()
   End Sub

   Public Sub UpdateDataSet()
      'Create a new dataset to hold the changes that have been made to the main dataset.
      Dim objDataSetChanges As UserMan.User = New UserMan.User()
      'Stop any current edits.
      Me.BindingContext(objUser, "tblUser").EndCurrentEdit()
      'Get the changes that have been made to the main dataset.
      objDataSetChanges = CType(objUser.GetChanges, UserMan.User)

      'Check to see if any changes have been made.
      If (Not (objDataSetChanges) Is Nothing) Then
         Try
            'There are changes that need to be made, so attempt to update the datasource by
            'calling the update method and passing the dataset and any parameters.
            Me.UpdateDataSource(objDataSetChanges)
            objUser.Merge(objDataSetChanges)
            objUser.AcceptChanges()
         Catch eUpdate As System.Exception
            'Add your error handling code here.
            Throw eUpdate
         End Try
         'Add your code to check the returned dataset for any errors that may have been
         'pushed into the row object's error.
      End If
   End Sub

   Public Sub LoadDataSet()
      'Create a new dataset to hold the records returned from the call to FillDataSet.
      'A temporary dataset is used because filling the existing dataset would
      'require the databindings to be rebound.
      Dim objDataSetTemp As UserMan.User
      objDataSetTemp = New UserMan.User()

      Try
         'Attempt to fill the temporary dataset.
         Me.FillDataSet(objDataSetTemp)
      Catch eFillDataSet As System.Exception
         'Add your error handling code here.
         Throw eFillDataSet
      End Try

      Try
         'Empty the old records from the dataset.
         objUser.Clear()
         'Merge the records into the main dataset.
         objUser.Merge(objDataSetTemp)
      Catch eLoadMerge As System.Exception
         'Add your error handling code here.
         Throw eLoadMerge
      End Try
   End Sub

   Public Sub UpdateDataSource(ByVal ChangedRows As UserMan.User)
      Try
         'The data source only needs to be updated if there are changes pending.
         If (Not (ChangedRows) Is Nothing) Then
            'Open the connection.
            Me.OleDbConnection1.Open()
            'Attempt to update the data source.
            OleDbDataAdapter1.Update(ChangedRows)
         End If
      Catch updateException As System.Exception
         'Add your error handling code here.
         Throw updateException
      Finally
         'Close the connection whether or not the exception was thrown.
         Me.OleDbConnection1.Close()
      End Try
   End Sub

   Public Sub FillDataSet(ByVal dataSet As UserMan.User)
      'Turn off constraint checking before the dataset is filled.
      'This allows the adapters to fill the dataset without concern
      'for dependencies between the tables.
      dataSet.EnforceConstraints = False

      Try
         'Open the connection.
         Me.OleDbConnection1.Open()
         'Attempt to fill the dataset through the OleDbDataAdapter1.
         Me.OleDbDataAdapter1.Fill(dataSet)
      Catch fillException As System.Exception
         'Add your error handling code here.
         Throw fillException
      Finally
         'Turn constraint checking back on.
         dataSet.EnforceConstraints = True
         'Close the connection whether or not the exception was thrown.
         Me.OleDbConnection1.Close()
      End Try
   End Sub
End Class