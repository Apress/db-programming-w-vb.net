' Listing 26-13
Imports System.Data.OleDb
Imports System.Runtime.InteropServices

Public Class CActiveDirectory
   Implements IDisposable

   ' Declare the APIs needed to manipulate the RAW SID
   Public Declare Function GetSidSubAuthority Lib "advapi32.dll" (ByRef pSid As Byte, ByVal nSubAuthority As Integer) As Integer
   Public Declare Function GetSidSubAuthorityCount Lib "advapi32.dll" (ByRef pSid As Byte) As Integer
   Public Declare Function GetSidIdentifierAuthority Lib "advapi32.dll" (ByRef pSid As Byte) As Integer

   Public Overloads Declare Sub CopyByValMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef Destination As Byte, ByVal Source As Integer, ByVal Length As Integer)
   Public Overloads Declare Sub CopyByValMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef Destination As Integer, ByVal Source As Integer, ByVal Length As Integer)
   Public Overloads Declare Sub CopyByValMemory Lib "kernel32" Alias "RtlMoveMemory" (ByRef Destination As String, ByVal Source As Integer, ByVal Length As Integer)

   Private Const PR_STR_CONNECTION_STRING As String = "Provider=ADsDSOObject;" & _
      "User Id=UserMan;Password=userman;"
   Private prstrADName As String
   Private prstrADSID As String
   Private prstrUserName As String

   Sub New(ByVal UserName As String)
      prstrUserName = UserName
      prOpenConnection()
   End Sub

   Protected Overrides Sub Finalize()
      ' Do your house keeping here
      prCloseConnection()
      ' Call the base class' destructor
      MyBase.Finalize()
   End Sub

   Public Overloads Sub Dispose() Implements IDisposable.Dispose
      ' Do your house keeping here
      prCloseConnection()
      ' Now you need to make sure the Finalize method isn't
      ' called as well, because you've already done
      ' the house keeping
      GC.SuppressFinalize(Me)
      ' Always call this method on the base class, 
      ' if it implements one
      'MyBase.Dispose()
   End Sub

   ' Database objects
   Private prcnnAD As OleDbConnection
   Private prcmmAD As OleDbCommand
   Private prdrdAD As OleDbDataReader

   Private Sub prOpenConnection()
      ' Instantiate and open connection
      prcnnAD = New OleDbConnection(PR_STR_CONNECTION_STRING)
      prcnnAD.Open()
      prRetrieveUserInformation()
   End Sub

   Private Sub prCloseConnection()
      ' Close connection
      prcnnAD.Close()
   End Sub

   Private Sub prRetrieveUserInformation()
      Dim arrbytSID() As Byte

      Try
         ' Instantiate command
         prcmmAD = New OleDbCommand("SELECT objectSid, samAccountName FROM " & _
            "'LDAP://dotnetservices.biz' WHERE objectCategory='person' AND " & _
            "objectClass='user' AND userPrincipalName='" & prstrUserName & "@dotnetservices.biz'", prcnnAD)
         ' Retrieve user info in data reader
         prdrdAD = prcmmAD.ExecuteReader()
         ' Move to the first row
         If prdrdAD.Read() Then
            ' Save SAM account name (pre-Windows 2000)
            prstrADName = prdrdAD("samAccountName").ToString()
            ' Save human readable SID
            prstrADSID = prConvertSID2SDDL(CType(prdrdAD("objectSid"), Byte()))
         End If
      Catch objE As Exception
         Throw New Exception("An error occurred trying to retrieve the user information from Active Directory.", objE)
      End Try
   End Sub

   Public ReadOnly Property ADName() As String
      Get
         Return prstrADName
      End Get
   End Property

   Public ReadOnly Property ADSID() As String
      Get
         Return prstrADSID
      End Get
   End Property

   Private Function prConvertSID2SDDL(ByVal objSID() As Byte) As String
      Dim strSDDL As String
      Dim pSia As Integer
      Dim pSiaByte(6) As Byte
      Dim pSid(512) As Byte
      Dim pSubAuthorityCount As Integer
      Dim bSubAuthorityCount As Byte
      Dim pAuthority As Integer
      Dim dAuthority, lAuthority As Integer
      Dim cbpSid As Integer
      Dim I As Integer
      Dim AuthCount As Integer

      cbpSid = 0

      For I = LBound(objSID) To UBound(objSID)
         pSid(cbpSid) = objSID(I)
         cbpSid = cbpSid + 1
      Next I

      ' Convert the raw sid into its SDDL form ( S-?-?-???-?????? )
      ' The first item in the S- format is the rivision level.  If we look closely at the
      ' SID structure in the WinNT.H C Header, we find that the revision value for the SID is
      ' stored in the 0th byte to the raw sid.
      '
      ' Another interesting fact is that the last byte of the Identifying authority structure contains
      ' the second component of the SDDL form, so lets retrieve both of those and
      ' place them into the string.
      pSia = GetSidIdentifierAuthority(pSid(0))

      ' The GetSidIdentifierAuthority returns a pointer to the Identifying Authority structure
      ' The pointer must be copied into some memory that VB knows how to manage, so....
      CopyByValMemory(pSiaByte(0), pSia, 6)
      strSDDL = "S-" & LTrim(Str(pSid(0))) & "-" & LTrim(Str(pSiaByte(5))) '

      ' The rest of the SDDL form contains a list of sub authorities separated by
      ' "-"s.  The total number of these authorities can be obtained by
      ' calling the GetSidSubAuthorityCount.  The value returned is a pointer into the
      ' SID memory that contains the Sub Authority value, once again, this memory
      ' must be copied into something that VB knows how to manage.
      '
      ' Notice that only 1 byte is copied.  This is because the sub authority count
      ' is stored in a single byte ( see the SID srtructure definition above )
      pSubAuthorityCount = GetSidSubAuthorityCount(pSid(0))
      CopyByValMemory(bSubAuthorityCount, pSubAuthorityCount, 1)

      ' We can loop throught the sub authorities and convert
      ' their DWORD values to VB longs, then convert them to a
      ' string.
      ' The count is 0 based, so we start a 0 and goto the
      ' number of sub authorities - 1
      For AuthCount = 0 To bSubAuthorityCount - 1
         pAuthority = GetSidSubAuthority(pSid(0), AuthCount)
         CopyByValMemory(lAuthority, pAuthority, Len(lAuthority))

         ' VB by default assumes its data types to be signed types. The sub authorities should
         ' be unsigned and hence the following code has to work around this problem to get the
         ' sub authorities as unsigned data types
         '
         ' Get rid of the most significant bit (the signed bit) if it is set (And &H7FFFFFFF), and then add it
         ' back in into the right location in the double variable (+ 2^31)
         dAuthority = lAuthority

         If ((lAuthority And &H80000000) <> 0) Then
            dAuthority = lAuthority And &H7FFFFFFF
            dAuthority = dAuthority + 2 ^ 31
         End If

         strSDDL = strSDDL & "-" & LTrim(Str(dAuthority))
      Next AuthCount

      Return strSDDL
   End Function
End Class