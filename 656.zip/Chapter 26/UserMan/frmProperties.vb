Public Class frmProperties
    Inherits System.Windows.Forms.Form

   Private prblnAdmin As Boolean
   Private probjUser As CUser
   Private blnDirty As Boolean = False

#Region " Windows Form Designer generated code "

   Public Sub New(ByVal blnAdmin As Boolean)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      prblnAdmin = blnAdmin

      ' Is this the admin user?
      If prblnAdmin Then
         Me.Text = "Admin Properties"
         probjUser = objAdminUser
      Else
         probjUser = New CUser()
      End If

      prDisplayUserProperties()
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents mnuProperties As System.Windows.Forms.ContextMenu
   Friend WithEvents mnuUpdate As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMain As System.Windows.Forms.MainMenu
   Friend WithEvents mnuAdmin As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminProperties As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminPropertiesUpdate As System.Windows.Forms.MenuItem
   Friend WithEvents txtADSID As System.Windows.Forms.TextBox
   Friend WithEvents lblADSID As System.Windows.Forms.Label
   Friend WithEvents lblLastName As System.Windows.Forms.Label
   Friend WithEvents lblFirstName As System.Windows.Forms.Label
   Friend WithEvents lblADName As System.Windows.Forms.Label
   Friend WithEvents lblId As System.Windows.Forms.Label
   Friend WithEvents lblPassword As System.Windows.Forms.Label
   Friend WithEvents lblUserId As System.Windows.Forms.Label
   Friend WithEvents txtLastName As System.Windows.Forms.TextBox
   Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
   Friend WithEvents txtADName As System.Windows.Forms.TextBox
   Friend WithEvents txtId As System.Windows.Forms.TextBox
   Friend WithEvents txtPassword As System.Windows.Forms.TextBox
   Friend WithEvents txtLoginName As System.Windows.Forms.TextBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.mnuProperties = New System.Windows.Forms.ContextMenu()
      Me.mnuUpdate = New System.Windows.Forms.MenuItem()
      Me.mnuMain = New System.Windows.Forms.MainMenu()
      Me.mnuAdmin = New System.Windows.Forms.MenuItem()
      Me.mnuAdminProperties = New System.Windows.Forms.MenuItem()
      Me.mnuAdminPropertiesUpdate = New System.Windows.Forms.MenuItem()
      Me.txtADSID = New System.Windows.Forms.TextBox()
      Me.lblADSID = New System.Windows.Forms.Label()
      Me.lblLastName = New System.Windows.Forms.Label()
      Me.lblFirstName = New System.Windows.Forms.Label()
      Me.lblADName = New System.Windows.Forms.Label()
      Me.lblId = New System.Windows.Forms.Label()
      Me.lblPassword = New System.Windows.Forms.Label()
      Me.lblUserId = New System.Windows.Forms.Label()
      Me.txtLastName = New System.Windows.Forms.TextBox()
      Me.txtFirstName = New System.Windows.Forms.TextBox()
      Me.txtADName = New System.Windows.Forms.TextBox()
      Me.txtId = New System.Windows.Forms.TextBox()
      Me.txtPassword = New System.Windows.Forms.TextBox()
      Me.txtLoginName = New System.Windows.Forms.TextBox()
      Me.SuspendLayout()
      '
      'mnuProperties
      '
      Me.mnuProperties.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuUpdate})
      '
      'mnuUpdate
      '
      Me.mnuUpdate.Index = 0
      Me.mnuUpdate.Text = "&Update"
      '
      'mnuMain
      '
      Me.mnuMain.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdmin})
      '
      'mnuAdmin
      '
      Me.mnuAdmin.Index = 0
      Me.mnuAdmin.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdminProperties})
      Me.mnuAdmin.MergeType = System.Windows.Forms.MenuMerge.MergeItems
      Me.mnuAdmin.Text = "&Admin"
      '
      'mnuAdminProperties
      '
      Me.mnuAdminProperties.Index = 0
      Me.mnuAdminProperties.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdminPropertiesUpdate})
      Me.mnuAdminProperties.MergeType = System.Windows.Forms.MenuMerge.MergeItems
      Me.mnuAdminProperties.Text = "&Properties..."
      '
      'mnuAdminPropertiesUpdate
      '
      Me.mnuAdminPropertiesUpdate.Index = 0
      Me.mnuAdminPropertiesUpdate.MergeType = System.Windows.Forms.MenuMerge.MergeItems
      Me.mnuAdminPropertiesUpdate.Text = "&Update"
      '
      'txtADSID
      '
      Me.txtADSID.Location = New System.Drawing.Point(399, 36)
      Me.txtADSID.Name = "txtADSID"
      Me.txtADSID.ReadOnly = True
      Me.txtADSID.Size = New System.Drawing.Size(211, 22)
      Me.txtADSID.TabIndex = 39
      Me.txtADSID.Text = "txtADSID"
      '
      'lblADSID
      '
      Me.lblADSID.AutoSize = True
      Me.lblADSID.Location = New System.Drawing.Point(317, 40)
      Me.lblADSID.Name = "lblADSID"
      Me.lblADSID.Size = New System.Drawing.Size(53, 15)
      Me.lblADSID.TabIndex = 38
      Me.lblADSID.Text = "AD &SID:"
      '
      'lblLastName
      '
      Me.lblLastName.AutoSize = True
      Me.lblLastName.Location = New System.Drawing.Point(317, 94)
      Me.lblLastName.Name = "lblLastName"
      Me.lblLastName.Size = New System.Drawing.Size(73, 15)
      Me.lblLastName.TabIndex = 36
      Me.lblLastName.Text = "&Last Name:"
      '
      'lblFirstName
      '
      Me.lblFirstName.AutoSize = True
      Me.lblFirstName.Location = New System.Drawing.Point(12, 94)
      Me.lblFirstName.Name = "lblFirstName"
      Me.lblFirstName.Size = New System.Drawing.Size(74, 15)
      Me.lblFirstName.TabIndex = 34
      Me.lblFirstName.Text = "&First Name:"
      '
      'lblADName
      '
      Me.lblADName.AutoSize = True
      Me.lblADName.Location = New System.Drawing.Point(12, 40)
      Me.lblADName.Name = "lblADName"
      Me.lblADName.Size = New System.Drawing.Size(66, 15)
      Me.lblADName.TabIndex = 28
      Me.lblADName.Text = "&AD Name:"
      '
      'lblId
      '
      Me.lblId.AutoSize = True
      Me.lblId.Location = New System.Drawing.Point(12, 12)
      Me.lblId.Name = "lblId"
      Me.lblId.Size = New System.Drawing.Size(20, 15)
      Me.lblId.TabIndex = 26
      Me.lblId.Text = "Id:"
      '
      'lblPassword
      '
      Me.lblPassword.AutoSize = True
      Me.lblPassword.Location = New System.Drawing.Point(317, 68)
      Me.lblPassword.Name = "lblPassword"
      Me.lblPassword.Size = New System.Drawing.Size(67, 15)
      Me.lblPassword.TabIndex = 32
      Me.lblPassword.Text = "&Password:"
      '
      'lblUserId
      '
      Me.lblUserId.AutoSize = True
      Me.lblUserId.Location = New System.Drawing.Point(12, 68)
      Me.lblUserId.Name = "lblUserId"
      Me.lblUserId.Size = New System.Drawing.Size(52, 15)
      Me.lblUserId.TabIndex = 30
      Me.lblUserId.Text = "&User Id:"
      '
      'txtLastName
      '
      Me.txtLastName.Location = New System.Drawing.Point(399, 90)
      Me.txtLastName.MaxLength = 50
      Me.txtLastName.Name = "txtLastName"
      Me.txtLastName.Size = New System.Drawing.Size(211, 22)
      Me.txtLastName.TabIndex = 37
      Me.txtLastName.Text = "txtLastName"
      '
      'txtFirstName
      '
      Me.txtFirstName.Location = New System.Drawing.Point(94, 90)
      Me.txtFirstName.Name = "txtFirstName"
      Me.txtFirstName.Size = New System.Drawing.Size(211, 22)
      Me.txtFirstName.TabIndex = 35
      Me.txtFirstName.Text = "txtFirstName"
      '
      'txtADName
      '
      Me.txtADName.Location = New System.Drawing.Point(94, 36)
      Me.txtADName.Name = "txtADName"
      Me.txtADName.ReadOnly = True
      Me.txtADName.Size = New System.Drawing.Size(211, 22)
      Me.txtADName.TabIndex = 29
      Me.txtADName.Text = "txtADName"
      '
      'txtId
      '
      Me.txtId.Location = New System.Drawing.Point(94, 8)
      Me.txtId.Name = "txtId"
      Me.txtId.ReadOnly = True
      Me.txtId.Size = New System.Drawing.Size(211, 22)
      Me.txtId.TabIndex = 27
      Me.txtId.Text = "txtId"
      '
      'txtPassword
      '
      Me.txtPassword.Location = New System.Drawing.Point(399, 62)
      Me.txtPassword.MaxLength = 50
      Me.txtPassword.Name = "txtPassword"
      Me.txtPassword.Size = New System.Drawing.Size(211, 22)
      Me.txtPassword.TabIndex = 33
      Me.txtPassword.Text = "txtPassword"
      '
      'txtLoginName
      '
      Me.txtLoginName.Location = New System.Drawing.Point(94, 62)
      Me.txtLoginName.Name = "txtLoginName"
      Me.txtLoginName.Size = New System.Drawing.Size(211, 22)
      Me.txtLoginName.TabIndex = 31
      Me.txtLoginName.Text = "txtLoginName"
      '
      'frmProperties
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(622, 123)
      Me.ContextMenu = Me.mnuProperties
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtADSID, Me.lblADSID, Me.lblLastName, Me.lblFirstName, Me.lblADName, Me.lblId, Me.lblPassword, Me.lblUserId, Me.txtLastName, Me.txtFirstName, Me.txtADName, Me.txtId, Me.txtPassword, Me.txtLoginName})
      Me.MaximizeBox = False
      Me.Menu = Me.mnuMain
      Me.MinimizeBox = False
      Me.Name = "frmProperties"
      Me.ShowInTaskbar = False
      Me.Text = "Properties"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub frmProperties_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
      If blnDirty Then
         MsgBox("The properties has been changed. Do you want to save the changes?", _
          MsgBoxStyle.YesNoCancel Or MsgBoxStyle.Question, "Save Changes")
      End If
   End Sub

   Private Sub mnuUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuUpdate.Click
      prUpdateUserProperties()
      probjUser.UpdateDataSource()
   End Sub

   Private Sub prDisplayUserProperties()
      txtId.Text = probjUser.Id.ToString()
      txtADName.Text = probjUser.ADName
      txtADSID.Text = probjUser.ADSID
      txtLoginName.Text = probjUser.LoginName
      txtFirstName.Text = probjUser.FirstName
      txtLastName.Text = probjUser.LastName
      txtPassword.Text = probjUser.Password
   End Sub

   Private Sub prUpdateUserProperties()
      probjUser.ADSID = txtADSID.Text
      probjUser.ADName = txtADName.Text
      probjUser.LoginName = txtLoginName.Text
      probjUser.FirstName = txtFirstName.Text
      probjUser.LastName = txtLastName.Text
      probjUser.Password = txtPassword.Text
   End Sub
End Class