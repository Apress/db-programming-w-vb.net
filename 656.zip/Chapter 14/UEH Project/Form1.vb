Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnEnableUEH As System.Windows.Forms.Button
   Friend WithEvents btnUseParentExceptionHandling As System.Windows.Forms.Button
   Friend WithEvents btnIgnoreExceptions As System.Windows.Forms.Button
   Friend WithEvents btnRaiseSystemException As System.Windows.Forms.Button
   Friend WithEvents btnRaiseUserException As System.Windows.Forms.Button
   Friend WithEvents btnDetermineUserException As System.Windows.Forms.Button
   Friend WithEvents btnCatchOpenConnectionException As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnEnableUEH = New System.Windows.Forms.Button()
      Me.btnUseParentExceptionHandling = New System.Windows.Forms.Button()
      Me.btnIgnoreExceptions = New System.Windows.Forms.Button()
      Me.btnRaiseSystemException = New System.Windows.Forms.Button()
      Me.btnRaiseUserException = New System.Windows.Forms.Button()
      Me.btnDetermineUserException = New System.Windows.Forms.Button()
      Me.btnCatchOpenConnectionException = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnEnableUEH
      '
      Me.btnEnableUEH.Location = New System.Drawing.Point(12, 17)
      Me.btnEnableUEH.Name = "btnEnableUEH"
      Me.btnEnableUEH.Size = New System.Drawing.Size(272, 23)
      Me.btnEnableUEH.TabIndex = 0
      Me.btnEnableUEH.Text = "Enable Unstructured Exception Handling"
      '
      'btnUseParentExceptionHandling
      '
      Me.btnUseParentExceptionHandling.Location = New System.Drawing.Point(12, 46)
      Me.btnUseParentExceptionHandling.Name = "btnUseParentExceptionHandling"
      Me.btnUseParentExceptionHandling.Size = New System.Drawing.Size(272, 23)
      Me.btnUseParentExceptionHandling.TabIndex = 1
      Me.btnUseParentExceptionHandling.Text = "Use Parent Exception Handling"
      '
      'btnIgnoreExceptions
      '
      Me.btnIgnoreExceptions.Location = New System.Drawing.Point(12, 74)
      Me.btnIgnoreExceptions.Name = "btnIgnoreExceptions"
      Me.btnIgnoreExceptions.Size = New System.Drawing.Size(272, 23)
      Me.btnIgnoreExceptions.TabIndex = 2
      Me.btnIgnoreExceptions.Text = "Ignore Exceptions"
      '
      'btnRaiseSystemException
      '
      Me.btnRaiseSystemException.Location = New System.Drawing.Point(12, 102)
      Me.btnRaiseSystemException.Name = "btnRaiseSystemException"
      Me.btnRaiseSystemException.Size = New System.Drawing.Size(272, 23)
      Me.btnRaiseSystemException.TabIndex = 3
      Me.btnRaiseSystemException.Text = "Raise System Exception"
      '
      'btnRaiseUserException
      '
      Me.btnRaiseUserException.Location = New System.Drawing.Point(12, 130)
      Me.btnRaiseUserException.Name = "btnRaiseUserException"
      Me.btnRaiseUserException.Size = New System.Drawing.Size(272, 23)
      Me.btnRaiseUserException.TabIndex = 4
      Me.btnRaiseUserException.Text = "Raise User Exception"
      '
      'btnDetermineUserException
      '
      Me.btnDetermineUserException.Location = New System.Drawing.Point(12, 158)
      Me.btnDetermineUserException.Name = "btnDetermineUserException"
      Me.btnDetermineUserException.Size = New System.Drawing.Size(272, 23)
      Me.btnDetermineUserException.TabIndex = 5
      Me.btnDetermineUserException.Text = "Determine User Exception"
      '
      'btnCatchOpenConnectionException
      '
      Me.btnCatchOpenConnectionException.Location = New System.Drawing.Point(12, 186)
      Me.btnCatchOpenConnectionException.Name = "btnCatchOpenConnectionException"
      Me.btnCatchOpenConnectionException.Size = New System.Drawing.Size(272, 23)
      Me.btnCatchOpenConnectionException.TabIndex = 6
      Me.btnCatchOpenConnectionException.Text = "Catch Open Connection Exception"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(292, 219)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCatchOpenConnectionException, Me.btnDetermineUserException, Me.btnRaiseUserException, Me.btnRaiseSystemException, Me.btnIgnoreExceptions, Me.btnUseParentExceptionHandling, Me.btnEnableUEH})
      Me.Name = "Form1"
      Me.Text = "UEH Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnEnableUEH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnableUEH.Click
      'EnableUnstructuredExceptionHandling1()
      'EnableUnstructuredExceptionHandling2()
      'EnableUnstructuredExceptionHandling3()
      EnableUnstructuredExceptionHandling4()
   End Sub

   Private Sub btnUseParentExceptionHandling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUseParentExceptionHandling.Click
      UsingParentExceptionHandling()
   End Sub

   Private Sub btnIgnoreExceptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIgnoreExceptions.Click
      IgnoreExceptions()
   End Sub

   Private Sub btnRaiseSystemException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseSystemException.Click
      RaiseSystemException(5)
   End Sub

   Private Sub btnRaiseUserException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRaiseUserException.Click
      RaiseUserException(5)
   End Sub

   Private Sub btnDetermineUserException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetermineUserException.Click
      DetermineUserException(5)
   End Sub

   Private Sub btnCatchOpenConnectionException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCatchOpenConnectionException.Click
      CatchOpenConnectionException()
   End Sub
End Class