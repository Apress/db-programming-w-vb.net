Imports System.Data.SqlClient

Module General
   ' Listing 14-14
   Public Sub EnableUnstructuredExceptionHandling1()
      ' Enable local exception handling
      On Error GoTo Err_EnableUnstructuredExceptionHandlingFromLabel

      Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel:
   End Sub

   ' Listing 14-15
   Public Sub EnableUnstructuredExceptionHandling2()
      ' Enable local exception handling
      On Error GoTo 5

      Exit Sub
5:
   End Sub

   ' Listing 14-16
   Public Sub EnableUnstructuredExceptionHandling3()
      On Error GoTo Err_EnableUnstructuredExceptionHandlingFromLabel1

      On Error GoTo Err_EnableUnstructuredExceptionHandlingFromLabel2

      Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel1:
      Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel2:
   End Sub

   ' Listing 14-17
   Public Sub EnableUnstructuredExceptionHandling4()
      Dim intResult As Integer
      Dim intValue As Integer

      On Error GoTo Err_EnableUnstructuredExceptionHandlingFromLabel1
      GoTo 20
19:
      intValue = 0
      intResult = 9 / intValue

      On Error GoTo Err_EnableUnstructuredExceptionHandlingFromLabel2
20:
      intValue = 0
      intResult = 9 / intValue

      Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel1:
      MsgBox("Err_EnableUnstructuredExceptionHandlingFromLabel1")
      Exit Sub
Err_EnableUnstructuredExceptionHandlingFromLabel2:
      GoTo 19
   End Sub

   ' Listing 14-18-1
   Public Sub UsingParentExceptionHandling()
      On Error GoTo Err_EnableUnstructuredExceptionHandling

      UsesParentExceptionHandling()

      Exit Sub
Err_EnableUnstructuredExceptionHandling:
      MsgBox("Err_EnableUnstructuredExceptionHandling")
   End Sub

   ' Listing 14-18-2
   Public Sub UsesParentExceptionHandling()
      Dim intResult As Integer
      Dim intValue As Integer

      intValue = 0
      intResult = 9 / intValue
   End Sub

   ' Listing 14-19
   Public Sub DisableUnstructuredExceptionHandling()
      ' Enable structured exception handling
      On Error GoTo 5

      ' Disable structured Exception handling
      On Error GoTo -1

      Exit Sub
5:
      Exit Sub
0:
      MsgBox("Line Number 0 has been reached!")
   End Sub

   ' Listing 14-20
   Public Sub IgnoreExceptions()
      Dim intResult As Integer
      Dim intValue As Integer

      On Error Resume Next

      ' Throw an exception
      intValue = 0
      intResult = 9 / intValue

      MsgBox("Was an exception thrown?", MsgBoxStyle.Question)
   End Sub

   ' Listing 14-21
   Public Sub ResolveException()
      On Error GoTo Err_EnableUnstructuredExceptionHandling

      Exit Sub
Err_EnableUnstructuredExceptionHandling:
      ' Resolve exception
      '...

      ' Continue execution by retrying the offending line of code
      Resume
   End Sub

   ' Listing 14-22
   Public Sub WorkAroundAnException()
      On Error GoTo Err_EnableUnstructuredExceptionHandling

      Exit Sub
Err_EnableUnstructuredExceptionHandling:
      ' Take other actions to work around the exception
      '...

      ' Continue execution from the following line
      Resume Next
   End Sub

   ' Listing 14-23
   Public Sub RaiseSystemException(ByVal vintExceptionNum As Integer)
      Err.Raise(vintExceptionNum)
   End Sub

   ' Listing 14-24
   Public Sub RaiseUserException(ByVal vintExceptionNum As Integer)
      Err.Raise(vbObjectError + vintExceptionNum)
   End Sub

   ' Listing 14-25
   Public Sub DetermineUserException(ByVal vlngExceptionNum As Long)
      Dim lngExceptionNum As Long

      lngExceptionNum = vlngExceptionNum - vbObjectError

      ' Determine if this is a user-defined exception number
      If lngExceptionNum > 0 And lngExceptionNum < 65535 Then
         MsgBox("User-defined Exception")
      Else
         MsgBox("Visual Basic Exception")
      End If
   End Sub

   ' Listing 14-26
   Public Sub CatchOpenConnectionException()
      Const STR_CONNECTION_STRING As String = "Data Source=USERMANPC1;" & _
       "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

      Dim cnnUserMan As SqlConnection

      On Error GoTo Err_EnableUnstructuredExceptionHandling

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(STR_CONNECTION_STRING)
      cnnUserMan.Open()

      Exit Sub
Err_EnableUnstructuredExceptionHandling:
      MsgBox(Err.Description & vbCrLf & Err.Erl & vbCrLf & Err.Number & vbCrLf & _
       Err.Source)
   End Sub
End Module