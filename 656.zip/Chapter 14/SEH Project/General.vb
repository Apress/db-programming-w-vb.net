Imports System.Data.SqlClient

Module General
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
     "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   Private Const PR_STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

   ' Listing 14-2
   Public Sub TwoStructuredExceptionHandlers()
      Dim lngResult As Long
      Dim lngValue As Long = 0

      Try   ' First exception handler
         lngResult = 8 / lngValue
      Catch objFirst As Exception
         MsgBox(objFirst.Message)
      End Try

      Try   ' Second exception handler
         lngResult = 8 / lngValue
      Catch objSecond As Exception
         MsgBox(objSecond.Source)
      End Try
   End Sub

   ' Listing 14-3
   Public Sub SimpleCatchBlock()
      Dim lngResult As Long
      Dim lngValue As Long = 0

      Try
         lngResult = 8 / lngValue
      Catch
         MsgBox("Catch")
      End Try
   End Sub

   ' Listing 14-4
   Public Sub CatchBlockWithDefaultExceptionObject()
      Dim lngResult As Long
      Dim lngValue As Long = 0
      Dim objE As Exception

      Try
         lngResult = 8 / lngValue
      Catch objE
         MsgBox(objE.ToString)
      End Try
   End Sub

   ' Listing 14-5
   Public Sub ThrowIndexOutOfRangeException()
      Dim arrlngException(2) As Long

      Try
         arrlngException(3) = 5
      Catch objE As Exception
         MsgBox(objE.ToString)
      End Try
   End Sub

   ' Listing 14-6
   Public Sub ThrowNullReferenceException()
      Dim objException As New Exception()

      Try
         objException = Nothing
         MsgBox(objException.Message)
      Catch objE As Exception
         MsgBox(objE.ToString)
      End Try
   End Sub

   ' Listing 14-7
   Public Sub ThrowInvalidOperationException()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim drdUser As SqlDataReader

      Try
         ' Instantiate and open the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         cnnUserMan.Open()
         ' Instantiate command
         cmmUser = New SqlCommand(PR_STR_SQL_USER_SELECT, cnnUserMan)
         ' Instantiate and populate data reader
         drdUser = cmmUser.ExecuteReader()
         ' Execute query while data reader is open
         cmmUser.ExecuteNonQuery()
      Catch objE As Exception
         MsgBox(objE.ToString)
      End Try
   End Sub

   ' Listing 14-8
   Public Sub ThrowArgumentNullException()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dstUser As DataSet
      Dim dadUser As SqlDataAdapter

      Try
         ' Instantiate and open the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         cnnUserMan.Open()
         ' Instantiate command
         cmmUser = New SqlCommand()
         ' Instatiate data adapter
         dadUser = New SqlDataAdapter(cmmUser)
         ' Update data source
         dadUser.Update(dstUser)
      Catch objE As Exception
         MsgBox(objE.ToString)
      End Try
   End Sub

   ' Listing 14-9
   Public Sub ThrowArgumentOutOfRangeException()
      Try
         ' Display the first 200 chars from the connection string
         MsgBox(PR_STR_CONNECTION_STRING.Substring(1, 200))
      Catch objE As Exception
         MsgBox(objE.ToString)
      End Try
   End Sub

   ' Listing 14-10
   Public Sub TypeFilterExceptions()
      Dim arrlngException(2) As Long
      Dim objException As Exception
      Dim lngResult As Long
      Dim lngValue As Long = 0

      Try
         arrlngException(3) = 5
         MsgBox(objException.Message)
         lngResult = 8 / lngValue
      Catch objE As NullReferenceException
         MsgBox("NullReferenceException")
      Catch objE As IndexOutOfRangeException
         MsgBox("IndexOutOfRangeException")
      Catch objE As Exception
         MsgBox("Exception")
      End Try
   End Sub

   ' Listing 14-11
   Public Sub UserFilterExceptions()
      Dim objException1 As New Exception()
      Dim objException2 As Exception

      Try
         MsgBox(objException1.Message)
         MsgBox(objException2.Message)
      Catch objE As NullReferenceException When objException1 Is Nothing
         MsgBox("objException NullReferenceException1")
      Catch objE As NullReferenceException When objException2 Is Nothing
         MsgBox("objException NullReferenceException2")
      Catch objE As Exception
         MsgBox("Exception")
      End Try
   End Sub

   Public Sub ThrowCustomException()
      Dim objUM As New UserManException()

      objUM.Source = "Test"
      Try
         Throw objUM
      Catch objE As Exception
         MsgBox(objE.Source)
      End Try
   End Sub

   ' Listing 14-13
   Public Sub CatchSqlConnectionClassExceptions()
      Dim cnnUserMan As SqlConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING & _
            ";Connection Timeout=-1")
      Catch objException As ArgumentException
         If objException.TargetSite.Name = "SetConnectTimeout" Then
            MsgBox(objException.StackTrace)
         End If
      End Try
   End Sub
End Module