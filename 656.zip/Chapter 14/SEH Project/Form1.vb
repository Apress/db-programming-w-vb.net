Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnTwoStructuredExceptionHandlers As System.Windows.Forms.Button
   Friend WithEvents btnSimpleCatchBlock As System.Windows.Forms.Button
   Friend WithEvents btnCatchBlockWithDefaultExceptionObject As System.Windows.Forms.Button
   Friend WithEvents btnThrowIndexOutOfRangeException As System.Windows.Forms.Button
   Friend WithEvents btnThrowNullReferenceException As System.Windows.Forms.Button
   Friend WithEvents btnThrowInvalidOperationException As System.Windows.Forms.Button
   Friend WithEvents btnThrowArgumentNullException As System.Windows.Forms.Button
   Friend WithEvents btnThrowArgumentOutOfRangeException As System.Windows.Forms.Button
   Friend WithEvents btnTypeFilterExceptions As System.Windows.Forms.Button
   Friend WithEvents btnUserFilterExceptions As System.Windows.Forms.Button
   Friend WithEvents btnThrowCustomException As System.Windows.Forms.Button
   Friend WithEvents btnCatchSqlConnectionClassExceptions As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnTwoStructuredExceptionHandlers = New System.Windows.Forms.Button()
      Me.btnSimpleCatchBlock = New System.Windows.Forms.Button()
      Me.btnCatchBlockWithDefaultExceptionObject = New System.Windows.Forms.Button()
      Me.btnThrowIndexOutOfRangeException = New System.Windows.Forms.Button()
      Me.btnThrowNullReferenceException = New System.Windows.Forms.Button()
      Me.btnThrowInvalidOperationException = New System.Windows.Forms.Button()
      Me.btnThrowArgumentNullException = New System.Windows.Forms.Button()
      Me.btnThrowArgumentOutOfRangeException = New System.Windows.Forms.Button()
      Me.btnTypeFilterExceptions = New System.Windows.Forms.Button()
      Me.btnUserFilterExceptions = New System.Windows.Forms.Button()
      Me.btnThrowCustomException = New System.Windows.Forms.Button()
      Me.btnCatchSqlConnectionClassExceptions = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnTwoStructuredExceptionHandlers
      '
      Me.btnTwoStructuredExceptionHandlers.Location = New System.Drawing.Point(10, 12)
      Me.btnTwoStructuredExceptionHandlers.Name = "btnTwoStructuredExceptionHandlers"
      Me.btnTwoStructuredExceptionHandlers.Size = New System.Drawing.Size(271, 23)
      Me.btnTwoStructuredExceptionHandlers.TabIndex = 0
      Me.btnTwoStructuredExceptionHandlers.Text = "Two Structured Exception Handlers"
      '
      'btnSimpleCatchBlock
      '
      Me.btnSimpleCatchBlock.Location = New System.Drawing.Point(10, 40)
      Me.btnSimpleCatchBlock.Name = "btnSimpleCatchBlock"
      Me.btnSimpleCatchBlock.Size = New System.Drawing.Size(271, 23)
      Me.btnSimpleCatchBlock.TabIndex = 1
      Me.btnSimpleCatchBlock.Text = "Simple Catch Block"
      '
      'btnCatchBlockWithDefaultExceptionObject
      '
      Me.btnCatchBlockWithDefaultExceptionObject.Location = New System.Drawing.Point(10, 68)
      Me.btnCatchBlockWithDefaultExceptionObject.Name = "btnCatchBlockWithDefaultExceptionObject"
      Me.btnCatchBlockWithDefaultExceptionObject.Size = New System.Drawing.Size(271, 23)
      Me.btnCatchBlockWithDefaultExceptionObject.TabIndex = 2
      Me.btnCatchBlockWithDefaultExceptionObject.Text = "Catch Block With Default Exception Object"
      '
      'btnThrowIndexOutOfRangeException
      '
      Me.btnThrowIndexOutOfRangeException.Location = New System.Drawing.Point(10, 96)
      Me.btnThrowIndexOutOfRangeException.Name = "btnThrowIndexOutOfRangeException"
      Me.btnThrowIndexOutOfRangeException.Size = New System.Drawing.Size(271, 23)
      Me.btnThrowIndexOutOfRangeException.TabIndex = 3
      Me.btnThrowIndexOutOfRangeException.Text = "Throw Index Out Of Range Exception"
      '
      'btnThrowNullReferenceException
      '
      Me.btnThrowNullReferenceException.Location = New System.Drawing.Point(10, 124)
      Me.btnThrowNullReferenceException.Name = "btnThrowNullReferenceException"
      Me.btnThrowNullReferenceException.Size = New System.Drawing.Size(271, 23)
      Me.btnThrowNullReferenceException.TabIndex = 4
      Me.btnThrowNullReferenceException.Text = "Throw Null Reference Exception"
      '
      'btnThrowInvalidOperationException
      '
      Me.btnThrowInvalidOperationException.Location = New System.Drawing.Point(10, 152)
      Me.btnThrowInvalidOperationException.Name = "btnThrowInvalidOperationException"
      Me.btnThrowInvalidOperationException.Size = New System.Drawing.Size(271, 23)
      Me.btnThrowInvalidOperationException.TabIndex = 5
      Me.btnThrowInvalidOperationException.Text = "Throw Invalid Operation Exception"
      '
      'btnThrowArgumentNullException
      '
      Me.btnThrowArgumentNullException.Location = New System.Drawing.Point(10, 180)
      Me.btnThrowArgumentNullException.Name = "btnThrowArgumentNullException"
      Me.btnThrowArgumentNullException.Size = New System.Drawing.Size(271, 23)
      Me.btnThrowArgumentNullException.TabIndex = 6
      Me.btnThrowArgumentNullException.Text = "Throw Argument Null Exception"
      '
      'btnThrowArgumentOutOfRangeException
      '
      Me.btnThrowArgumentOutOfRangeException.Location = New System.Drawing.Point(10, 208)
      Me.btnThrowArgumentOutOfRangeException.Name = "btnThrowArgumentOutOfRangeException"
      Me.btnThrowArgumentOutOfRangeException.Size = New System.Drawing.Size(271, 23)
      Me.btnThrowArgumentOutOfRangeException.TabIndex = 7
      Me.btnThrowArgumentOutOfRangeException.Text = "Throw Argument Out Of Range Exception"
      '
      'btnTypeFilterExceptions
      '
      Me.btnTypeFilterExceptions.Location = New System.Drawing.Point(10, 236)
      Me.btnTypeFilterExceptions.Name = "btnTypeFilterExceptions"
      Me.btnTypeFilterExceptions.Size = New System.Drawing.Size(271, 23)
      Me.btnTypeFilterExceptions.TabIndex = 8
      Me.btnTypeFilterExceptions.Text = "Type Filter Exceptions"
      '
      'btnUserFilterExceptions
      '
      Me.btnUserFilterExceptions.Location = New System.Drawing.Point(10, 264)
      Me.btnUserFilterExceptions.Name = "btnUserFilterExceptions"
      Me.btnUserFilterExceptions.Size = New System.Drawing.Size(271, 23)
      Me.btnUserFilterExceptions.TabIndex = 9
      Me.btnUserFilterExceptions.Text = "User Filter Exceptions"
      '
      'btnThrowCustomException
      '
      Me.btnThrowCustomException.Location = New System.Drawing.Point(10, 292)
      Me.btnThrowCustomException.Name = "btnThrowCustomException"
      Me.btnThrowCustomException.Size = New System.Drawing.Size(271, 23)
      Me.btnThrowCustomException.TabIndex = 10
      Me.btnThrowCustomException.Text = "Throw Custom Exception"
      '
      'btnCatchSqlConnectionClassExceptions
      '
      Me.btnCatchSqlConnectionClassExceptions.Location = New System.Drawing.Point(10, 320)
      Me.btnCatchSqlConnectionClassExceptions.Name = "btnCatchSqlConnectionClassExceptions"
      Me.btnCatchSqlConnectionClassExceptions.Size = New System.Drawing.Size(271, 23)
      Me.btnCatchSqlConnectionClassExceptions.TabIndex = 11
      Me.btnCatchSqlConnectionClassExceptions.Text = "Catch SqlConnection Class Exceptions"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(288, 350)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCatchSqlConnectionClassExceptions, Me.btnThrowCustomException, Me.btnUserFilterExceptions, Me.btnTypeFilterExceptions, Me.btnThrowArgumentOutOfRangeException, Me.btnThrowArgumentNullException, Me.btnThrowInvalidOperationException, Me.btnThrowNullReferenceException, Me.btnThrowIndexOutOfRangeException, Me.btnCatchBlockWithDefaultExceptionObject, Me.btnSimpleCatchBlock, Me.btnTwoStructuredExceptionHandlers})
      Me.Name = "Form1"
      Me.Text = "SEH Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnTwoStructuredExceptionHandlers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTwoStructuredExceptionHandlers.Click
      TwoStructuredExceptionHandlers()
   End Sub

   Private Sub btnSimpleCatchBlock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpleCatchBlock.Click
      SimpleCatchBlock()
   End Sub

   Private Sub btnCatchBlockWithDefaultExceptionObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCatchBlockWithDefaultExceptionObject.Click
      CatchBlockWithDefaultExceptionObject()
   End Sub

   Private Sub btnThrowIndexOutOfRangeException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThrowIndexOutOfRangeException.Click
      ThrowIndexOutOfRangeException()
   End Sub

   Private Sub btnThrowNullReferenceException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThrowNullReferenceException.Click
      ThrowNullReferenceException()
   End Sub

   Private Sub btnThrowInvalidOperationException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThrowInvalidOperationException.Click
      ThrowInvalidOperationException()
   End Sub

   Private Sub btnThrowArgumentNullException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThrowArgumentNullException.Click
      ThrowArgumentNullException()
   End Sub

   Private Sub btnThrowArgumentOutOfRangeException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThrowArgumentOutOfRangeException.Click
      ThrowArgumentOutOfRangeException()
   End Sub

   Private Sub btnTypeFilterExceptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTypeFilterExceptions.Click
      TypeFilterExceptions()
   End Sub

   Private Sub btnUserFilterExceptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserFilterExceptions.Click
      UserFilterExceptions()
   End Sub

   Private Sub btnThrowCustomException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThrowCustomException.Click
      ThrowCustomException()
   End Sub

   Private Sub btnCatchSqlConnectionClassExceptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCatchSqlConnectionClassExceptions.Click
      CatchSqlConnectionClassExceptions()
   End Sub
End Class
