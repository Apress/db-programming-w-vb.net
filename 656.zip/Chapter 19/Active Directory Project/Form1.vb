Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnBindToUserManObject As System.Windows.Forms.Button
   Friend WithEvents btnSearchForSpecificADObject As System.Windows.Forms.Button
   Friend WithEvents btnSearchForAllADUserObjects As System.Windows.Forms.Button
   Friend WithEvents btnReturnNonDefaultNodeProperties As System.Windows.Forms.Button
   Friend WithEvents btnEditUserObjectProperty As System.Windows.Forms.Button
   Friend WithEvents btnAddNewUserObjectProperty As System.Windows.Forms.Button
   Friend WithEvents btnManipulateUserObjectProperty As System.Windows.Forms.Button
   Friend WithEvents btnAccessADWithOLEDB As System.Windows.Forms.Button
   Friend WithEvents btnGetSIDSAMAccountName As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnBindToUserManObject = New System.Windows.Forms.Button()
      Me.btnSearchForSpecificADObject = New System.Windows.Forms.Button()
      Me.btnSearchForAllADUserObjects = New System.Windows.Forms.Button()
      Me.btnReturnNonDefaultNodeProperties = New System.Windows.Forms.Button()
      Me.btnEditUserObjectProperty = New System.Windows.Forms.Button()
      Me.btnAddNewUserObjectProperty = New System.Windows.Forms.Button()
      Me.btnManipulateUserObjectProperty = New System.Windows.Forms.Button()
      Me.btnAccessADWithOLEDB = New System.Windows.Forms.Button()
      Me.btnGetSIDSAMAccountName = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnBindToUserManObject
      '
      Me.btnBindToUserManObject.Location = New System.Drawing.Point(9, 16)
      Me.btnBindToUserManObject.Name = "btnBindToUserManObject"
      Me.btnBindToUserManObject.Size = New System.Drawing.Size(275, 23)
      Me.btnBindToUserManObject.TabIndex = 0
      Me.btnBindToUserManObject.Text = "Bind to UserMan Object"
      '
      'btnSearchForSpecificADObject
      '
      Me.btnSearchForSpecificADObject.Location = New System.Drawing.Point(9, 44)
      Me.btnSearchForSpecificADObject.Name = "btnSearchForSpecificADObject"
      Me.btnSearchForSpecificADObject.Size = New System.Drawing.Size(275, 23)
      Me.btnSearchForSpecificADObject.TabIndex = 1
      Me.btnSearchForSpecificADObject.Text = "Search For Specific AD Object"
      '
      'btnSearchForAllADUserObjects
      '
      Me.btnSearchForAllADUserObjects.Location = New System.Drawing.Point(9, 72)
      Me.btnSearchForAllADUserObjects.Name = "btnSearchForAllADUserObjects"
      Me.btnSearchForAllADUserObjects.Size = New System.Drawing.Size(275, 23)
      Me.btnSearchForAllADUserObjects.TabIndex = 2
      Me.btnSearchForAllADUserObjects.Text = "Search For All AD User Objects"
      '
      'btnReturnNonDefaultNodeProperties
      '
      Me.btnReturnNonDefaultNodeProperties.Location = New System.Drawing.Point(9, 100)
      Me.btnReturnNonDefaultNodeProperties.Name = "btnReturnNonDefaultNodeProperties"
      Me.btnReturnNonDefaultNodeProperties.Size = New System.Drawing.Size(275, 23)
      Me.btnReturnNonDefaultNodeProperties.TabIndex = 3
      Me.btnReturnNonDefaultNodeProperties.Text = "Return Non-Default Node Properties"
      '
      'btnEditUserObjectProperty
      '
      Me.btnEditUserObjectProperty.Location = New System.Drawing.Point(9, 128)
      Me.btnEditUserObjectProperty.Name = "btnEditUserObjectProperty"
      Me.btnEditUserObjectProperty.Size = New System.Drawing.Size(275, 23)
      Me.btnEditUserObjectProperty.TabIndex = 4
      Me.btnEditUserObjectProperty.Text = "Edit User Object Property"
      '
      'btnAddNewUserObjectProperty
      '
      Me.btnAddNewUserObjectProperty.Location = New System.Drawing.Point(9, 156)
      Me.btnAddNewUserObjectProperty.Name = "btnAddNewUserObjectProperty"
      Me.btnAddNewUserObjectProperty.Size = New System.Drawing.Size(275, 23)
      Me.btnAddNewUserObjectProperty.TabIndex = 5
      Me.btnAddNewUserObjectProperty.Text = "Add New User Object Property"
      '
      'btnManipulateUserObjectProperty
      '
      Me.btnManipulateUserObjectProperty.Location = New System.Drawing.Point(9, 184)
      Me.btnManipulateUserObjectProperty.Name = "btnManipulateUserObjectProperty"
      Me.btnManipulateUserObjectProperty.Size = New System.Drawing.Size(275, 23)
      Me.btnManipulateUserObjectProperty.TabIndex = 6
      Me.btnManipulateUserObjectProperty.Text = "Manipulate User Object Property"
      '
      'btnAccessADWithOLEDB
      '
      Me.btnAccessADWithOLEDB.Location = New System.Drawing.Point(9, 212)
      Me.btnAccessADWithOLEDB.Name = "btnAccessADWithOLEDB"
      Me.btnAccessADWithOLEDB.Size = New System.Drawing.Size(275, 23)
      Me.btnAccessADWithOLEDB.TabIndex = 7
      Me.btnAccessADWithOLEDB.Text = "Access AD with OLE DB"
      '
      'btnGetSIDSAMAccountName
      '
      Me.btnGetSIDSAMAccountName.Location = New System.Drawing.Point(9, 240)
      Me.btnGetSIDSAMAccountName.Name = "btnGetSIDSAMAccountName"
      Me.btnGetSIDSAMAccountName.Size = New System.Drawing.Size(275, 23)
      Me.btnGetSIDSAMAccountName.TabIndex = 8
      Me.btnGetSIDSAMAccountName.Text = "Get SID && SAM Account Name"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(292, 270)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnGetSIDSAMAccountName, Me.btnAccessADWithOLEDB, Me.btnManipulateUserObjectProperty, Me.btnAddNewUserObjectProperty, Me.btnEditUserObjectProperty, Me.btnReturnNonDefaultNodeProperties, Me.btnSearchForAllADUserObjects, Me.btnSearchForSpecificADObject, Me.btnBindToUserManObject})
      Me.Name = "Form1"
      Me.Text = "Active Directory Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnBindToUserManObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBindToUserManObject.Click
      BindToUserManObjectInAD()
   End Sub

   Private Sub btnSearchForSpecificADObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchForSpecificADObject.Click
      SearchForSpecificObjectInAD()
   End Sub

   Private Sub btnSearchForAllADUserObjects_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchForAllADUserObjects.Click
      SearchForAllUserObjectsInAD()
   End Sub

   Private Sub btnReturnNonDefaultNodeProperties_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReturnNonDefaultNodeProperties.Click
      ReturnNonDefaultNodeProperties()
   End Sub

   Private Sub btnEditUserObjectProperty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditUserObjectProperty.Click
      EditUserProperty()
   End Sub

   Private Sub btnAddNewUserObjectProperty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNewUserObjectProperty.Click
      AddNewUserProperty()
   End Sub

   Private Sub btnManipulateUserObjectProperty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManipulateUserObjectProperty.Click
      ManipulateUserProperty()
   End Sub

   Private Sub btnAccessADWithOLEDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAccessADWithOLEDB.Click
      AccessADWithOleDb()
   End Sub

   Private Sub btnGetSIDSAMAccountName_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetSIDSAMAccountName.Click
      GetSIDAndSAMAccountNameFromAD()
   End Sub
End Class
