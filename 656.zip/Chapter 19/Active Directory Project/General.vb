Option Strict On
Option Explicit On 

Imports System.DirectoryServices
Imports System.Data.OleDb
Imports System.DirectoryServices.Interop

Module General
   ' Listing 19-1
	Public Sub BindToUserManObjectInAD()
      Dim objEntry As DirectoryEntry

      objEntry = New DirectoryEntry( _
         "LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", _
         "Administrator", "AdminPwd")
	End Sub

   ' Listing 19-2
   Public Sub SearchForSpecificObjectInAD()
      Dim objEntry As DirectoryEntry
      Dim objSearcher As DirectorySearcher
      Dim objSearchResult As SearchResult

      ' Instantiate and bind to Users node in AD
      objEntry = New DirectoryEntry("LDAP://CN=Users,DC=userman,DC=dk", _
         "UserMan", "userman")

      ' Set up to search for UserMan on the Users node
      objSearcher = New DirectorySearcher(objEntry, "(&(objectClass=user)" & _
         "(objectCategory=person)(userPrincipalName=userman@userman.dk))")

      ' Find the user
      objSearchResult = objSearcher.FindOne()

      ' Check if the user was found
      If Not objSearchResult Is Nothing Then
         ' Display path for user
         MsgBox("Users Path: " & objSearchResult.Path)
      Else
         MsgBox("User not found!")
      End If
   End Sub

   ' Listing 19-3
   Public Sub SearchForAllUserObjectsInAD()
      Dim objEntry As DirectoryEntry
      Dim objSearcher As DirectorySearcher
      Dim objSearchResult As SearchResult
      Dim objSearchResults As SearchResultCollection

      ' Instantiate and bind to root node in AD
      objEntry = New DirectoryEntry( _
         "LDAP://DC=userman,DC=dk", "UserMan", "userman")

      ' Set up to search for UserMan on the Users node
      objSearcher = New DirectorySearcher(objEntry, _
         "(&(objectClass=user)(objectCategory=person))")

      ' Find all objects of class user
      objSearchResults = objSearcher.FindAll()

      ' Check if any users were found
      If Not objSearchResults Is Nothing Then
         ' Loop through all users returned
         For Each objSearchResult In objSearchResults
            ' Display path for user
            MsgBox("Users Path: " & objSearchResult.Path)
         Next
      Else
         MsgBox("No users were found!")
      End If
   End Sub

   ' Listing 19-4
   Public Sub ReturnNonDefaultNodeProperties()
      Dim objEntry As DirectoryEntry
      Dim objSearcher As DirectorySearcher
      Dim objSearchResult As SearchResult
      Dim objValue As Object
      Dim strName As String

      ' Instantiate and bind to Users node in AD
      objEntry = New DirectoryEntry( _
         "LDAP://CN=Users,DC=userman,DC=dk", _
         "UserMan", "userman")

      ' Set up to search for UserMan on the Users node
      objSearcher = New DirectorySearcher(objEntry, _
         "(&(objectClass=user)(objectCategory=person)" & _
         "(userPrincipalName=userman@userman.dk))", _
         New String(2) {"sn", "telephoneNumber", "givenName"})

      Try
         ' Find the user
         objSearchResult = objSearcher.FindOne()
      Catch objE As Exception
         ' Catch any mistakes made when setting up
         ' the DirectoryEntry object, like wrong domain
         MsgBox(objE.Message)
      End Try

      ' Check if the user was found
      If Not objSearchResult Is Nothing Then
         ' Display all returned user properties
         ' Loop through all the properties returned
         For Each strName In objSearchResult.Properties.PropertyNames
            ' Loop through all the values for each property
            For Each objValue In objSearchResult.Properties(strName)
               ' Display the property and value
               MsgBox("Property Name: " & strName.ToString() & _
               " - Value: " + objValue.ToString())
            Next
         Next
      Else
         MsgBox("User not found!")
      End If
   End Sub

   ' Listing 19-5
   Public Sub EditUserProperty()
      Dim objEntry As DirectoryEntry

      ' Bind to UserMan user object
      objEntry = New DirectoryEntry( _
         "LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", _
         "Administrator", "AdminPwd")

      ' Check if the user already had an e-mail address
      If objEntry.Properties.Contains("mail") Then
         ' Change the e-mail address for the user
         objEntry.Properties("mail")(0) = "userman@userman.dk"
         ' Commit the changes to the AD database
         objEntry.CommitChanges()
      End If
   End Sub

   ' Listing 19-6
   Public Sub AddNewUserProperty()
      Dim objEntry As DirectoryEntry

      ' Bind to UserMan user object
      objEntry = New DirectoryEntry( _
         "LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", _
         "Administrator", "AdminPwd")

      ' Check if the user already had an e-mail address
      If Not objEntry.Properties.Contains("mail") Then
         ' Add new e-mail address
         objEntry.Properties("mail").Add("userman@userman.dk")
         ' Commit the changes to the AD database
         objEntry.CommitChanges()
      End If
   End Sub

   ' Listing 19-7
   Public Sub ManipulateUserProperty()
      Dim objEntry As DirectoryEntry

      ' Bind to UserMan user object
      objEntry = New DirectoryEntry( _
         "LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", _
         "Administrator", "AdminPwd")

      ' Check if the user already had an e-mail address
      If objEntry.Properties.Contains("mail") Then
         ' Add new e-mail address
         objEntry.Properties("mail")(0) = "userman@userman.dk"
      Else
         ' Add new e-mail address
         objEntry.Properties("mail").Add("userman@userman.dk")
      End If

      ' Commit the changes to the AD database
      objEntry.CommitChanges()
   End Sub

   ' Listing 19-8
   Public Sub AccessADWithOleDb()
      Dim cnnAD As OleDbConnection
      Dim cmmAD As OleDbCommand
      Dim drdAD As OleDbDataReader

      ' Instantiate and open connection
      cnnAD = New OleDbConnection( _
         "Provider=ADsDSOObject;User Id=UserMan;Password=userman")
      cnnAD.Open()
      ' Instantiate command
      cmmAD = New OleDbCommand("SELECT cn, AdsPath FROM " & _
         "'LDAP://userman.dk' WHERE objectCategory='person' " & _
         "AND objectClass='user' AND cn='UserMan'", cnnAD)

      ' Retrieve rows in data reader
      drdAD = cmmAD.ExecuteReader()
   End Sub

   ' Listing 19-9
   Public Sub GetSIDAndSAMAccountNameFromAD()
      Dim cnnAD As OleDbConnection
      Dim cmmAD As OleDbCommand
      Dim drdAD As OleDbDataReader
      Dim strSAMAccountName As String
      Dim strSID As String

      ' Instantiate and open connection
      cnnAD = New OleDbConnection( _
         "Provider=ADsDSOObject;User Id=UserMan;Password=userman")
      cnnAD.Open()
      ' Instantiate command
      cmmAD = New OleDbCommand("SELECT objectSid, samAccountName FROM " & _
       "'LDAP://userman.dk' WHERE objectCategory='person' " & _
       "AND objectClass='user' AND cn='UserMan'", cnnAD)

      ' Retrieve rows in data reader
      drdAD = cmmAD.ExecuteReader()
      ' Go to first row
      drdAD.Read()
      ' Get SAM Account name
      strSAMAccountName = drdAD("samAccountName").ToString
      ' Get SID
      strSID = drdAD("objectSid").ToString
   End Sub
End Module