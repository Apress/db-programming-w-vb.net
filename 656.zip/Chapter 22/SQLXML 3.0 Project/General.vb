Imports Microsoft.Data.SqlXml
Imports System.Xml
Imports System.IO

Module General
   ' Listing 22-8
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=SQLOLEDB;Data Source=10.8.1.11;User Id=UserMan;" & _
      "Password=userman;Initial Catalog=UserMan"

   Public Sub InstantiateSqlXmlAdapter()
      ' Declare and instantiate command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)

      ' Declare and instantiate adapters
      Dim dadUserMan1 As New SqlXmlAdapter(cmdUser)
      Dim dadUserMan2 As New SqlXmlAdapter( _
         "SELECT * FROM tblUser FOR XML AUTO", _
         SqlXmlCommandType.Sql, PR_STR_CONNECTION_STRING)
   End Sub

   ' Listing 22-9
   Public Sub PopulateDataSetUsingSql()
      ' Declare SELECT statement
      Dim strSQL As String = "SELECT * FROM tblUser FOR XML AUTO, ELEMENTS"
      ' Declare and instantiate DataSet
      Dim dstUserMan As New DataSet("UserMan")
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = strSQL

      ' Declare and instantiate adapters
      Dim dadUserMan1 As New SqlXmlAdapter(cmdUser)
      Dim dadUserMan2 As New SqlXmlAdapter(strSQL, _
         SqlXmlCommandType.Sql, PR_STR_CONNECTION_STRING)

      ' Fill DataSet. Uncomment one of the lines below 
      ' and comment out the other to test either
      dadUserMan1.Fill(dstUserMan)
      'dadUserMan2.Fill(dstUserMan)
   End Sub

   ' Listing 22-10
   Public Sub PopulateDataSetUsingSql2()
      ' Declare SELECT statement
      Dim strSQL As String = "SELECT * FROM tblUser FOR XML AUTO"
      ' Declare and instantiate DataSet
      Dim dstUserMan As New DataSet("UserMan")
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = strSQL
      ' You need to set the RootTag property, otherwise
      ' otherwise there is no root tag and an exception
      ' is thrown
      cmdUser.RootTag = "UserMan"

      ' Declare and instantiate adapter
      Dim dadUserMan1 As New SqlXmlAdapter(cmdUser)

      ' Fill DataSet
      dadUserMan1.Fill(dstUserMan)
   End Sub

   ' Listing 22-11
   Public Sub PopulateDataSetUsingStringTemplate()
      ' Declare template
      Dim strTemplate As String = _
         "<ROOT xmlns:sql='urn:schemas-microsoft-com:xml-sql'>" & _
         "<sql:query>" & "SELECT * FROM tblUser FOR XML AUTO" & _
         "</sql:query>" & "</ROOT>"
      ' Declare and instantiate DataSet
      Dim dstUserMan As New DataSet("UserMan")

      ' Declare and instantiate adapter
      Dim dadUserMan As New SqlXmlAdapter(strTemplate, _
         SqlXmlCommandType.Template, PR_STR_CONNECTION_STRING)

      ' Fill DataSet
      dadUserMan.Fill(dstUserMan)
      ' Write xml document to disk (Listing 22-12)
      'dstUserMan.WriteXml("C:\ReturnedDocument.xml")
      ' Check how many tables are in the DataSet
      MsgBox(dstUserMan.Tables.Count.ToString())
   End Sub

   ' Listing 22-13
   Public Sub PopulateDataSetUsingTemplateFile()
      ' Declare template file
      Dim strTemplateFile As String = "C:\DBPWVBNET\Chapter 22\" & _
         "InetPub\wwwroot\UserMan\Templates\AllUsers.xml"
      ' Declare output file
      Dim strOutputFile As String = "C:\ReturnedDocument.xml"
      ' Declare and instantiate DataSet
      Dim dstUserMan As New DataSet("UserMan")

      ' Declare and instantiate adapter
      Dim dadUserMan As New SqlXmlAdapter(strTemplateFile, _
         SqlXmlCommandType.TemplateFile, PR_STR_CONNECTION_STRING)

      ' Fill DataSet
      dadUserMan.Fill(dstUserMan)
      ' Write xml document to disk
      dstUserMan.WriteXml(strOutputFile)
   End Sub

   ' Listing 22-14
   Public Sub UpdateDataSourceFromDataSet()
      ' Declare template file
      Dim strTemplateFile As String = "C:\DBPWVBNET\Chapter 22\" & _
         "InetPub\wwwroot\UserMan\Templates\AllUsers.xml"
      ' Declare and instantiate DataSet
      Dim dstUserMan As New DataSet("UserMan")

      ' Declare and instantiate adapter
      Dim dadUserMan As New SqlXmlAdapter(strTemplateFile, _
         SqlXmlCommandType.TemplateFile, _
         PR_STR_CONNECTION_STRING)

      ' Fill DataSet
      dadUserMan.Fill(dstUserMan)
      ' Update DataSet
      dstUserMan.Tables("tblUser").Rows(0)("FirstName") = "Johnny"

      ' Check for chnages
      If dstUserMan.HasChanges() Then
         Try
            ' Update data source
            dadUserMan.Update(dstUserMan)
         Catch objException As SqlXmlException
            ' Start reading from beginning of stream
            objException.ErrorStream.Position = 0
            ' Read error message
            Dim strError As String = New StreamReader( _
               objException.ErrorStream).ReadToEnd()
            ' Display error message
            MsgBox(strError)
         End Try
      End If
   End Sub

   Public Sub InstantiateSqlXmlCommand()
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
   End Sub

   ' Listing 22-15
   Public Sub PopulateXmlReader()
      ' Declare XmlReader
      Dim xrdUser As XmlReader
      ' Declare SELECT statement
      Dim strSQL As String = "SELECT * FROM tblUser FOR XML AUTO"
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = strSQL
      ' Retrieve result set in Xml Reader
      xrdUser = cmdUser.ExecuteXmlReader()
   End Sub

   ' Listing 22-16
   Public Sub SaveCommandResultToStream()
      Dim stmUser As Stream
      Dim smwUser As StreamWriter
      ' Declare SELECT statement
      Dim strSQL As String = "SELECT * FROM tblUser FOR XML AUTO"
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = strSQL
      ' You need to set the RootTag property, 
      ' otherwise there is no root tag/element
      cmdUser.RootTag = "UserMan"

      ' Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream()
      ' Read content of stream into stream reader
      Dim smrUser As New StreamReader(stmUser)

      ' Create new file to hold the result stream
      smwUser = New StreamWriter("C:\Users.xml")
      ' Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd())
      ' Flush and close the stream writer
      smwUser.Flush()
      smwUser.Close()
   End Sub

   ' Listing 22-17
   Public Sub AppendCommandResultToStream()
      Dim stmUser As Stream
      Dim smwUser As StreamWriter
      ' Declare SELECT statement
      Dim strSQL As String = "SELECT * FROM tblUser FOR XML AUTO"
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = strSQL
      ' You need to set the RootTag property, otherwise
      ' there is no root element to form a valid XML
      ' document
      cmdUser.RootTag = "UserMan"

      ' Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream()
      ' Append new result set to existing stream
      cmdUser.ExecuteToStream(stmUser)
      ' Read content of stream into stream reader
      Dim smrUser As New StreamReader(stmUser)

      ' Create new file to hold the result stream
      smwUser = New StreamWriter("C:\Users.xml")
      ' Set the stream position to 0
      stmUser.Position = 0
      ' Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd())
      ' Flush and close the stream writer
      smwUser.Flush()
      smwUser.Close()
   End Sub

   ' Listing 22-18
   Public Sub ExecuteNamedParameterCommand()
      Dim stmUser As Stream
      Dim smwUser As StreamWriter
      Dim prmLastName As SqlXmlParameter
      ' Declare SELECT statement
      Dim strSQL As String = "SELECT * FROM tblUser " & _
         "WHERE LastName=LastName FOR XML AUTO"
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = strSQL
      ' You need to set the RootTag property, otherwise
      ' there is no root element to form a valid XML
      ' document
      cmdUser.RootTag = "UserMan"
      ' Add named parameter and set properties
      prmLastName = cmdUser.CreateParameter()
      prmLastName.Name = "LastName"
      prmLastName.Value = "Doe"
      ' Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream()
      ' Read content of stream into stream reader
      Dim smrUser As New StreamReader(stmUser)

      ' Create new file to hold the result stream
      smwUser = New StreamWriter("C:\Users.xml")
      ' Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd())
      ' Flush and close the stream writer
      smwUser.Flush()
      smwUser.Close()
   End Sub

   ' Listing 22-19
   Public Sub ExecutePositionalParameterCommand()
      Dim stmUser As Stream
      Dim smwUser As StreamWriter
      Dim prmLastName, prmFirstName As SqlXmlParameter
      ' Declare SELECT statement
      Dim strSQL As String = "SELECT * FROM tblUser WHERE LastName=? " & _
         "AND FirstName=? FOR XML AUTO"
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = strSQL
      ' You need to set the RootTag property, otherwise
      ' there is no root element to form a valid XML
      ' document
      cmdUser.RootTag = "UserMan"
      ' Add positional parameters and set value properties
      prmLastName = cmdUser.CreateParameter()
      prmLastName.Value = "Doe"
      prmFirstName = cmdUser.CreateParameter()
      prmFirstName.Value = "John"
      ' Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream()
      ' Read content of stream into stream reader
      Dim smrUser As New StreamReader(stmUser)

      ' Create new file to hold the result stream
      smwUser = New StreamWriter("C:\Users.xml")
      ' Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd())
      ' Flush and close the stream writer
      smwUser.Flush()
      smwUser.Close()
   End Sub

   ' Listing 22-20
   Public Sub ExecuteXPathQuery()
      Dim stmUser As Stream
      Dim smwUser As StreamWriter
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = "tblUser/@LoginName"
      cmdUser.CommandType = SqlXmlCommandType.XPath
      ' You need to set the RootTag property, otherwise
      ' there is no root element to form a valid XML
      ' document
      cmdUser.RootTag = "UserMan"
      ' Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream()
      ' Read content of stream into stream reader
      Dim smrUser As New StreamReader(stmUser)

      ' Create new file to hold the result stream
      smwUser = New StreamWriter("C:\Users.xml")
      ' Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd())
      ' Flush and close the stream writer
      smwUser.Flush()
      smwUser.Close()
   End Sub

   ' Listing 22-22
   Public Sub ExecuteXPathQueryUsingMappingSchema()
      Dim stmUser As Stream
      Dim smwUser As StreamWriter
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = "Users"
      cmdUser.CommandType = SqlXmlCommandType.XPath
      cmdUser.SchemaPath = "C:\Users.xsd"
      ' You need to set the RootTag property, otherwise
      ' there is no root element to form a valid XML
      ' document
      cmdUser.RootTag = "UserMan"

      ' Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream()

      ' Read content of stream into stream reader
      Dim smrUser As New StreamReader(stmUser)

      ' Create new file to hold the result stream
      smwUser = New StreamWriter("C:\Users.xml")
      ' Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd())
      ' Flush and close the stream writer
      smwUser.Flush()
      smwUser.Close()
   End Sub

   ' Listing 22-23
   Public Sub ExecuteNonQuery()
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = "UPDATE tblUser " & _
         "SET FirstName='FirstName' WHERE FirstName ='John'"

      Try
         ' Execute non query
         cmdUser.ExecuteNonQuery()
      Catch objException As SqlXmlException
         ' Start reading from beginning of stream
         objException.ErrorStream.Position = 0
         ' Read error message
         Dim strError As String = New StreamReader( _
            objException.ErrorStream).ReadToEnd()
         ' Display error message
         MsgBox(strError)
      End Try
   End Sub

   ' Listing 22-25
   Public Sub ExecuteNonQueryStringTemplate()
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = _
         "<ROOT xmlns:sql='urn:schemas-microsoft-com:xml-sql'>" & _
         "<sql:query>" & _
         "UPDATE tblUser " & _
         "SET FirstName='FirstName' WHERE FirstName = 'John'" & _
         "</sql:query>" & _
         "</ROOT>"
      cmdUser.CommandType = SqlXmlCommandType.Template

      Try
         ' Execute non query
         cmdUser.ExecuteNonQuery()
      Catch objException As SqlXmlException
         ' Start reading from beginning of stream
         objException.ErrorStream.Position = 0
         ' Read error message
         Dim strError As String = New StreamReader( _
            objException.ErrorStream).ReadToEnd()
         ' Display error message
         MsgBox(strError)
      End Try
   End Sub

   ' Listing 22-26
   Public Sub ExecuteNonQueryTemplate()
      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = "C:\UpdateUsers.xml"
      cmdUser.CommandType = SqlXmlCommandType.TemplateFile

      Try
         ' Execute non query
         cmdUser.ExecuteNonQuery()
      Catch objException As SqlXmlException
         ' Start reading from beginning of stream
         objException.ErrorStream.Position = 0
         ' Read error message
         Dim strError As String = New StreamReader( _
            objException.ErrorStream).ReadToEnd()
         ' Display error message
         MsgBox(strError)
      End Try
   End Sub

   ' Listing 22-27
   Public Sub ExecuteDiffGram()
      ' Declare template file
      Dim strTemplate As String = "C:\AllUsers.xml"
      ' Declare and instantiate DataSet
      Dim dstUserMan As New DataSet("UserMan")

      ' Declare and instantiate adapter
      Dim dadUserMan As New SqlXmlAdapter(strTemplate, _
         SqlXmlCommandType.TemplateFile, PR_STR_CONNECTION_STRING)

      ' Fill DataSet
      dadUserMan.Fill(dstUserMan)
      ' Update DataSet
      dstUserMan.Tables("tblUser").Rows(0)("FirstName") = "Johnny" ' Update
      dstUserMan.Tables("tblUser").Rows(3).Delete()                ' Delete
      dstUserMan.Tables("tblUser").Rows.Add(New Object(4) {Nothing, _
         Nothing, Nothing, "NewLogin", "password"})                ' Insert
      ' Save dataset as diffgram      
      dstUserMan.WriteXml("C:\Users-DiffGram.xml", XmlWriteMode.DiffGram)

      ' Declare, instantiate and initialize command
      Dim cmdUser As New SqlXmlCommand(PR_STR_CONNECTION_STRING)
      cmdUser.CommandText = "C:\Users-DiffGram.xml"
      cmdUser.CommandType = SqlXmlCommandType.TemplateFile
      cmdUser.SchemaPath = "C:\Users-DiffGram.xsd"

      Try
         ' Execute non query
         cmdUser.ExecuteNonQuery()
      Catch objException As SqlXmlException
         ' Start reading from beginning of stream
         objException.ErrorStream.Position = 0
         ' Read error message
         Dim strError As String = New StreamReader( _
            objException.ErrorStream).ReadToEnd()
         ' Display error message
         MsgBox(strError)
      End Try
   End Sub
End Module