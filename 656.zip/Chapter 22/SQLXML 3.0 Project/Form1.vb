Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnExecuteDiffGram As System.Windows.Forms.Button
   Friend WithEvents btnExecuteNonQuery As System.Windows.Forms.Button
   Friend WithEvents btnExecuteXPathQuery As System.Windows.Forms.Button
   Friend WithEvents btnExecutePositionalParameterCommand As System.Windows.Forms.Button
   Friend WithEvents btnExecuteNamedParameterCommand As System.Windows.Forms.Button
   Friend WithEvents btnAppendResultSetToStream As System.Windows.Forms.Button
   Friend WithEvents btnSaveCommandResultToStream As System.Windows.Forms.Button
   Friend WithEvents btnPopulateXmlReader As System.Windows.Forms.Button
   Friend WithEvents btnInstantiateCommand As System.Windows.Forms.Button
   Friend WithEvents btnUpdateDataSource As System.Windows.Forms.Button
   Friend WithEvents btnPopulateDataSet As System.Windows.Forms.Button
   Friend WithEvents btnInstantiateAdapter As System.Windows.Forms.Button
   Friend WithEvents btnExecuteWebServiceSP As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnExecuteDiffGram = New System.Windows.Forms.Button()
      Me.btnExecuteNonQuery = New System.Windows.Forms.Button()
      Me.btnExecuteXPathQuery = New System.Windows.Forms.Button()
      Me.btnExecutePositionalParameterCommand = New System.Windows.Forms.Button()
      Me.btnExecuteNamedParameterCommand = New System.Windows.Forms.Button()
      Me.btnAppendResultSetToStream = New System.Windows.Forms.Button()
      Me.btnSaveCommandResultToStream = New System.Windows.Forms.Button()
      Me.btnPopulateXmlReader = New System.Windows.Forms.Button()
      Me.btnInstantiateCommand = New System.Windows.Forms.Button()
      Me.btnUpdateDataSource = New System.Windows.Forms.Button()
      Me.btnPopulateDataSet = New System.Windows.Forms.Button()
      Me.btnInstantiateAdapter = New System.Windows.Forms.Button()
      Me.btnExecuteWebServiceSP = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnExecuteDiffGram
      '
      Me.btnExecuteDiffGram.Location = New System.Drawing.Point(186, 287)
      Me.btnExecuteDiffGram.Name = "btnExecuteDiffGram"
      Me.btnExecuteDiffGram.Size = New System.Drawing.Size(279, 28)
      Me.btnExecuteDiffGram.TabIndex = 9
      Me.btnExecuteDiffGram.Text = "Execute DiffGram"
      '
      'btnExecuteNonQuery
      '
      Me.btnExecuteNonQuery.Location = New System.Drawing.Point(186, 252)
      Me.btnExecuteNonQuery.Name = "btnExecuteNonQuery"
      Me.btnExecuteNonQuery.Size = New System.Drawing.Size(279, 29)
      Me.btnExecuteNonQuery.TabIndex = 8
      Me.btnExecuteNonQuery.Text = "Execute Non-Query"
      '
      'btnExecuteXPathQuery
      '
      Me.btnExecuteXPathQuery.Location = New System.Drawing.Point(186, 218)
      Me.btnExecuteXPathQuery.Name = "btnExecuteXPathQuery"
      Me.btnExecuteXPathQuery.Size = New System.Drawing.Size(279, 28)
      Me.btnExecuteXPathQuery.TabIndex = 13
      Me.btnExecuteXPathQuery.Text = "Execute XPath Query"
      '
      'btnExecutePositionalParameterCommand
      '
      Me.btnExecutePositionalParameterCommand.Location = New System.Drawing.Point(186, 183)
      Me.btnExecutePositionalParameterCommand.Name = "btnExecutePositionalParameterCommand"
      Me.btnExecutePositionalParameterCommand.Size = New System.Drawing.Size(279, 29)
      Me.btnExecutePositionalParameterCommand.TabIndex = 12
      Me.btnExecutePositionalParameterCommand.Text = "Execute Positional Parameter Command"
      '
      'btnExecuteNamedParameterCommand
      '
      Me.btnExecuteNamedParameterCommand.Location = New System.Drawing.Point(186, 149)
      Me.btnExecuteNamedParameterCommand.Name = "btnExecuteNamedParameterCommand"
      Me.btnExecuteNamedParameterCommand.Size = New System.Drawing.Size(279, 28)
      Me.btnExecuteNamedParameterCommand.TabIndex = 11
      Me.btnExecuteNamedParameterCommand.Text = "Execute Named Parameter Command"
      '
      'btnAppendResultSetToStream
      '
      Me.btnAppendResultSetToStream.Location = New System.Drawing.Point(186, 114)
      Me.btnAppendResultSetToStream.Name = "btnAppendResultSetToStream"
      Me.btnAppendResultSetToStream.Size = New System.Drawing.Size(279, 28)
      Me.btnAppendResultSetToStream.TabIndex = 7
      Me.btnAppendResultSetToStream.Text = "Append Result Set to Stream"
      '
      'btnSaveCommandResultToStream
      '
      Me.btnSaveCommandResultToStream.Location = New System.Drawing.Point(186, 79)
      Me.btnSaveCommandResultToStream.Name = "btnSaveCommandResultToStream"
      Me.btnSaveCommandResultToStream.Size = New System.Drawing.Size(279, 29)
      Me.btnSaveCommandResultToStream.TabIndex = 3
      Me.btnSaveCommandResultToStream.Text = "Save Result Set to Stream"
      '
      'btnPopulateXmlReader
      '
      Me.btnPopulateXmlReader.Location = New System.Drawing.Point(186, 45)
      Me.btnPopulateXmlReader.Name = "btnPopulateXmlReader"
      Me.btnPopulateXmlReader.Size = New System.Drawing.Size(279, 28)
      Me.btnPopulateXmlReader.TabIndex = 2
      Me.btnPopulateXmlReader.Text = "Populate XmlReader"
      '
      'btnInstantiateCommand
      '
      Me.btnInstantiateCommand.Location = New System.Drawing.Point(186, 10)
      Me.btnInstantiateCommand.Name = "btnInstantiateCommand"
      Me.btnInstantiateCommand.Size = New System.Drawing.Size(279, 29)
      Me.btnInstantiateCommand.TabIndex = 1
      Me.btnInstantiateCommand.Text = "Instantiate Command"
      '
      'btnUpdateDataSource
      '
      Me.btnUpdateDataSource.Location = New System.Drawing.Point(10, 79)
      Me.btnUpdateDataSource.Name = "btnUpdateDataSource"
      Me.btnUpdateDataSource.Size = New System.Drawing.Size(164, 29)
      Me.btnUpdateDataSource.TabIndex = 6
      Me.btnUpdateDataSource.Text = "Update Data Source"
      '
      'btnPopulateDataSet
      '
      Me.btnPopulateDataSet.Location = New System.Drawing.Point(10, 45)
      Me.btnPopulateDataSet.Name = "btnPopulateDataSet"
      Me.btnPopulateDataSet.Size = New System.Drawing.Size(164, 28)
      Me.btnPopulateDataSet.TabIndex = 5
      Me.btnPopulateDataSet.Text = "Populate DataSet"
      '
      'btnInstantiateAdapter
      '
      Me.btnInstantiateAdapter.Location = New System.Drawing.Point(10, 10)
      Me.btnInstantiateAdapter.Name = "btnInstantiateAdapter"
      Me.btnInstantiateAdapter.Size = New System.Drawing.Size(164, 29)
      Me.btnInstantiateAdapter.TabIndex = 4
      Me.btnInstantiateAdapter.Text = "Instantiate Adapter"
      '
      'btnExecuteWebServiceSP
      '
      Me.btnExecuteWebServiceSP.Location = New System.Drawing.Point(10, 150)
      Me.btnExecuteWebServiceSP.Name = "btnExecuteWebServiceSP"
      Me.btnExecuteWebServiceSP.Size = New System.Drawing.Size(164, 29)
      Me.btnExecuteWebServiceSP.TabIndex = 14
      Me.btnExecuteWebServiceSP.Text = "Execute WebService SP"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(474, 326)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnExecuteWebServiceSP, Me.btnExecuteDiffGram, Me.btnExecuteNonQuery, Me.btnExecuteXPathQuery, Me.btnExecutePositionalParameterCommand, Me.btnExecuteNamedParameterCommand, Me.btnAppendResultSetToStream, Me.btnSaveCommandResultToStream, Me.btnPopulateXmlReader, Me.btnInstantiateCommand, Me.btnUpdateDataSource, Me.btnPopulateDataSet, Me.btnInstantiateAdapter})
      Me.Name = "Form1"
      Me.Text = "SQLXML 3.0 Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnInstantiateAdapter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateAdapter.Click
      InstantiateSqlXmlAdapter()
   End Sub

   Private Sub btnPopulateDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateDataSet.Click
      'PopulateDataSetUsingSql()
      'PopulateDataSetUsingSql2()
      'PopulateDataSetUsingStringTemplate()
      PopulateDataSetUsingTemplateFile()
   End Sub

   Private Sub btnUpdateDataSource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateDataSource.Click
      UpdateDataSourceFromDataSet()
   End Sub

   Private Sub btnInstantiateCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateCommand.Click
      InstantiateSqlXmlCommand()
   End Sub

   Private Sub btnPopulateXmlReader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateXmlReader.Click
      PopulateXmlReader()
   End Sub

   Private Sub btnSaveCommandResultToStream_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveCommandResultToStream.Click
      SaveCommandResultToStream()
   End Sub

   Private Sub btnAppendResultSetToStream_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAppendResultSetToStream.Click
      AppendCommandResultToStream()
   End Sub

   Private Sub btnExecuteNamedParameterCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteNamedParameterCommand.Click
      ExecuteNamedParameterCommand()
   End Sub

   Private Sub btnExecutePositionalParameterCommand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecutePositionalParameterCommand.Click
      ExecutePositionalParameterCommand()
   End Sub

   Private Sub btnExecuteXPathQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteXPathQuery.Click
      'ExecuteXPathQuery()
      ExecuteXPathQueryUsingMappingSchema()
   End Sub

   Private Sub btnExecuteNonQuery_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteNonQuery.Click
      'ExecuteNonQuery()
      'ExecuteNonQueryStringTemplate()
      ExecuteNonQueryTemplate()
   End Sub

   Private Sub btnExecuteDiffGram_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteDiffGram.Click
      ExecuteDiffGram()
   End Sub

   ' Listing 22-29
   Private Sub btnExecuteWebServiceSP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecuteWebServiceSP.Click
      Dim dstUsers As DataSet
      Dim intReturn As Integer

      ' Declare object as new SP Web Service
      Dim objWS As New SPWS.WebService()

      ' Retrieve users from SP via Web Service
      dstUsers = objWS.uspGetUsers(intReturn)
   End Sub
End Class
