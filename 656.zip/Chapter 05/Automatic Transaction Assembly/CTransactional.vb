Imports System.EnterpriseServices
Imports System.Reflection

<Assembly: AssemblyKeyFileAttribute("Automatic Transaction Assembly.snk")> 

<Transaction(TransactionOption.Supported)> _
Public Class CTransactional
   Inherits ServicedComponent

End Class