Option Strict Off

Imports eInfoDesigns.dbProvider.MySqlClient
Imports System.Xml

Module General
   ' Listing 5-1
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.30;" & _
      "User ID=UserMan;Password=userman;Database=UserMan"

   ' Listing 5-2
   Public Sub OpenConnection()
      ' Declare connection object
      Dim cnnUserMan As MySqlConnection

      ' Instantiate the connection object
      cnnUserMan = New MySqlConnection()

      Try
         ' Set up connection string
         cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
         ' Open the connection
         cnnUserMan.Open()
      Catch objE As Exception
         ' Deal with exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 5-14
   Public Sub BeginNonDefaultIsolationLevelTransaction()
      Dim cnnUserMan As MySqlConnection
      Dim traUserMan As MySqlTransaction

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)
   End Sub

   ' Listing 5-17
   Public Sub DetermineTransactionIsolationLevel()
      Dim cnnUserMan As MySqlConnection
      Dim traUserMan As MySqlTransaction
      Dim intIsolationLevel As Integer

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      ' Start transaction with non-default isolation level
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)

      ' Return the isolation level as text
      MsgBox(traUserMan.IsolationLevel.ToString)
      ' Return the isolation level as an integer value
      intIsolationLevel = traUserMan.IsolationLevel
   End Sub

   ' Listing 5-20
   Public Sub TraverseAllSqlErrors()
      Dim cnnUserMan As MySqlConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Do your stuff...
         ' ...
      Catch objException As MySqlException
         ' This Catch block will handle all exceptions that 
         ' the MySqlDataAdapter cannot handle
         Dim objError As MySqlError

         For Each objError In objException.Errors
            MsgBox(objException.Message)
         Next
      Catch objException As Exception
         ' This Catch block will catch all exceptions that
         ' the MySqlDataAdapter can handle
         MsgBox(objException.Message)
      End Try
   End Sub
End Module