Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnOpenConnection As System.Windows.Forms.Button
   Friend WithEvents btnBeginNonDefaultIsolationLevelTransaction As System.Windows.Forms.Button
   Friend WithEvents btnBeginNamedTransaction As System.Windows.Forms.Button
   Friend WithEvents btnBeginNamedNonDefaultIsolationLevelTransaction As System.Windows.Forms.Button
   Friend WithEvents btnDetermineTransactionLevel As System.Windows.Forms.Button
   Friend WithEvents btnTraverseAllOLEDBErrors As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnOpenConnection = New System.Windows.Forms.Button()
      Me.btnBeginNonDefaultIsolationLevelTransaction = New System.Windows.Forms.Button()
      Me.btnBeginNamedTransaction = New System.Windows.Forms.Button()
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction = New System.Windows.Forms.Button()
      Me.btnDetermineTransactionLevel = New System.Windows.Forms.Button()
      Me.btnTraverseAllOLEDBErrors = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnOpenConnection
      '
      Me.btnOpenConnection.Location = New System.Drawing.Point(15, 42)
      Me.btnOpenConnection.Name = "btnOpenConnection"
      Me.btnOpenConnection.Size = New System.Drawing.Size(259, 28)
      Me.btnOpenConnection.TabIndex = 0
      Me.btnOpenConnection.Text = "Open Connection"
      '
      'btnBeginNonDefaultIsolationLevelTransaction
      '
      Me.btnBeginNonDefaultIsolationLevelTransaction.Location = New System.Drawing.Point(301, 42)
      Me.btnBeginNonDefaultIsolationLevelTransaction.Name = "btnBeginNonDefaultIsolationLevelTransaction"
      Me.btnBeginNonDefaultIsolationLevelTransaction.Size = New System.Drawing.Size(361, 28)
      Me.btnBeginNonDefaultIsolationLevelTransaction.TabIndex = 5
      Me.btnBeginNonDefaultIsolationLevelTransaction.Text = "Begin NonDefault Isolation Level Transaction"
      '
      'btnBeginNamedTransaction
      '
      Me.btnBeginNamedTransaction.Location = New System.Drawing.Point(301, 76)
      Me.btnBeginNamedTransaction.Name = "btnBeginNamedTransaction"
      Me.btnBeginNamedTransaction.Size = New System.Drawing.Size(361, 29)
      Me.btnBeginNamedTransaction.TabIndex = 6
      Me.btnBeginNamedTransaction.Text = "Begin Named Transaction"
      '
      'btnBeginNamedNonDefaultIsolationLevelTransaction
      '
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Location = New System.Drawing.Point(301, 111)
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Name = "btnBeginNamedNonDefaultIsolationLevelTransaction"
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Size = New System.Drawing.Size(361, 28)
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.TabIndex = 7
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Text = "Begin Named NonDefault Isolation Level Transaction"
      '
      'btnDetermineTransactionLevel
      '
      Me.btnDetermineTransactionLevel.Location = New System.Drawing.Point(301, 146)
      Me.btnDetermineTransactionLevel.Name = "btnDetermineTransactionLevel"
      Me.btnDetermineTransactionLevel.Size = New System.Drawing.Size(361, 28)
      Me.btnDetermineTransactionLevel.TabIndex = 8
      Me.btnDetermineTransactionLevel.Text = "Determine Transaction Level"
      '
      'btnTraverseAllOLEDBErrors
      '
      Me.btnTraverseAllOLEDBErrors.Location = New System.Drawing.Point(302, 232)
      Me.btnTraverseAllOLEDBErrors.Name = "btnTraverseAllOLEDBErrors"
      Me.btnTraverseAllOLEDBErrors.Size = New System.Drawing.Size(360, 28)
      Me.btnTraverseAllOLEDBErrors.TabIndex = 10
      Me.btnTraverseAllOLEDBErrors.Text = "Traverse All SQL Errors"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(675, 275)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnTraverseAllOLEDBErrors, Me.btnDetermineTransactionLevel, Me.btnBeginNamedNonDefaultIsolationLevelTransaction, Me.btnBeginNamedTransaction, Me.btnBeginNonDefaultIsolationLevelTransaction, Me.btnOpenConnection})
      Me.Name = "Form1"
      Me.Text = "MySqlConnection_MySqlTransaction Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnOpenConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenConnection.Click
      OpenConnection()
   End Sub

   Private Sub btnDetermineTransactionLevel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetermineTransactionLevel.Click
      DetermineTransactionIsolationLevel()
   End Sub

   Private Sub btnTraverseAllOLEDBErrors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTraverseAllOLEDBErrors.Click
      TraverseAllSqlErrors()
   End Sub
End Class
