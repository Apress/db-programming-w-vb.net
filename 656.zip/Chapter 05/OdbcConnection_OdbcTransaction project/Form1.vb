Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnOpenConnection As System.Windows.Forms.Button
   Friend WithEvents btnClearConnectionPool As System.Windows.Forms.Button
   Friend WithEvents btnTriggerInfoMessage As System.Windows.Forms.Button
   Friend WithEvents btnTriggerStateChange As System.Windows.Forms.Button
   Friend WithEvents btnDetermineTransactionLevel As System.Windows.Forms.Button
   Friend WithEvents btnBeginNonDefaultIsolationLevelTransaction As System.Windows.Forms.Button
   Friend WithEvents btnTraverseAllODBCErrors As System.Windows.Forms.Button
   Friend WithEvents btnCheckBeginTransactionMethodException As System.Windows.Forms.Button
   Friend WithEvents btnCheckConnectionStringPropertyException As System.Windows.Forms.Button
   Friend WithEvents btnCheckChangeDatabaseMethodException As System.Windows.Forms.Button
   Friend WithEvents btnCheckOpenMethodException As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnOpenConnection = New System.Windows.Forms.Button()
      Me.btnClearConnectionPool = New System.Windows.Forms.Button()
      Me.btnTriggerInfoMessage = New System.Windows.Forms.Button()
      Me.btnTriggerStateChange = New System.Windows.Forms.Button()
      Me.btnDetermineTransactionLevel = New System.Windows.Forms.Button()
      Me.btnBeginNonDefaultIsolationLevelTransaction = New System.Windows.Forms.Button()
      Me.btnTraverseAllODBCErrors = New System.Windows.Forms.Button()
      Me.btnCheckBeginTransactionMethodException = New System.Windows.Forms.Button()
      Me.btnCheckConnectionStringPropertyException = New System.Windows.Forms.Button()
      Me.btnCheckChangeDatabaseMethodException = New System.Windows.Forms.Button()
      Me.btnCheckOpenMethodException = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnOpenConnection
      '
      Me.btnOpenConnection.Location = New System.Drawing.Point(24, 26)
      Me.btnOpenConnection.Name = "btnOpenConnection"
      Me.btnOpenConnection.Size = New System.Drawing.Size(130, 23)
      Me.btnOpenConnection.TabIndex = 1
      Me.btnOpenConnection.Text = "Open Connection"
      '
      'btnClearConnectionPool
      '
      Me.btnClearConnectionPool.Location = New System.Drawing.Point(24, 82)
      Me.btnClearConnectionPool.Name = "btnClearConnectionPool"
      Me.btnClearConnectionPool.Size = New System.Drawing.Size(130, 23)
      Me.btnClearConnectionPool.TabIndex = 3
      Me.btnClearConnectionPool.Text = "Clear Connection Pool"
      '
      'btnTriggerInfoMessage
      '
      Me.btnTriggerInfoMessage.Location = New System.Drawing.Point(24, 110)
      Me.btnTriggerInfoMessage.Name = "btnTriggerInfoMessage"
      Me.btnTriggerInfoMessage.Size = New System.Drawing.Size(130, 23)
      Me.btnTriggerInfoMessage.TabIndex = 4
      Me.btnTriggerInfoMessage.Text = "Trigger Info Message"
      '
      'btnTriggerStateChange
      '
      Me.btnTriggerStateChange.Location = New System.Drawing.Point(24, 54)
      Me.btnTriggerStateChange.Name = "btnTriggerStateChange"
      Me.btnTriggerStateChange.Size = New System.Drawing.Size(130, 23)
      Me.btnTriggerStateChange.TabIndex = 2
      Me.btnTriggerStateChange.Text = "Trigger State Change"
      '
      'btnDetermineTransactionLevel
      '
      Me.btnDetermineTransactionLevel.Location = New System.Drawing.Point(206, 56)
      Me.btnDetermineTransactionLevel.Name = "btnDetermineTransactionLevel"
      Me.btnDetermineTransactionLevel.Size = New System.Drawing.Size(239, 23)
      Me.btnDetermineTransactionLevel.TabIndex = 6
      Me.btnDetermineTransactionLevel.Text = "Determine Transaction Level"
      '
      'btnBeginNonDefaultIsolationLevelTransaction
      '
      Me.btnBeginNonDefaultIsolationLevelTransaction.Location = New System.Drawing.Point(206, 28)
      Me.btnBeginNonDefaultIsolationLevelTransaction.Name = "btnBeginNonDefaultIsolationLevelTransaction"
      Me.btnBeginNonDefaultIsolationLevelTransaction.Size = New System.Drawing.Size(239, 23)
      Me.btnBeginNonDefaultIsolationLevelTransaction.TabIndex = 5
      Me.btnBeginNonDefaultIsolationLevelTransaction.Text = "Begin NonDefault Isolation Level Transaction"
      '
      'btnTraverseAllODBCErrors
      '
      Me.btnTraverseAllODBCErrors.Location = New System.Drawing.Point(206, 138)
      Me.btnTraverseAllODBCErrors.Name = "btnTraverseAllODBCErrors"
      Me.btnTraverseAllODBCErrors.Size = New System.Drawing.Size(239, 23)
      Me.btnTraverseAllODBCErrors.TabIndex = 7
      Me.btnTraverseAllODBCErrors.Text = "Traverse All ODBC Errors"
      '
      'btnCheckBeginTransactionMethodException
      '
      Me.btnCheckBeginTransactionMethodException.Location = New System.Drawing.Point(206, 166)
      Me.btnCheckBeginTransactionMethodException.Name = "btnCheckBeginTransactionMethodException"
      Me.btnCheckBeginTransactionMethodException.Size = New System.Drawing.Size(239, 23)
      Me.btnCheckBeginTransactionMethodException.TabIndex = 8
      Me.btnCheckBeginTransactionMethodException.Text = "Check BeginTransaction Method Exception"
      '
      'btnCheckConnectionStringPropertyException
      '
      Me.btnCheckConnectionStringPropertyException.Location = New System.Drawing.Point(206, 194)
      Me.btnCheckConnectionStringPropertyException.Name = "btnCheckConnectionStringPropertyException"
      Me.btnCheckConnectionStringPropertyException.Size = New System.Drawing.Size(239, 23)
      Me.btnCheckConnectionStringPropertyException.TabIndex = 9
      Me.btnCheckConnectionStringPropertyException.Text = "Check ConnectionString Property Exception"
      '
      'btnCheckChangeDatabaseMethodException
      '
      Me.btnCheckChangeDatabaseMethodException.Location = New System.Drawing.Point(206, 222)
      Me.btnCheckChangeDatabaseMethodException.Name = "btnCheckChangeDatabaseMethodException"
      Me.btnCheckChangeDatabaseMethodException.Size = New System.Drawing.Size(239, 23)
      Me.btnCheckChangeDatabaseMethodException.TabIndex = 10
      Me.btnCheckChangeDatabaseMethodException.Text = "Check ChangeDatabase Method Exception"
      '
      'btnCheckOpenMethodException
      '
      Me.btnCheckOpenMethodException.Location = New System.Drawing.Point(206, 250)
      Me.btnCheckOpenMethodException.Name = "btnCheckOpenMethodException"
      Me.btnCheckOpenMethodException.Size = New System.Drawing.Size(239, 23)
      Me.btnCheckOpenMethodException.TabIndex = 11
      Me.btnCheckOpenMethodException.Text = "Check Open Method Exception"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(466, 287)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCheckOpenMethodException, Me.btnCheckChangeDatabaseMethodException, Me.btnCheckConnectionStringPropertyException, Me.btnCheckBeginTransactionMethodException, Me.btnTraverseAllODBCErrors, Me.btnBeginNonDefaultIsolationLevelTransaction, Me.btnDetermineTransactionLevel, Me.btnTriggerInfoMessage, Me.btnTriggerStateChange, Me.btnClearConnectionPool, Me.btnOpenConnection})
      Me.Name = "Form1"
      Me.Text = "OdbcConnection_OdbcTransaction Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnOpenConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenConnection.Click
      OpenConnection()
   End Sub

   Private Sub btnClearConnectionPool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearConnectionPool.Click
      ClearConnectionPool()
   End Sub

   Private Sub btnTriggerStateChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerStateChange.Click
      Dim objGeneral As New CGeneral()

      objGeneral.TriggerStateChangeEvent()
   End Sub

   Private Sub btnTriggerInfoMessage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerInfoMessage.Click
      Dim objGeneral As New CGeneral()

      objGeneral.TriggerInfoMessageEvent()
   End Sub

   Private Sub btnDetermineTransactionLevel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetermineTransactionLevel.Click
      DetermineTransactionIsolationLevel()
   End Sub

   Private Sub btnBeginNonDefaultIsolationLevelTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginNonDefaultIsolationLevelTransaction.Click
      BeginNonDefaultIsolationLevelTransaction()
   End Sub

   Private Sub btnTraverseAllODBCErrors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTraverseAllODBCErrors.Click
      TraverseAllOdbcErrors()
   End Sub

   Private Sub btnCheckBeginTransactionMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckBeginTransactionMethodException.Click
      CheckBeginTransactionMethodException()
   End Sub

   Private Sub btnCheckConnectionStringPropertyException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckConnectionStringPropertyException.Click
      CheckConnectionStringPropertyException()
   End Sub

   Private Sub btnCheckChangeDatabaseMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckChangeDatabaseMethodException.Click
      CheckChangeDatabaseMethodException()
   End Sub

   Private Sub btnCheckOpenMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckOpenMethodException.Click
      CheckOpenMethodException()
   End Sub
End Class
