Option Strict On

Imports Microsoft.Data.Odbc

#Const MySQL = 1
'#Const Oracle = 1
'#Const MSAccess = 1
'#Const SQLSERVER = 1
'#Const DB2 = 1
' You simply uncomment the line above for the DBMS you want to use

Module General
   ' Listing 5-1
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = "DRIVER={SQL Server};SERVER=USERMANPC;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "DRIVER={SQL Server};SERVER=USERMANPC;" & _
   '   "UID=UserMan;PWD=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "DRIVER={SQL Server};SERVER=USERMANPC;" & _
   '   "UID=UserMan;PWD=userman;DATABASE=UserMan"
#ElseIf MSAccess Then
	' This connection string os for connecting to an Access mdb
   ' I'm not using any security, hence no specification of User Id and password. 
   ' You must edit the path to your database file
   'Private Const PR_STR_CONNECTION_STRING As String = _
   '   "DRIVER={Microsoft Access Driver (*.mdb)};DBQ=C:\DBPWVBNET\UserMan.mdb;"
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={Microsoft Access Driver (*.mdb)};DBQ=C:\DBPWVBNET\UserMan.mdb;" & _
      "FIL=MS Access;"
   'Private Const PR_STR_CONNECTION_STRING As String = "DSN=UserMan;"
#ElseIf MySQL Then
   ' This connection string os for connecting to MySQL 3.23.51 or later
   ' You must change the SERVER value
   'Private Const PR_STR_CONNECTION_STRING As String = _
   '   "DRIVER={MySQL};SERVER=10.8.1.30;UID=UserMan;PWD=userman;DATABASE=UserMan"
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={MySQL};SERVER=10.8.1.30;UID=UserMan;PWD=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = _
   '   "DRIVER={MySQL};SERVER=USERMANPC;UID=UserMan;PWD=userman;DATABASE=UserMan"
#ElseIf Oracle Then
	' This connection string os for connecting to Oracle
    ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={Microsoft ODBC for Oracle};PWD=userman;UID=USERMAN;SERVER=USERMAN"
#ElseIf DB2 Then
	' This connection string os for connecting to IBM DB2 Universal Database 7.2 EE
   ' You must change the SERVER value
   'Private Const PR_STR_CONNECTION_STRING As String = _
   '   "DRIVER={IBM DB2 ODBC DRIVER};PWD=userman;UID=USERMAN;DBALIAS=USERMAN;"
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={IBM DB2 ODBC DRIVER};PWD=userman;UID=USERMAN;DBALIAS=USERMAN;"
#End If

   ' Listing 5-2
   Public Sub OpenConnection()
      ' Declare connection object
      Dim cnnUserMan As OdbcConnection

      ' Instantiate the connection object
      cnnUserMan = New OdbcConnection()

      Try
         ' Set up connection string
         cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
         ' Open the connection
         cnnUserMan.Open()
      Catch objE As Exception
         ' Deal with exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 5-6
   Public Sub ClearConnectionPool()
      ' Declare connection object
      Dim cnnUserMan As OdbcConnection

      ' Instantiate the connection object
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      ' Do your stuff
      ' ...

      ' Close connection and release pool
      cnnUserMan.Close()
      cnnUserMan.ReleaseObjectPool()
   End Sub

   ' Listing 5-14
   Public Sub BeginNonDefaultIsolationLevelTransaction()
      Dim cnnUserMan As OdbcConnection
      Dim traUserMan As OdbcTransaction

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)
   End Sub

   ' Listing 5-17
   Public Sub DetermineTransactionIsolationLevel()
      Dim cnnUserMan As OdbcConnection
      Dim traUserMan As OdbcTransaction
      Dim intIsolationLevel As Integer

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      ' Start transaction with non-default isolation level
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)

      ' Return the isolation level as text
      MsgBox(traUserMan.IsolationLevel.ToString)
      ' Return the isolation level as an integer value
      intIsolationLevel = traUserMan.IsolationLevel
   End Sub

   ' Listing 5-20
   Public Sub TraverseAllOdbcErrors()
      Dim cnnUserMan As OdbcConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Do your stuff...
         ' ...
      Catch objException As OdbcException
         ' This Catch block will handle all exceptions that 
         ' the OdbcAdapter cannot handle
         Dim objError As OdbcError

         For Each objError In objException.Errors
            MsgBox(objException.Message)
         Next
      Catch objException As Exception
         ' This Catch block will catch all exceptions that
         ' the OdbcAdapter can handle
         MsgBox(objException.Message)
      End Try
   End Sub

   ' Listing 5-21
   Public Sub CheckBeginTransactionMethodException()
      Dim cnnUserMan As OdbcConnection
      Dim traUserMan1, traUserMan2 As OdbcTransaction

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      Try
         ' Start parallel transactions
         traUserMan1 = cnnUserMan.BeginTransaction
         traUserMan2 = cnnUserMan.BeginTransaction
      Catch objException As InvalidOperationException
         ' Check if a BeginTransaction method threw the exception
         If objException.TargetSite.Name = "BeginTransactionObject" Then
            MsgBox("The BeginTransaction method threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-22
   Public Sub CheckConnectionStringPropertyException()
      Dim cnnUserMan As OdbcConnection

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      Try
         ' Set the connection string
         cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
      Catch objException As InvalidOperationException
         ' Check if setting the ConnectionString threw the exception
         If objException.TargetSite.Name = "set_ConnectionString" Then
            MsgBox("The ConnectionString property threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-24
   Public Sub CheckChangeDatabaseMethodException()
      Dim cnnUserMan As OdbcConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         ' If the following line is commented out, the ChangeDatabase exception will be thrown
         'cnnUserMan.Open()
         ' Change database
         cnnUserMan.ChangeDatabase("master")
      Catch objException As InvalidOperationException
         ' Check if we tried to change database on an invalid connection
         If objException.TargetSite.Name = "CheckState" Then
            MsgBox("The ChangeDatabase method threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-25
   Public Sub CheckOpenMethodException()
      Dim cnnUserMan As OdbcConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Open the connection
         cnnUserMan.Open()
      Catch objException As InvalidOperationException
         ' Check if we tried to open an already open connection
         If objException.TargetSite.Name = "Open" Then
            MsgBox("The Open method threw the exception!")
         End If
      End Try
   End Sub
End Module