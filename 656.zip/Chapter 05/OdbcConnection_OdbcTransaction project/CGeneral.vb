Option Strict On

Imports Microsoft.Data.Odbc

'#Const DB2 = 1
#Const SQLSERVER = 1
' You simply uncomment the line above for the DBMS you want to use

' Listing 5-4-1 & 5-10-1
Public Class CGeneral

#If SQLServer Then
   Private Const PR_STR_CONNECTION_STRING As String = "DRIVER={SQL Server};" & _
      "SERVER=10.8.1.11;UID=UserMan;PWD=userman;DATABASE=UserMan"
#ElseIf DB2 Then
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={IBM DB2 ODBC DRIVER};PWD=userman;UID=USERMAN;DBALIAS=USERMAN;"
#End If

   ' Declare and instantiate connection
   Private prcnnUserMan As OdbcConnection = _
      New OdbcConnection(PR_STR_CONNECTION_STRING)

   Public Sub New()
      MyBase.New()
      ' Listing 5-4-2
      ' Set up StateChange event handler
      AddHandler prcnnUserMan.StateChange, New _
         StateChangeEventHandler(AddressOf OnStateChange)
      ' Listing 5-10-2
      ' Set up InfoMessage event handler
      AddHandler prcnnUserMan.InfoMessage, New _
         OdbcInfoMessageEventHandler(AddressOf OnInfoMessage)
   End Sub

   ' Listing 5-4-3
   Private Shared Sub OnStateChange(ByVal sender As Object, _
      ByVal args As StateChangeEventArgs)
      ' Display the original and the current state
      MessageBox.Show("The original connection state was: " & _
         args.OriginalState.ToString() & vbCrLf & _
         "The current connection state is: " & _
         args.CurrentState.ToString())
   End Sub

   ' Listing 5-10-3
   Private Shared Sub OnInfoMessage(ByVal sender As Object, _
      ByVal args As OdbcInfoMessageEventArgs)
      Dim objError As OdbcError

      ' Loop through all the error messages 
      For Each objError In args.Errors
         ' Display the error properties
         MessageBox.Show("The " & objError.Source & _
            " has raised a warning. These are the properties :" & _
            vbCrLf & vbCrLf & "Native Error: " & objError.NativeError & vbCrLf & _
            "SQL State: " & objError.SQLState & vbCrLf & "Message: " & _
            objError.Message)
      Next
   End Sub

   ' Listing 5-4-4
   Public Sub TriggerStateChangeEvent()
      ' Open the connection
      prcnnUserMan.Open()
      ' Close the connection
      prcnnUserMan.Close()
   End Sub

   ' Listing 5-10-4
   Public Sub TriggerInfoMessageEvent()
#If SQLServer Then
      ' The RAISERROR T-SQL function will raise the InfoMessage
      ' event
      Dim cmmUserMan As OdbcCommand = _
         New OdbcCommand("RAISERROR('This is an info message event.', 10, 1)", _
         prcnnUserMan)
#ElseIf DB2 Then
      ' By adding the SERVER value name to the connection string, the InfoMessage
      ' event is triggered, because this is an invalid value name for the DB2 ODBC
      ' driver
      prcnnUserMan.ConnectionString = "SERVER=10.8.1.30"
#End If
      ' Open the connection
      prcnnUserMan.Open()
#If SQLServer Then
      ' Execute the SQL command
      cmmUserMan.ExecuteNonQuery()
#End If
   End Sub
End Class