Imports System.Data.SqlClient

' Listing 5-4-1 & 5-12-1
Public Class CGeneral
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.1;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   ' Declare and instantiate connection
   Private prcnnUserMan As SqlConnection = _
      New SqlConnection(PR_STR_CONNECTION_STRING)

   Public Sub New()
      MyBase.New()
      ' Listing 5-4-2
      ' Set up StateChange event handler
      AddHandler prcnnUserMan.StateChange, New _
         StateChangeEventHandler(AddressOf OnStateChange)
      ' Listing 5-12-2
      ' Set up InfoMessage event handler
      AddHandler prcnnUserMan.InfoMessage, New _
         SqlInfoMessageEventHandler(AddressOf OnInfoMessage)
   End Sub

   ' Listing 5-4-3
   Private Shared Sub OnStateChange(ByVal sender As Object, _
      ByVal args As StateChangeEventArgs)
      ' Display the original and the current state
      MessageBox.Show("The original connection state was: " & _
         args.OriginalState.ToString() & vbCrLf & _
         "The current connection state is: " & _
         args.CurrentState.ToString())
   End Sub

   ' Listing 5-12-3
   Private Shared Sub OnInfoMessage(ByVal sender As Object, _
      ByVal args As SqlInfoMessageEventArgs)
      Dim objError As SqlError

      ' Loop through all the error messages 
      For Each objError In args.Errors
         ' Display the error properties
         MessageBox.Show("The " & objError.Source & _
            " has raised a warning on the " & _
            objError.Server & " server. These are the properties :" & _
            vbCrLf & vbCrLf & "Severity: " & objError.Class & vbCrLf & _
            "Number: " & objError.Number & vbCrLf & "State: " & _
            objError.State & vbCrLf & "Line: " & objError.LineNumber & vbCrLf & _
            "Procedure: " & objError.Procedure & vbCrLf & "Message: " & _
            objError.Message)
      Next

      ' Display the message and the source
      MessageBox.Show("Info Message: " & args.Message & _
         vbCrLf & "Info Source: " + args.Source)
   End Sub

   ' Listing 5-4-4
   Public Sub TriggerStateChangeEvent()
      ' Open the connection
      prcnnUserMan.Open()
      ' Close the connection
      prcnnUserMan.Close()
   End Sub

   ' Listing 5-12-4
   Public Sub TriggerInfoMessageEvent()
      Dim cmmUserMan As SqlCommand = _
         New SqlCommand("RAISERROR('This is an info message event.', 10, 1)", _
         prcnnUserMan)
      ' Open the connection
      prcnnUserMan.Open()
      ' Execute the T-SQL command
      cmmUserMan.ExecuteNonQuery()
   End Sub
End Class