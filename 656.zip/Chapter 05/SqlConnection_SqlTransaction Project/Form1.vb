Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnOpenConnection As System.Windows.Forms.Button
   Friend WithEvents btnTriggerStateChange As System.Windows.Forms.Button
   Friend WithEvents btnTriggerInfoMessage As System.Windows.Forms.Button
   Friend WithEvents btnCheckConnectionPooling As System.Windows.Forms.Button
   Friend WithEvents Button1 As System.Windows.Forms.Button
   Friend WithEvents btnBeginNonDefaultIsolationLevelTransaction As System.Windows.Forms.Button
   Friend WithEvents btnBeginNestedTransaction As System.Windows.Forms.Button
   Friend WithEvents btnBeginNamedTransaction As System.Windows.Forms.Button
   Friend WithEvents btnBeginNamedNonDefaultIsolationLevelTransaction As System.Windows.Forms.Button
   Friend WithEvents btnDetermineTransactionLevel As System.Windows.Forms.Button
   Friend WithEvents btnTraverseAllOLEDBErrors As System.Windows.Forms.Button
   Friend WithEvents btnCheckBeginTransactionMethodException As System.Windows.Forms.Button
   Friend WithEvents btnCheckConnectionStringPropertyException As System.Windows.Forms.Button
   Friend WithEvents btnCheckConnectionTimeoutPropertyException As System.Windows.Forms.Button
   Friend WithEvents btnCheckChangeDatabaseMethodException As System.Windows.Forms.Button
   Friend WithEvents btnCheckOpenMethodException As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnOpenConnection = New System.Windows.Forms.Button()
      Me.btnTriggerStateChange = New System.Windows.Forms.Button()
      Me.btnTriggerInfoMessage = New System.Windows.Forms.Button()
      Me.btnCheckConnectionPooling = New System.Windows.Forms.Button()
      Me.Button1 = New System.Windows.Forms.Button()
      Me.btnBeginNonDefaultIsolationLevelTransaction = New System.Windows.Forms.Button()
      Me.btnBeginNestedTransaction = New System.Windows.Forms.Button()
      Me.btnBeginNamedTransaction = New System.Windows.Forms.Button()
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction = New System.Windows.Forms.Button()
      Me.btnDetermineTransactionLevel = New System.Windows.Forms.Button()
      Me.btnTraverseAllOLEDBErrors = New System.Windows.Forms.Button()
      Me.btnCheckBeginTransactionMethodException = New System.Windows.Forms.Button()
      Me.btnCheckConnectionStringPropertyException = New System.Windows.Forms.Button()
      Me.btnCheckConnectionTimeoutPropertyException = New System.Windows.Forms.Button()
      Me.btnCheckChangeDatabaseMethodException = New System.Windows.Forms.Button()
      Me.btnCheckOpenMethodException = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnOpenConnection
      '
      Me.btnOpenConnection.Location = New System.Drawing.Point(12, 34)
      Me.btnOpenConnection.Name = "btnOpenConnection"
      Me.btnOpenConnection.Size = New System.Drawing.Size(202, 23)
      Me.btnOpenConnection.TabIndex = 0
      Me.btnOpenConnection.Text = "Open Connection"
      '
      'btnTriggerStateChange
      '
      Me.btnTriggerStateChange.Location = New System.Drawing.Point(12, 62)
      Me.btnTriggerStateChange.Name = "btnTriggerStateChange"
      Me.btnTriggerStateChange.Size = New System.Drawing.Size(202, 23)
      Me.btnTriggerStateChange.TabIndex = 1
      Me.btnTriggerStateChange.Text = "Trigger State Change"
      '
      'btnTriggerInfoMessage
      '
      Me.btnTriggerInfoMessage.Location = New System.Drawing.Point(12, 90)
      Me.btnTriggerInfoMessage.Name = "btnTriggerInfoMessage"
      Me.btnTriggerInfoMessage.Size = New System.Drawing.Size(202, 23)
      Me.btnTriggerInfoMessage.TabIndex = 2
      Me.btnTriggerInfoMessage.Text = "Trigger Info Message"
      '
      'btnCheckConnectionPooling
      '
      Me.btnCheckConnectionPooling.Location = New System.Drawing.Point(12, 146)
      Me.btnCheckConnectionPooling.Name = "btnCheckConnectionPooling"
      Me.btnCheckConnectionPooling.Size = New System.Drawing.Size(202, 23)
      Me.btnCheckConnectionPooling.TabIndex = 4
      Me.btnCheckConnectionPooling.Text = "Check Connection Pooling"
      '
      'Button1
      '
      Me.Button1.Location = New System.Drawing.Point(12, 118)
      Me.Button1.Name = "Button1"
      Me.Button1.Size = New System.Drawing.Size(202, 23)
      Me.Button1.TabIndex = 3
      Me.Button1.Text = "Check ConnectionString White Space"
      '
      'btnBeginNonDefaultIsolationLevelTransaction
      '
      Me.btnBeginNonDefaultIsolationLevelTransaction.Location = New System.Drawing.Point(235, 34)
      Me.btnBeginNonDefaultIsolationLevelTransaction.Name = "btnBeginNonDefaultIsolationLevelTransaction"
      Me.btnBeginNonDefaultIsolationLevelTransaction.Size = New System.Drawing.Size(282, 23)
      Me.btnBeginNonDefaultIsolationLevelTransaction.TabIndex = 5
      Me.btnBeginNonDefaultIsolationLevelTransaction.Text = "Begin NonDefault Isolation Level Transaction"
      '
      'btnBeginNestedTransaction
      '
      Me.btnBeginNestedTransaction.Location = New System.Drawing.Point(235, 146)
      Me.btnBeginNestedTransaction.Name = "btnBeginNestedTransaction"
      Me.btnBeginNestedTransaction.Size = New System.Drawing.Size(282, 23)
      Me.btnBeginNestedTransaction.TabIndex = 9
      Me.btnBeginNestedTransaction.Text = "Begin Nested Transaction"
      '
      'btnBeginNamedTransaction
      '
      Me.btnBeginNamedTransaction.Location = New System.Drawing.Point(235, 62)
      Me.btnBeginNamedTransaction.Name = "btnBeginNamedTransaction"
      Me.btnBeginNamedTransaction.Size = New System.Drawing.Size(282, 23)
      Me.btnBeginNamedTransaction.TabIndex = 6
      Me.btnBeginNamedTransaction.Text = "Begin Named Transaction"
      '
      'btnBeginNamedNonDefaultIsolationLevelTransaction
      '
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Location = New System.Drawing.Point(235, 90)
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Name = "btnBeginNamedNonDefaultIsolationLevelTransaction"
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Size = New System.Drawing.Size(282, 23)
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.TabIndex = 7
      Me.btnBeginNamedNonDefaultIsolationLevelTransaction.Text = "Begin Named NonDefault Isolation Level Transaction"
      '
      'btnDetermineTransactionLevel
      '
      Me.btnDetermineTransactionLevel.Location = New System.Drawing.Point(235, 118)
      Me.btnDetermineTransactionLevel.Name = "btnDetermineTransactionLevel"
      Me.btnDetermineTransactionLevel.Size = New System.Drawing.Size(282, 23)
      Me.btnDetermineTransactionLevel.TabIndex = 8
      Me.btnDetermineTransactionLevel.Text = "Determine Transaction Level"
      '
      'btnTraverseAllOLEDBErrors
      '
      Me.btnTraverseAllOLEDBErrors.Location = New System.Drawing.Point(236, 188)
      Me.btnTraverseAllOLEDBErrors.Name = "btnTraverseAllOLEDBErrors"
      Me.btnTraverseAllOLEDBErrors.Size = New System.Drawing.Size(281, 23)
      Me.btnTraverseAllOLEDBErrors.TabIndex = 10
      Me.btnTraverseAllOLEDBErrors.Text = "Traverse All SQL Errors"
      '
      'btnCheckBeginTransactionMethodException
      '
      Me.btnCheckBeginTransactionMethodException.Location = New System.Drawing.Point(236, 216)
      Me.btnCheckBeginTransactionMethodException.Name = "btnCheckBeginTransactionMethodException"
      Me.btnCheckBeginTransactionMethodException.Size = New System.Drawing.Size(281, 23)
      Me.btnCheckBeginTransactionMethodException.TabIndex = 11
      Me.btnCheckBeginTransactionMethodException.Text = "Check BeginTransaction Method Exception"
      '
      'btnCheckConnectionStringPropertyException
      '
      Me.btnCheckConnectionStringPropertyException.Location = New System.Drawing.Point(236, 244)
      Me.btnCheckConnectionStringPropertyException.Name = "btnCheckConnectionStringPropertyException"
      Me.btnCheckConnectionStringPropertyException.Size = New System.Drawing.Size(281, 23)
      Me.btnCheckConnectionStringPropertyException.TabIndex = 12
      Me.btnCheckConnectionStringPropertyException.Text = "Check ConnectionString Property Exception"
      '
      'btnCheckConnectionTimeoutPropertyException
      '
      Me.btnCheckConnectionTimeoutPropertyException.Location = New System.Drawing.Point(236, 272)
      Me.btnCheckConnectionTimeoutPropertyException.Name = "btnCheckConnectionTimeoutPropertyException"
      Me.btnCheckConnectionTimeoutPropertyException.Size = New System.Drawing.Size(281, 23)
      Me.btnCheckConnectionTimeoutPropertyException.TabIndex = 13
      Me.btnCheckConnectionTimeoutPropertyException.Text = "Check ConnectionTimeout Property Exception"
      '
      'btnCheckChangeDatabaseMethodException
      '
      Me.btnCheckChangeDatabaseMethodException.Location = New System.Drawing.Point(236, 300)
      Me.btnCheckChangeDatabaseMethodException.Name = "btnCheckChangeDatabaseMethodException"
      Me.btnCheckChangeDatabaseMethodException.Size = New System.Drawing.Size(281, 23)
      Me.btnCheckChangeDatabaseMethodException.TabIndex = 14
      Me.btnCheckChangeDatabaseMethodException.Text = "Check ChangeDatabase Method Exception"
      '
      'btnCheckOpenMethodException
      '
      Me.btnCheckOpenMethodException.Location = New System.Drawing.Point(236, 328)
      Me.btnCheckOpenMethodException.Name = "btnCheckOpenMethodException"
      Me.btnCheckOpenMethodException.Size = New System.Drawing.Size(281, 23)
      Me.btnCheckOpenMethodException.TabIndex = 15
      Me.btnCheckOpenMethodException.Text = "Check Open Method Exception"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(528, 362)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCheckOpenMethodException, Me.btnCheckChangeDatabaseMethodException, Me.btnCheckConnectionTimeoutPropertyException, Me.btnCheckConnectionStringPropertyException, Me.btnCheckBeginTransactionMethodException, Me.btnTraverseAllOLEDBErrors, Me.btnDetermineTransactionLevel, Me.btnBeginNamedNonDefaultIsolationLevelTransaction, Me.btnBeginNamedTransaction, Me.btnBeginNonDefaultIsolationLevelTransaction, Me.btnBeginNestedTransaction, Me.Button1, Me.btnCheckConnectionPooling, Me.btnTriggerInfoMessage, Me.btnTriggerStateChange, Me.btnOpenConnection})
      Me.Name = "Form1"
      Me.Text = "SqlConnection & SqlTransaction Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnOpenConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenConnection.Click
      OpenConnection()
   End Sub

   Private Sub btnTriggerStateChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerStateChange.Click
      Dim objGeneral As New CGeneral()

      objGeneral.TriggerStateChangeEvent()
   End Sub

   Private Sub btnTriggerInfoMessage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerInfoMessage.Click
      Dim objGeneral As New CGeneral()

      objGeneral.TriggerInfoMessageEvent()
   End Sub

   Private Sub btnCheckConnectionPooling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckConnectionPooling.Click
      CheckConnectionPooling()
   End Sub

   Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
      CheckConnectionStringWhiteSpace()
   End Sub

   Private Sub btnBeginNonDefaultIsolationLevelTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginNonDefaultIsolationLevelTransaction.Click
      BeginNamedNonDefaultIsolationLevelTransaction()
   End Sub

   Private Sub btnBeginNamedTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginNamedTransaction.Click
      BeginNamedTransaction()
   End Sub

   Private Sub btnBeginNamedNonDefaultIsolationLevelTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginNamedNonDefaultIsolationLevelTransaction.Click
      BeginNamedNonDefaultIsolationLevelTransaction()
   End Sub

   Private Sub btnBeginNestedTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginNestedTransaction.Click
      UseTransactionSavePoints()
   End Sub

   Private Sub btnDetermineTransactionLevel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetermineTransactionLevel.Click
      DetermineTransactionIsolationLevel()
   End Sub

   Private Sub btnTraverseAllOLEDBErrors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTraverseAllOLEDBErrors.Click
      TraverseAllSqlErrors()
   End Sub

   Private Sub btnCheckBeginTransactionMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckBeginTransactionMethodException.Click
      CheckBeginTransactionMethodException()
   End Sub

   Private Sub btnCheckConnectionStringPropertyException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckConnectionStringPropertyException.Click
      CheckConnectionStringPropertyException()
   End Sub

   Private Sub btnCheckConnectionTimeoutPropertyException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckConnectionTimeoutPropertyException.Click
      CheckConnectionTimeoutPropertyException()
   End Sub

   Private Sub btnCheckChangeDatabaseMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckChangeDatabaseMethodException.Click
      CheckChangeDatabaseMethodException()
   End Sub

   Private Sub btnCheckOpenMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckOpenMethodException.Click
      CheckOpenMethodException()
   End Sub
End Class
