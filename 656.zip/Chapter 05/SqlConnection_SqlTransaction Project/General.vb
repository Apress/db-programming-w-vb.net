Option Strict On

Imports System.Data.SqlClient
Imports System.Xml

Module General
   ' Listing 5-1
   'Private Const PR_STR_CONNECTION_STRING As String = "Data Source=USERMANPC;" & _
   '   "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "Server=USERMANPC;" & _
   '   "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "Addr=10.8.1.1;" & _
   '   "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "Address=10.8.1.1;" & _
   '   "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "Network Address=10.8.1.1;" & _
   '   "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "Address=10.8.1.1;" & _
   '   "User ID=UserMan;Password=userman;Database=UserMan"
   'Private Const PR_STR_CONNECTION_STRING As String = "Address=10.8.1.1;" & _
   '   "User ID=UserMan;Pwd=userman;Database=UserMan"
   Private Const PR_STR_CONNECTION_STRING As String = "Address=10.8.1.1;" & _
      "UID=UserMan;Pwd=userman;Database=UserMan"

   ' Listing 5-2
   Public Sub OpenConnection()
      ' Declare connection object
      Dim cnnUserMan As SqlConnection

      ' Instantiate the connection object
      cnnUserMan = New SqlConnection()

      Try
         ' Set up connection string
         cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
         ' Open the connection
         cnnUserMan.Open()
      Catch objE As Exception
         ' Deal with exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 5-5
   Public Sub CheckConnectionStringWhiteSpace()
      Dim cnnUserMan1 As New SqlConnection()
      Dim cnnUserMan2 As New SqlConnection()

      Try
         ' Set the connection string for the connections
         cnnUserMan1.ConnectionString = "User Id=UserMan;Password=userman;" & _
          "Data Source=USERMANPC;Initial Catalog=UserMan;Max Pool Size=1;Connection Timeout=5"
         cnnUserMan2.ConnectionString = "User Id=UserMan;Password=userman; " & _
          "Data Source=USERMANPC;Initial Catalog=UserMan;Max Pool Size=1;Connection Timeout=5"

         ' cnnUserMan1 and cnnUserMan2 will NOT be added to the same connection pool
         ' because cnnUserMan2 contains an extra space character right after
         ' Password=userman;

         ' Open the cnnUserMan1 connection
         cnnUserMan1.Open()
         ' Open the cnnUserMan2 connection
         cnnUserMan2.Open()
      Catch objE As Exception
         ' This message will be be displayed if the two connection strings are the same,
         ' because then the connection pool will have reached it's max size (1)
         ' If you don't see the message, the connections are drawn from different pools
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 5-9
   Public Sub CheckConnectionPooling()
      Dim cnnUserMan1 As SqlConnection
      Dim cnnUserMan2 As SqlConnection

      Try
         ' Instantiate and open the first SQL connection
         cnnUserMan1 = New SqlConnection(PR_STR_CONNECTION_STRING & ";Max Pool Size=1;Connection Timeout=5")
         cnnUserMan1.Open()

         ' Instantiate and open the second SQL connection
         cnnUserMan2 = New SqlConnection(PR_STR_CONNECTION_STRING & ";Max Pool Size=1;Connection Timeout=5")
         cnnUserMan2.Open()
      Catch objE As Exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 5-14
   Public Sub BeginNonDefaultIsolationLevelTransaction()
      Dim cnnUserMan As SqlConnection
      Dim traUserMan As SqlTransaction

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Begin transaction
      traUserMan = cnnUserMan.BeginTransaction( _
         IsolationLevel.ReadCommitted)
   End Sub

   ' Listing 5-15
   Public Sub BeginNamedTransaction()
      Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

      Dim cnnUserMan As SqlConnection
      Dim traUserMan As SqlTransaction

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(STR_MAIN_TRANSACTION_NAME)
   End Sub

   ' Listing 5-16
   Public Sub BeginNamedNonDefaultIsolationLevelTransaction()
      Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

      Dim cnnUserMan As SqlConnection
      Dim traUserMan As SqlTransaction

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted, STR_MAIN_TRANSACTION_NAME)
   End Sub

   ' Listing 5-17
   Public Sub DetermineTransactionIsolationLevel()
      Const STR_MAIN_TRANSACTION_NAME As String = "MainTransaction"

      Dim cnnUserMan As SqlConnection
      Dim traUserMan As SqlTransaction
      Dim intIsolationLevel As Integer

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      ' Start named transaction with non-default isolation level
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted, _
         STR_MAIN_TRANSACTION_NAME)

      ' Return the isolation level as text
      MsgBox(traUserMan.IsolationLevel.ToString)
      ' Return the isolation level as an integer value
      intIsolationLevel = traUserMan.IsolationLevel
   End Sub

   ' Listing 5-19
   Public Sub UseTransactionSavePoints()
      Const STR_USER99_TRANSACTION_NAME As String = "User99"
      Const STR_USER3_TRANSACTION_NAME As String = "User3"
      Const STR_USER2_TRANSACTION_NAME As String = "User2"

      Dim cnnUserMan As SqlConnection
      Dim traUserMan As SqlTransaction
      Dim cmmDelete As New SqlCommand()

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      ' Start named main transaction
      traUserMan = cnnUserMan.BeginTransaction(STR_USER99_TRANSACTION_NAME)
      ' Initialize the command
      cmmDelete.Connection = cnnUserMan
      cmmDelete.Transaction = traUserMan
      ' Delete User99
      cmmDelete.CommandText = "DELETE FROM tblUser WHERE LoginName='User99'"
      cmmDelete.ExecuteNonQuery()
      ' Save transaction reference point
      traUserMan.Save(STR_USER3_TRANSACTION_NAME)
      ' Delete User3
      cmmDelete.CommandText = "DELETE FROM tblUser WHERE LoginName='User3'"
      cmmDelete.ExecuteNonQuery()
      ' Save transaction reference point
      traUserMan.Save(STR_USER2_TRANSACTION_NAME)
      ' Delete User2
      cmmDelete.CommandText = "DELETE FROM tblUser WHERE LoginName='User2'"
      cmmDelete.ExecuteNonQuery()
      ' Roll back deletion of User2
      traUserMan.Rollback(STR_USER2_TRANSACTION_NAME)
      ' Commit all pending changes in main transaction
      traUserMan.Commit()
   End Sub

   ' Listing 5-20
   Public Sub TraverseAllSqlErrors()
      Dim cnnUserMan As SqlConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Do your stuff...
         ' ...
      Catch objException As SqlException
         ' This Catch block will handle all exceptions that 
         ' the SqlDataAdapter cannot handle
         Dim objError As SqlError

         For Each objError In objException.Errors
            MsgBox(objException.Message)
         Next
      Catch objException As Exception
         ' This Catch block will catch all exceptions that
         ' the SqlDataAdapter can handle
         MsgBox(objException.Message)
      End Try
   End Sub

   ' Listing 5-21
   Public Sub CheckBeginTransactionMethodException()
      Dim cnnUserMan As SqlConnection
      Dim traUserMan1, traUserMan2 As SqlTransaction

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      Try
         ' Start parallel transactions
         traUserMan1 = cnnUserMan.BeginTransaction()
         traUserMan2 = cnnUserMan.BeginTransaction()
      Catch objException As InvalidOperationException
         ' Check if a BeginTransaction method threw the exception
         If objException.TargetSite.Name = "BeginTransaction" Then
            MsgBox("The BeginTransaction method threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-22
   Public Sub CheckConnectionStringPropertyException()
      Dim cnnUserMan As SqlConnection

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      Try
         ' Set the connection string
         cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
      Catch objException As InvalidOperationException
         ' Check if setting the ConnectionString threw the exception
         If objException.TargetSite.Name = "set_ConnectionString" Then
            MsgBox("The ConnectionString property threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-23
   Public Sub CheckConnectionTimeoutPropertyException()
      Dim cnnUserMan As SqlConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING & ";Connection Timeout=-1")
         ' Open the connection
         cnnUserMan.Open()
      Catch objException As ArgumentException
         ' Check if setting the Connection Timeout to an invalid value threw the exception
         If objException.TargetSite.Name = "SetConnectTimeout" Then
            MsgBox("The Connection Timeout value threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-24
   Public Sub CheckChangeDatabaseMethodException()
      Dim cnnUserMan As SqlConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         ' If the following line is commented out, the ChangeDatabase exception will be thrown
         'cnnUserMan.Open()
         ' Change database
         cnnUserMan.ChangeDatabase("master")
      Catch objInvOpException As InvalidOperationException
         ' Check if we tried to change database on an invalid connection
         If objInvOpException.TargetSite.Name = "ChangeDatabase" Then
            MsgBox("The ChangeDatabase method threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-25
   Public Sub CheckOpenMethodException()
      Dim cnnUserMan As SqlConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Open the connection
         cnnUserMan.Open()
      Catch objException As InvalidOperationException
         ' Check if we tried to open an already open connection
         If objException.TargetSite.Name = "Open" Then
            MsgBox("The Open method threw the exception!")
         End If
      End Try
   End Sub
End Module