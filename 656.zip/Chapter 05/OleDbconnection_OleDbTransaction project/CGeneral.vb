Imports System.Data.OleDb

'#Const Oracle = 1
'#Const DB2 = 1
'#Const MSAccess = 1
#Const SQLSERVER = 1
' You simply uncomment the line above for the DBMS you want to use

' Listing 5-4-1 & 5-11-1
Public Class CGeneral
#If SQLServer Then
   Private Const PR_STR_CONNECTION_STRING As String = "Provider=SQLOLEDB;" & _
      "Data Source=10.8.1.30;User ID=UserMan;Password=userman;" & _
      "Initial Catalog=UserMan"
#ElseIf MSAccess Then
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\DBPWVBNET\UserMan.mdb;User Id=;" & _
      "Password=;Mode=Share Deny None;"
#ElseIf Oracle Then
   ' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
    "Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#ElseIf DB2 Then
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Declare and instantiate connection
   Private prcnnUserMan As OleDbConnection = _
      New OleDbConnection(PR_STR_CONNECTION_STRING)

   Public Sub New()
      MyBase.New()
      ' Listing 5-4-2
      ' Set up StateChange event handler
      AddHandler prcnnUserMan.StateChange, New _
         StateChangeEventHandler(AddressOf OnStateChange)
      ' Listing 5-11-2
      ' Set up InfoMessage event handler
      AddHandler prcnnUserMan.InfoMessage, New _
         OleDbInfoMessageEventHandler(AddressOf OnInfoMessage)
   End Sub

   ' Listing 5-4-3
   Private Shared Sub OnStateChange(ByVal sender As Object, _
      ByVal args As StateChangeEventArgs)
      ' Display the original and the current state
      MessageBox.Show("The original connection state was: " & _
         args.OriginalState.ToString() & vbCrLf & _
         "The current connection state is: " & _
         args.CurrentState.ToString())
   End Sub

   ' Listing 5-11-3
   Private Shared Sub OnInfoMessage(ByVal sender As Object, _
      ByVal args As OleDbInfoMessageEventArgs)
      Dim objError As OleDbError

      ' Loop through all the error messages 
      For Each objError In args.Errors
         ' Display the error properties
         MessageBox.Show("The " & objError.Source & _
            " has raised a warning. These are the properties :" & _
            vbCrLf & vbCrLf & "Native Error: " & objError.NativeError & vbCrLf & _
            "SQL State: " & objError.SQLState & vbCrLf & "Message: " & _
            objError.Message)
      Next

      ' Display the message and the source
      MessageBox.Show("Info Message: " & args.Message & _
         vbCrLf & "Info Source: " + args.Source)
   End Sub

   ' Listing 5-4-4
   Public Sub TriggerStateChangeEvent()
      ' Open the connection
      prcnnUserMan.Open()
      ' Close the connection
      prcnnUserMan.Close()
   End Sub

   ' Listing 5-11-4
   Public Sub TriggerInfoMessageEvent()
#If SQLServer Then
      Dim cmmUserMan As OleDbCommand = _
         New OleDbCommand("RAISERROR('This is an info message event.', 10, 1)", _
         prcnnUserMan)
#ElseIf DB2 Then
      ' By adding the SERVER value name to the connection string, the InfoMessage
      ' event is triggered, because this is an invalid value name for the DB2 OLE DB
      ' provider
      prcnnUserMan.ConnectionString = "SERVER=10.8.1.30"
#End If
      ' Open the connection
      prcnnUserMan.Open()
#If SQLServer Then
      ' Execute the SQL command
      cmmUserMan.ExecuteNonQuery()
#End If
   End Sub
End Class