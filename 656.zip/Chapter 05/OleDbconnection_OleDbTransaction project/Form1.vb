Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnOpenConnection As System.Windows.Forms.Button
   Friend WithEvents btnDisableConnectionPooling As System.Windows.Forms.Button
   Friend WithEvents btnClearConnectionPool As System.Windows.Forms.Button
   Friend WithEvents btnTriggerInfoMessage As System.Windows.Forms.Button
   Friend WithEvents btnTriggerStateChange As System.Windows.Forms.Button
   Friend WithEvents btnBeginNestedTransaction As System.Windows.Forms.Button
   Friend WithEvents btnBeginNonDefaultIsolationLevelTransaction As System.Windows.Forms.Button
   Friend WithEvents btnDetermineTransactionLevel As System.Windows.Forms.Button
   Friend WithEvents btnTraverseAllOLEDBErrors As System.Windows.Forms.Button
   Friend WithEvents btnCheckBeginTransactionMethodException As System.Windows.Forms.Button
   Friend WithEvents btnCheckConnectionStringPropertyException As System.Windows.Forms.Button
   Friend WithEvents btnCheckChangeDatabaseMethodException As System.Windows.Forms.Button
   Friend WithEvents btnCheckOpenMethodException As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnOpenConnection = New System.Windows.Forms.Button()
      Me.btnDisableConnectionPooling = New System.Windows.Forms.Button()
      Me.btnClearConnectionPool = New System.Windows.Forms.Button()
      Me.btnTriggerInfoMessage = New System.Windows.Forms.Button()
      Me.btnTriggerStateChange = New System.Windows.Forms.Button()
      Me.btnBeginNestedTransaction = New System.Windows.Forms.Button()
      Me.btnBeginNonDefaultIsolationLevelTransaction = New System.Windows.Forms.Button()
      Me.btnDetermineTransactionLevel = New System.Windows.Forms.Button()
      Me.btnTraverseAllOLEDBErrors = New System.Windows.Forms.Button()
      Me.btnCheckBeginTransactionMethodException = New System.Windows.Forms.Button()
      Me.btnCheckConnectionStringPropertyException = New System.Windows.Forms.Button()
      Me.btnCheckChangeDatabaseMethodException = New System.Windows.Forms.Button()
      Me.btnCheckOpenMethodException = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnOpenConnection
      '
      Me.btnOpenConnection.Location = New System.Drawing.Point(26, 35)
      Me.btnOpenConnection.Name = "btnOpenConnection"
      Me.btnOpenConnection.Size = New System.Drawing.Size(194, 28)
      Me.btnOpenConnection.TabIndex = 1
      Me.btnOpenConnection.Text = "Open Connection"
      '
      'btnDisableConnectionPooling
      '
      Me.btnDisableConnectionPooling.Location = New System.Drawing.Point(26, 138)
      Me.btnDisableConnectionPooling.Name = "btnDisableConnectionPooling"
      Me.btnDisableConnectionPooling.Size = New System.Drawing.Size(194, 29)
      Me.btnDisableConnectionPooling.TabIndex = 4
      Me.btnDisableConnectionPooling.Text = "Disable Connection Pooling"
      '
      'btnClearConnectionPool
      '
      Me.btnClearConnectionPool.Location = New System.Drawing.Point(26, 104)
      Me.btnClearConnectionPool.Name = "btnClearConnectionPool"
      Me.btnClearConnectionPool.Size = New System.Drawing.Size(194, 28)
      Me.btnClearConnectionPool.TabIndex = 3
      Me.btnClearConnectionPool.Text = "Clear Connection Pool"
      '
      'btnTriggerInfoMessage
      '
      Me.btnTriggerInfoMessage.Location = New System.Drawing.Point(26, 173)
      Me.btnTriggerInfoMessage.Name = "btnTriggerInfoMessage"
      Me.btnTriggerInfoMessage.Size = New System.Drawing.Size(194, 28)
      Me.btnTriggerInfoMessage.TabIndex = 5
      Me.btnTriggerInfoMessage.Text = "Trigger Info Message"
      '
      'btnTriggerStateChange
      '
      Me.btnTriggerStateChange.Location = New System.Drawing.Point(26, 69)
      Me.btnTriggerStateChange.Name = "btnTriggerStateChange"
      Me.btnTriggerStateChange.Size = New System.Drawing.Size(194, 28)
      Me.btnTriggerStateChange.TabIndex = 2
      Me.btnTriggerStateChange.Text = "Trigger State Change"
      '
      'btnBeginNestedTransaction
      '
      Me.btnBeginNestedTransaction.Location = New System.Drawing.Point(251, 104)
      Me.btnBeginNestedTransaction.Name = "btnBeginNestedTransaction"
      Me.btnBeginNestedTransaction.Size = New System.Drawing.Size(306, 28)
      Me.btnBeginNestedTransaction.TabIndex = 8
      Me.btnBeginNestedTransaction.Text = "Begin Nested Transaction"
      '
      'btnBeginNonDefaultIsolationLevelTransaction
      '
      Me.btnBeginNonDefaultIsolationLevelTransaction.Location = New System.Drawing.Point(251, 35)
      Me.btnBeginNonDefaultIsolationLevelTransaction.Name = "btnBeginNonDefaultIsolationLevelTransaction"
      Me.btnBeginNonDefaultIsolationLevelTransaction.Size = New System.Drawing.Size(306, 28)
      Me.btnBeginNonDefaultIsolationLevelTransaction.TabIndex = 6
      Me.btnBeginNonDefaultIsolationLevelTransaction.Text = "Begin NonDefault Isolation Level Transaction"
      '
      'btnDetermineTransactionLevel
      '
      Me.btnDetermineTransactionLevel.Location = New System.Drawing.Point(251, 69)
      Me.btnDetermineTransactionLevel.Name = "btnDetermineTransactionLevel"
      Me.btnDetermineTransactionLevel.Size = New System.Drawing.Size(306, 28)
      Me.btnDetermineTransactionLevel.TabIndex = 7
      Me.btnDetermineTransactionLevel.Text = "Determine Transaction Level"
      '
      'btnTraverseAllOLEDBErrors
      '
      Me.btnTraverseAllOLEDBErrors.Location = New System.Drawing.Point(251, 173)
      Me.btnTraverseAllOLEDBErrors.Name = "btnTraverseAllOLEDBErrors"
      Me.btnTraverseAllOLEDBErrors.Size = New System.Drawing.Size(306, 28)
      Me.btnTraverseAllOLEDBErrors.TabIndex = 9
      Me.btnTraverseAllOLEDBErrors.Text = "Traverse All OLE DB Errors"
      '
      'btnCheckBeginTransactionMethodException
      '
      Me.btnCheckBeginTransactionMethodException.Location = New System.Drawing.Point(251, 207)
      Me.btnCheckBeginTransactionMethodException.Name = "btnCheckBeginTransactionMethodException"
      Me.btnCheckBeginTransactionMethodException.Size = New System.Drawing.Size(306, 29)
      Me.btnCheckBeginTransactionMethodException.TabIndex = 10
      Me.btnCheckBeginTransactionMethodException.Text = "Check BeginTransaction Method Exception"
      '
      'btnCheckConnectionStringPropertyException
      '
      Me.btnCheckConnectionStringPropertyException.Location = New System.Drawing.Point(251, 242)
      Me.btnCheckConnectionStringPropertyException.Name = "btnCheckConnectionStringPropertyException"
      Me.btnCheckConnectionStringPropertyException.Size = New System.Drawing.Size(306, 28)
      Me.btnCheckConnectionStringPropertyException.TabIndex = 11
      Me.btnCheckConnectionStringPropertyException.Text = "Check ConnectionString Property Exception"
      '
      'btnCheckChangeDatabaseMethodException
      '
      Me.btnCheckChangeDatabaseMethodException.Location = New System.Drawing.Point(251, 276)
      Me.btnCheckChangeDatabaseMethodException.Name = "btnCheckChangeDatabaseMethodException"
      Me.btnCheckChangeDatabaseMethodException.Size = New System.Drawing.Size(306, 29)
      Me.btnCheckChangeDatabaseMethodException.TabIndex = 12
      Me.btnCheckChangeDatabaseMethodException.Text = "Check ChangeDatabase Method Exception"
      '
      'btnCheckOpenMethodException
      '
      Me.btnCheckOpenMethodException.Location = New System.Drawing.Point(251, 311)
      Me.btnCheckOpenMethodException.Name = "btnCheckOpenMethodException"
      Me.btnCheckOpenMethodException.Size = New System.Drawing.Size(306, 28)
      Me.btnCheckOpenMethodException.TabIndex = 13
      Me.btnCheckOpenMethodException.Text = "Check Open Method Exception"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(583, 351)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnCheckOpenMethodException, Me.btnCheckChangeDatabaseMethodException, Me.btnCheckConnectionStringPropertyException, Me.btnCheckBeginTransactionMethodException, Me.btnTraverseAllOLEDBErrors, Me.btnDetermineTransactionLevel, Me.btnBeginNonDefaultIsolationLevelTransaction, Me.btnBeginNestedTransaction, Me.btnTriggerInfoMessage, Me.btnTriggerStateChange, Me.btnClearConnectionPool, Me.btnDisableConnectionPooling, Me.btnOpenConnection})
      Me.Name = "Form1"
      Me.Text = "OleDbConnection_OleDbTransaction Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnOpenConnection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenConnection.Click
      'OpenConnection()
      OpenConnectionUsingUDLFile()
   End Sub

   Private Sub btnDisableConnectionPooling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisableConnectionPooling.Click
      DisableAutomaticConnectionPooling()
   End Sub

   Private Sub btnClearConnectionPool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearConnectionPool.Click
      ClearConnectionPool()
   End Sub

   Private Sub btnTriggerStateChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerStateChange.Click
      Dim objGeneral As New CGeneral()

      objGeneral.TriggerStateChangeEvent()
   End Sub

   Private Sub btnTriggerInfoMessage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerInfoMessage.Click
      Dim objGeneral As New CGeneral()

      objGeneral.TriggerInfoMessageEvent()
   End Sub

   Private Sub btnBeginNestedTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginNestedTransaction.Click
      NestTransactions()
   End Sub

   Private Sub btnBeginNonDefaultIsolationLevelTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeginNonDefaultIsolationLevelTransaction.Click
      BeginNonDefaultIsolationLevelTransaction()
   End Sub

   Private Sub btnTraverseAllOLEDBErrors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTraverseAllOLEDBErrors.Click
      TraverseAllOleDbErrors()
   End Sub

   Private Sub btnCheckBeginTransactionMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckBeginTransactionMethodException.Click
      CheckBeginTransactionMethodException()
   End Sub

   Private Sub btnCheckConnectionStringPropertyException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckConnectionStringPropertyException.Click
      CheckConnectionStringPropertyException()
   End Sub

   Private Sub btnCheckChangeDatabaseMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckChangeDatabaseMethodException.Click
      CheckChangeDatabaseMethodException()
   End Sub

   Private Sub btnCheckOpenMethodException_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckOpenMethodException.Click
      CheckOpenMethodException()
   End Sub

   Private Sub btnDetermineTransactionLevel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetermineTransactionLevel.Click
      DetermineTransactionIsolationLevel()
   End Sub
End Class