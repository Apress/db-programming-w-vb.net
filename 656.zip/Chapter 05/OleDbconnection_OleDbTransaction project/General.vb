Option Strict On

Imports System.Data.OleDb
Imports System.Xml
Imports ADODB

'#Const Oracle = 1
'#Const DB2 = 1
#Const MSAccess = 1
'#Const SQLSERVER = 1
' You simply uncomment the line above for the DBMS you want to use

Module General
   ' Listing 5-1
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = "Provider=SQLOLEDB;Data Source=USERMANPC;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
#ElseIf MSAccess Then
	' This connection string os for connecting to an Access mdb
   ' I'm not using any security, hence the blank User Id and password. I'm also
   ' Opening the mdb in shared mode. You must edit the path to your database file
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\DBPWVBNET\UserMan.mdb;User Id=;Password=;" & _
      "Mode=Share Deny None;"
   'Private Const PR_STR_CONNECTION_STRING As String = _
   '   "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\DBPWVBNET\UserMan.mdb;" & _
   '   "Mode=Share Deny None;"
#ElseIf Oracle Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
	Private Const PR_STR_CONNECTION_STRING as String  = _
		"Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#ElseIf DB2 Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Listing 5-2
   Public Sub OpenConnection()
      ' Declare connection object
      Dim cnnUserMan As OleDbConnection

      ' Instantiate the connection object
      cnnUserMan = New OleDbConnection()

      Try
         ' Set up connection string
         cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
         ' Open the connection
         cnnUserMan.Open()
      Catch objE As Exception
         ' Deal with exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 5-3
   Public Sub OpenConnectionUsingUDLFile()
      ' Declare connection object
      Dim cnnUserMan As OleDbConnection

      ' Instantiate the connection object
      cnnUserMan = New OleDbConnection()
      ' Set up connection string
      cnnUserMan.ConnectionString = "File Name=C:\DBPWVBNET\Chapter 05\USERMANPC.udl"

      ' Open the connection
      cnnUserMan.Open()
   End Sub

   ' Listing 5-7
   Public Sub DisableAutomaticConnectionPooling()
      Dim cnnUserMan As OleDbConnection

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING & ";OLE DB Services=-4")
      cnnUserMan.Open()
   End Sub

   ' Listing 5-8
   Public Sub ClearConnectionPool()
      ' Declare connection object
      Dim cnnUserMan As OleDbConnection

      ' Instantiate the connection object
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      ' Do your stuff
      ' ...

      ' Close connection and release pool
      cnnUserMan.Close()
      cnnUserMan.ReleaseObjectPool()
   End Sub

   ' Listing 5-14
   Public Sub BeginNonDefaultIsolationLevelTransaction()
      Dim cnnUserMan As OleDbConnection
      Dim traUserMan As OleDbTransaction

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)
   End Sub

   ' Listing 5-17
   Public Sub DetermineTransactionIsolationLevel()
      Dim cnnUserMan As OleDbConnection
      Dim traUserMan As OleDbTransaction
      Dim intIsolationLevel As Integer

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      ' Start transaction with non-default isolation level
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted)

      ' Return the isolation level as text
      MsgBox(traUserMan.IsolationLevel.ToString)
      ' Return the isolation level as an integer value
      intIsolationLevel = traUserMan.IsolationLevel
   End Sub

   ' Listing 5-18
   Public Sub NestTransactions()
      Dim cnnUserMan As OleDbConnection
      Dim traUser2 As OleDbTransaction
      Dim traUser3 As OleDbTransaction
      Dim traUser99 As OleDbTransaction
      Dim cmmDelete As New OleDbCommand()

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Initialize the command
      cmmDelete.Connection = cnnUserMan

      ' Start main transaction
      traUser99 = cnnUserMan.BeginTransaction()
      ' Delete User99
      cmmDelete.CommandText = "DELETE FROM tblUser WHERE LoginName='User99'"
      cmmDelete.Transaction = traUser99
      cmmDelete.ExecuteNonQuery()
      ' Begin nested transaction
      traUser3 = traUser99.Begin()
      ' Delete User3
      cmmDelete.CommandText = "DELETE FROM tblUser WHERE LoginName='User3'"
      cmmDelete.Transaction = traUser3
      cmmDelete.ExecuteNonQuery()
      ' Begin nested transaction
      traUser2 = traUser3.Begin()
      ' Delete User2
      cmmDelete.CommandText = "DELETE FROM tblUser WHERE LoginName='User2'"
      cmmDelete.Transaction = traUser2
      cmmDelete.ExecuteNonQuery()
      ' Roll back deletion of User2
      traUser2.Rollback()
      ' Commit all pending changes in main transaction
      traUser99.Commit()
   End Sub

   ' Listing 5-20
   Public Sub TraverseAllOleDbErrors()
      Dim cnnUserMan As OleDbConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Do your stuff...
         ' ...
      Catch objException As OleDbException
         ' This Catch block will handle all exceptions that 
         ' the OleDbDataAdapter cannot handle
         Dim objError As OleDbError

         For Each objError In objException.Errors
            MsgBox(objException.Message)
         Next
      Catch objException As Exception
         ' This Catch block will catch all exceptions that
         ' the OleDbDataAdapter can handle
         MsgBox(objException.Message)
      End Try
   End Sub

   ' Listing 5-21
   Public Sub CheckBeginTransactionMethodException()
      Dim cnnUserMan As OleDbConnection
      Dim traUserMan1, traUserMan2 As OleDbTransaction

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      Try
         ' Start parallel transactions
         traUserMan1 = cnnUserMan.BeginTransaction
         traUserMan2 = cnnUserMan.BeginTransaction
      Catch objException As InvalidOperationException
         ' Check if a BeginTransaction method threw the exception
         If objException.TargetSite.Name = "BeginTransaction" Then
            MsgBox("The BeginTransaction method threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-22
   Public Sub CheckConnectionStringPropertyException()
      Dim cnnUserMan As OleDbConnection

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()

      Try
         ' Set the connection string
         cnnUserMan.ConnectionString = PR_STR_CONNECTION_STRING
      Catch objException As InvalidOperationException
         ' Check if setting the ConnectionString threw the exception
         If objException.TargetSite.Name = "set_ConnectionString" Then
            MsgBox("The ConnectionString property threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-24
   Public Sub CheckChangeDatabaseMethodException()
      Dim cnnUserMan As OleDbConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         ' If the following line is commented out, the ChangeDatabase exception will be thrown
         'cnnUserMan.Open()
         ' Change database
         cnnUserMan.ChangeDatabase("master")
      Catch objException As InvalidOperationException
         ' Check if we tried to change database on an invalid connection
         If objException.TargetSite.Name = "CheckStateOpen" Then
            MsgBox("The ChangeDatabase method threw the exception!")
         End If
      End Try
   End Sub

   ' Listing 5-25
   Public Sub CheckOpenMethodException()
      Dim cnnUserMan As OleDbConnection

      Try
         ' Instantiate the connection
         cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
         ' Open the connection
         cnnUserMan.Open()
         ' Open the connection
         cnnUserMan.Open()
      Catch objException As InvalidOperationException
         ' Check if we tried to open an already open connection
         If objException.TargetSite.Name = "Open" Then
            MsgBox("The Open method threw the exception!")
         End If
      End Try
   End Sub
End Module