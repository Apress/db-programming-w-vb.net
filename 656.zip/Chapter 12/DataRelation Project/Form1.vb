Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnInstantiateDataRelationObject As System.Windows.Forms.Button
   Friend WithEvents btnBuildUserManDatabase As System.Windows.Forms.Button
   Friend WithEvents btnParentKeyConstraints As System.Windows.Forms.Button
   Friend WithEvents btnChildKeyConstraints As System.Windows.Forms.Button
   Friend WithEvents btnAddRowsToUserManDatabase As System.Windows.Forms.Button
   Friend WithEvents btnNavigateRelatedRows As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnInstantiateDataRelationObject = New System.Windows.Forms.Button()
      Me.btnBuildUserManDatabase = New System.Windows.Forms.Button()
      Me.btnParentKeyConstraints = New System.Windows.Forms.Button()
      Me.btnChildKeyConstraints = New System.Windows.Forms.Button()
      Me.btnAddRowsToUserManDatabase = New System.Windows.Forms.Button()
      Me.btnNavigateRelatedRows = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnInstantiateDataRelationObject
      '
      Me.btnInstantiateDataRelationObject.Location = New System.Drawing.Point(20, 18)
      Me.btnInstantiateDataRelationObject.Name = "btnInstantiateDataRelationObject"
      Me.btnInstantiateDataRelationObject.Size = New System.Drawing.Size(214, 23)
      Me.btnInstantiateDataRelationObject.TabIndex = 0
      Me.btnInstantiateDataRelationObject.Text = "Instantiate DataRelation Object"
      '
      'btnBuildUserManDatabase
      '
      Me.btnBuildUserManDatabase.Location = New System.Drawing.Point(20, 46)
      Me.btnBuildUserManDatabase.Name = "btnBuildUserManDatabase"
      Me.btnBuildUserManDatabase.Size = New System.Drawing.Size(214, 23)
      Me.btnBuildUserManDatabase.TabIndex = 1
      Me.btnBuildUserManDatabase.Text = "Build UserMan Database"
      '
      'btnParentKeyConstraints
      '
      Me.btnParentKeyConstraints.Location = New System.Drawing.Point(20, 74)
      Me.btnParentKeyConstraints.Name = "btnParentKeyConstraints"
      Me.btnParentKeyConstraints.Size = New System.Drawing.Size(214, 23)
      Me.btnParentKeyConstraints.TabIndex = 2
      Me.btnParentKeyConstraints.Text = "Parent Key Constraints"
      '
      'btnChildKeyConstraints
      '
      Me.btnChildKeyConstraints.Location = New System.Drawing.Point(20, 102)
      Me.btnChildKeyConstraints.Name = "btnChildKeyConstraints"
      Me.btnChildKeyConstraints.Size = New System.Drawing.Size(214, 23)
      Me.btnChildKeyConstraints.TabIndex = 3
      Me.btnChildKeyConstraints.Text = "Child Key Constraints"
      '
      'btnAddRowsToUserManDatabase
      '
      Me.btnAddRowsToUserManDatabase.Location = New System.Drawing.Point(20, 130)
      Me.btnAddRowsToUserManDatabase.Name = "btnAddRowsToUserManDatabase"
      Me.btnAddRowsToUserManDatabase.Size = New System.Drawing.Size(214, 23)
      Me.btnAddRowsToUserManDatabase.TabIndex = 4
      Me.btnAddRowsToUserManDatabase.Text = "Add Rows To UserMan Database"
      '
      'btnNavigateRelatedRows
      '
      Me.btnNavigateRelatedRows.Location = New System.Drawing.Point(20, 158)
      Me.btnNavigateRelatedRows.Name = "btnNavigateRelatedRows"
      Me.btnNavigateRelatedRows.Size = New System.Drawing.Size(214, 23)
      Me.btnNavigateRelatedRows.TabIndex = 5
      Me.btnNavigateRelatedRows.Text = "Navigate Related Rows"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(252, 195)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnNavigateRelatedRows, Me.btnAddRowsToUserManDatabase, Me.btnChildKeyConstraints, Me.btnParentKeyConstraints, Me.btnBuildUserManDatabase, Me.btnInstantiateDataRelationObject})
      Me.Name = "Form1"
      Me.Text = "DataRelation Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnInstantiateDataRelationObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataRelationObject.Click
      InstantiateDataRelation()
   End Sub

   Private Sub btnBuildUserManDatabase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuildUserManDatabase.Click
      BuildUserManDatabase()
   End Sub

   Private Sub btnParentKeyConstraints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnParentKeyConstraints.Click
      ParentKeyConstraints()
   End Sub

   Private Sub btnChildKeyConstraints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChildKeyConstraints.Click
      ChildKeyConstraints()
   End Sub

   Private Sub btnAddRowsToUserManDatabase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRowsToUserManDatabase.Click
      AddRowsToUserManDatabase()
   End Sub

   Private Sub btnNavigateRelatedRows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNavigateRelatedRows.Click
      NavigateRelatedRows()
   End Sub
End Class
