Imports System.Globalization

Module General
   ' Listing 12-1
   Public Sub InstantiateDataRelation()
      ' Declare parent and child columns for use in relationship
      Dim dtcParentColumn As New DataColumn("ParentColumn")
      Dim dtcChildColumn As New DataColumn("ChildColumn")
      ' Declare and initialize array of parent and child 
      ' columns for use in relationship
      Dim arrdtcParentColumn(1) As DataColumn
      Dim arrdtcChildColumn(1) As DataColumn

      arrdtcParentColumn(0) = New DataColumn("ParentColumn1")
      arrdtcParentColumn(1) = New DataColumn("ParentColumn2")
      arrdtcChildColumn(0) = New DataColumn("ChildColumn1")
      arrdtcChildColumn(1) = New DataColumn("ChildColumn2")

      ' This constructor will fail, unless you add the
      ' specified parent and child columns to a table
      Dim dtrParentColumnAndChildColumn As New _
         DataRelation("RelationName", dtcParentColumn, _
         dtcChildColumn)
      ' This constructor will fail, unless you add the
      ' specified parent and child columns to a table
      Dim dtrParentColumnAndChildColumnAndConstraints As New _
         DataRelation("RelationName", dtcParentColumn, _
         dtcChildColumn, False)

      ' This constructor will fail, unless you add the
      ' specified arrays of parent and child columns to a table
      Dim dtrParentColumnsAndChildColumns As New _
         DataRelation("RelationName", arrdtcParentColumn, _
         arrdtcChildColumn, False)
      ' This constructor will fail, unless you add the
      ' specified arrays of parent and child columns to a table
      Dim dtrParentColumnsAndChildColumnsAndConstraints As New _
         DataRelation("RelationName", arrdtcParentColumn, _
         arrdtcChildColumn, False)

      ' This constructor takes string values for all arguments
      ' except for the last argument, Nested. This argument is 
      ' used for indicating if this relation is used in connection
      ' with hierarchical data, like an XML document
      Dim dtrStringsAndNested As New _
         DataRelation("RelationName", "ParentTableName", _
         "ChildTableName", New String(0) {"PrimaryKeyColumn1"}, _
         New String(0) {"ForeignKeyColumn1"}, False)
   End Sub

   ' Listing 12-2
   Public Sub BuildUserManDatabase(Optional ByRef rdstUserMan As DataSet = Nothing)
      ' Declare and instantiate data set
      Dim dstUserMan As New DataSet("UserMan")
      ' Declare and instantiate tables in data set
      Dim dtbUser As New DataTable("tblUser")
      Dim dtbRights As New DataTable("tblRights")
      Dim dtbUserRights As New DataTable("tblUserRights")
      Dim dtbLog As New DataTable("tblLog")
      ' Declare table elements
      Dim dclUser, dclRights, dclUserRights, dclLog As DataColumn
      Dim arrdclUserPrimaryKey(), arrdclRightsPrimaryKey(), _
         arrdclUserRightsPrimaryKey(), arrdclLogPrimaryKey() _
         As DataColumn
      ' Declare table relations
      Dim dtrUser2Log, dtrUser2UserRights, _
         dtrRights2UserRights As DataRelation

      ' Set up data set for saving to XML
      dstUserMan.Namespace = "UserMan"
      dstUserMan.Locale = New CultureInfo("En-US", True)
      dstUserMan.Prefix = "Development"

      ' Create user table structure
      ' Create Id column
      dclUser = New DataColumn("Id", Type.GetType("System.Int32"), "", _
         MappingType.Element)
      ' Make the Id column an auto increment column, incrementing by 1 
      ' every time a new row is added to the table, with a seed of 1
      dclUser.AutoIncrement = True
      dclUser.AutoIncrementSeed = 1
      dclUser.AutoIncrementStep = 1
      ' Disallow null values in column
      dclUser.AllowDBNull = False
      ' Add Id column to user table structure
      dtbUser.Columns.Add(dclUser)
      ' Create single-column primary key
      ReDim arrdclUserPrimaryKey(0)
      ' Add Id column to PK array
      arrdclUserPrimaryKey(0) = dclUser
      ' Set primary key
      dtbUser.PrimaryKey = arrdclUserPrimaryKey

      ' Create ADName column
      dclUser = New DataColumn("ADName", Type.GetType("System.String"))
      dclUser.MaxLength = 100
      ' Add column to user table structure
      dtbUser.Columns.Add(dclUser)

      ' Create ADSID column
      dclUser = New DataColumn("ADSID", Type.GetType("System.String"))
      dclUser.MaxLength = 50
      ' Add column to user table structure
      dtbUser.Columns.Add(dclUser)

      ' Create FirstName column
      dclUser = New DataColumn("FirstName", Type.GetType("System.String"))
      dclUser.MaxLength = 50
      ' Add column to user table structure
      dtbUser.Columns.Add(dclUser)

      ' Create LastName column
      dclUser = New DataColumn("LastName", Type.GetType("System.String"))
      dclUser.MaxLength = 50
      ' Add column to user table structure
      dtbUser.Columns.Add(dclUser)

      ' Create LoginName column
      dclUser = New DataColumn("LoginName", Type.GetType("System.String"))
      ' Disallow null values in column
      dclUser.AllowDBNull = False
      ' Disallow duplicate values in column
      dclUser.Unique = True
      dclUser.MaxLength = 50
      ' Add column to user table structure
      dtbUser.Columns.Add(dclUser)

      ' Create Password column
      dclUser = New DataColumn("Password", Type.GetType("System.String"))
      ' Disallow null values in column
      dclUser.AllowDBNull = False
      dclUser.MaxLength = 50
      ' Add column to user table structure
      dtbUser.Columns.Add(dclUser)

      ' Add User table to dataset
      dstUserMan.Tables.Add(dtbUser)

      ' Create Rights table structure
      ' Create Id column
      dclRights = New DataColumn("Id", _
         Type.GetType("System.Int32"), "", MappingType.Element)
      ' Make the Id column an auto increment column, incrementing by 1 
      ' every time a new row is added to the table, with a seed of 1
      dclRights.AutoIncrement = True
      dclRights.AutoIncrementSeed = 1
      dclRights.AutoIncrementStep = 1
      ' Disallow null values in column
      dclRights.AllowDBNull = False
      ' Add Id column to Rights table structure
      dtbRights.Columns.Add(dclRights)
      ' Create single-column primary key
      ReDim arrdclRightsPrimaryKey(0)
      ' Add Id column to PK array
      arrdclRightsPrimaryKey(0) = dclRights
      ' Set primary key
      dtbRights.PrimaryKey = arrdclRightsPrimaryKey

      ' Create Name column
      dclRights = New DataColumn("Name", Type.GetType("System.String"))
      dclUser.MaxLength = 50
      ' Add column to Rights table structure
      dtbRights.Columns.Add(dclRights)

      ' Create Description column
      dclRights = New DataColumn("Description", Type.GetType("System.String"))
      dclUser.MaxLength = 255
      ' Add column to Rights table structure
      dtbRights.Columns.Add(dclRights)

      ' Add Rights table to dataset
      dstUserMan.Tables.Add(dtbRights)

      ' Create Log table structure
      ' Create Id column
      dclLog = New DataColumn("Id", _
         Type.GetType("System.Int32"), "", MappingType.Element)
      ' Make the Id column an auto increment column, incrementing by 1 
      ' every time a new row is added to the table, with a seed of 1
      dclLog.AutoIncrement = True
      dclLog.AutoIncrementSeed = 1
      dclLog.AutoIncrementStep = 1
      ' Disallow null values in column
      dclLog.AllowDBNull = False
      ' Add Id column to Log table structure
      dtbLog.Columns.Add(dclLog)
      ' Create single-column primary key
      ReDim arrdclLogPrimaryKey(0)
      ' Add Id column to PK array
      arrdclLogPrimaryKey(0) = dclLog
      ' Set primary key
      dtbLog.PrimaryKey = arrdclLogPrimaryKey

      ' Create Logged column
      dclLog = New DataColumn("Logged", Type.GetType("System.DateTime"))
      ' Add column to Log table structure
      dtbLog.Columns.Add(dclLog)

      ' Create Description column
      dclLog = New DataColumn("Description", Type.GetType("System.String"))
      dclLog.MaxLength = 255
      ' Add column to Log table structure
      dtbLog.Columns.Add(dclLog)

      ' Create UserId column
      dclLog = New DataColumn("UserId", Type.GetType("System.Int32"), "", _
         MappingType.Element)
      ' Disallow null values in column
      dclLog.AllowDBNull = False
      ' Add UserId column to Log table structure
      dtbLog.Columns.Add(dclLog)

      ' Add Log table to dataset
      dstUserMan.Tables.Add(dtbLog)

      ' Create UserRights table structure
      ' Create UserId column
      dclUserRights = New DataColumn("UserId", _
         Type.GetType("System.Int32"), "", MappingType.Element)
      ' Disallow null values in column
      dclUserRights.AllowDBNull = False
      ' Add Id column to UserRights table structure
      dtbUserRights.Columns.Add(dclUserRights)

      ' Create composite primary key
      ReDim arrdclUserRightsPrimaryKey(1)
      ' Add UserId column to PK array
      arrdclUserRightsPrimaryKey(0) = dclUserRights

      ' Create RightsId column
      dclUserRights = New DataColumn("RightsId", _
         Type.GetType("System.Int32"), "", MappingType.Element)
      ' Disallow null values in column
      dclUserRights.AllowDBNull = False
      ' Add RightsId column to UserRights table structure
      dtbUserRights.Columns.Add(dclUserRights)

      ' Add RightsId column to PK array
      arrdclUserRightsPrimaryKey(1) = dclUserRights
      ' Set primary key
      dtbUserRights.PrimaryKey = arrdclUserRightsPrimaryKey

      ' Add UserRights table to dataset
      dstUserMan.Tables.Add(dtbUserRights)

      ' Create table relations
      dtrUser2Log = New DataRelation("User2Log", dtbUser.Columns("Id"), _
         dtbLog.Columns("UserId"), True)
      dtrUser2UserRights = New DataRelation("User2UserRights", _
         dtbUser.Columns("Id"), dtbUserRights.Columns("UserId"), True)
      dtrRights2UserRights = New DataRelation("Rights2UserRight", _
         dtbRights.Columns("Id"), dtbUserRights.Columns("RightsId"), True)
      ' Add relationships to DataSet
      dstUserMan.Relations.Add(dtrUser2Log)
      dstUserMan.Relations.Add(dtrUser2UserRights)
      dstUserMan.Relations.Add(dtrRights2UserRights)

      ' Write data set schema to XML file
      dstUserMan.WriteXmlSchema("C:\\UserMan.xml")
      ' Return new DataSet
      rdstUserMan = dstUserMan
   End Sub

   ' Listing 12-3
   Public Sub ParentKeyConstraints()
      ' Declare and instantiate data set
      Dim dstUserMan As New DataSet("UserMan")
      ' Declare and instantiate tables in data set
      Dim dtbUser As New DataTable("tblUser")
      Dim dtbLog As New DataTable("tblLog")
      ' Declare table elements
      Dim dclUser, dclLog As DataColumn
      Dim arrdclUserPrimaryKey(), arrdclLogPrimaryKey() _
         As DataColumn
      ' Declare table relations
      Dim dtrUser2Log As DataRelation

      ' Create user table structure
      ' Create Id column
      dclUser = New DataColumn("Id", Type.GetType("System.Int32"), "", _
         MappingType.Element)
      ' Make the Id column an auto increment column, incrementing by 1 
      ' every time a new row is added to the table, with a seed of 1
      dclUser.AutoIncrement = True
      dclUser.AutoIncrementSeed = 1
      dclUser.AutoIncrementStep = 1
      ' Disallow null values in column
      dclUser.AllowDBNull = False
      ' Add Id column to user table structure
      dtbUser.Columns.Add(dclUser)
      ' Create single-column primary key
      ReDim arrdclUserPrimaryKey(0)
      ' Add Id column to PK array
      arrdclUserPrimaryKey(0) = dclUser
      ' Set primary key
      dtbUser.PrimaryKey = arrdclUserPrimaryKey

      ' Add User table to dataset
      dstUserMan.Tables.Add(dtbUser)

      ' Create Log table structure
      ' Create Id column
      dclLog = New DataColumn("Id", _
         Type.GetType("System.Int32"), "", MappingType.Element)
      ' Make the Id column an auto increment column, incrementing by 1 
      ' every time a new row is added to the table, with a seed of 1
      dclLog.AutoIncrement = True
      dclLog.AutoIncrementSeed = 1
      dclLog.AutoIncrementStep = 1
      ' Disallow null values in column
      dclLog.AllowDBNull = False
      ' Add Id column to Log table structure
      dtbLog.Columns.Add(dclLog)
      ' Create single-column primary key
      ReDim arrdclLogPrimaryKey(0)
      ' Add Id column to PK array
      arrdclLogPrimaryKey(0) = dclLog
      ' Set primary key
      dtbLog.PrimaryKey = arrdclLogPrimaryKey

      ' Create UserId column
      dclLog = New DataColumn("UserId", Type.GetType("System.Int32"), "", _
         MappingType.Element)
      ' Disallow null values in column
      dclLog.AllowDBNull = False
      ' Add UserId column to Log table structure
      dtbLog.Columns.Add(dclLog)

      ' Add Log table to dataset
      dstUserMan.Tables.Add(dtbLog)

      ' Create table relations
      dtrUser2Log = New DataRelation("User2Log", dtbUser.Columns("Id"), _
         dtbLog.Columns("UserId"), True)
      ' This next line of code  will throw an exception, because 
      ' the propertiy hasn't been set yet
      'MsgBox(dtrUser2Log.ParentKeyConstraint.ConstraintName.ToString)

      ' Add relationships to DataSet
      dstUserMan.Relations.Add(dtrUser2Log)
      ' Now, after adding the DataRelation to the DataSet, you can
      ' read the ParentKeyConstraint property
      MsgBox(dtrUser2Log.ParentKeyConstraint.ConstraintName.ToString)
      ' Check if the parent key constraint has been set on a primary key
      MsgBox(dtrUser2Log.ParentKeyConstraint.IsPrimaryKey.ToString)
   End Sub

   ' Listing 12-3
   Public Sub ChildKeyConstraints()
      ' Declare and instantiate data set
      Dim dstUserMan As New DataSet("UserMan")
      ' Declare and instantiate tables in data set
      Dim dtbUser As New DataTable("tblUser")
      Dim dtbLog As New DataTable("tblLog")
      ' Declare table elements
      Dim dclUser, dclLog As DataColumn
      Dim arrdclUserPrimaryKey(), arrdclLogPrimaryKey() _
         As DataColumn
      ' Declare table relations
      Dim dtrUser2Log As DataRelation
      ' Declare rows
      Dim drwUser, drwLog As DataRow

      ' Create user table structure
      ' Create Id column
      dclUser = New DataColumn("Id", Type.GetType("System.Int32"), "", _
         MappingType.Element)
      ' Make the Id column an auto increment column, incrementing by 1 
      ' every time a new row is added to the table, with a seed of 1
      dclUser.AutoIncrement = True
      dclUser.AutoIncrementSeed = 1
      dclUser.AutoIncrementStep = 1
      ' Disallow null values in column
      dclUser.AllowDBNull = False
      ' Add Id column to user table structure
      dtbUser.Columns.Add(dclUser)
      ' Create single-column primary key
      ReDim arrdclUserPrimaryKey(0)
      ' Add Id column to PK array
      arrdclUserPrimaryKey(0) = dclUser
      ' Set primary key
      dtbUser.PrimaryKey = arrdclUserPrimaryKey

      ' Add User table to dataset
      dstUserMan.Tables.Add(dtbUser)

      ' Create Log table structure
      ' Create Id column
      dclLog = New DataColumn("Id", _
         Type.GetType("System.Int32"), "", MappingType.Element)
      ' Make the Id column an auto increment column, incrementing by 1 
      ' every time a new row is added to the table, with a seed of 1
      dclLog.AutoIncrement = True
      dclLog.AutoIncrementSeed = 1
      dclLog.AutoIncrementStep = 1
      ' Disallow null values in column
      dclLog.AllowDBNull = False
      ' Add Id column to Log table structure
      dtbLog.Columns.Add(dclLog)
      ' Create single-column primary key
      ReDim arrdclLogPrimaryKey(0)
      ' Add Id column to PK array
      arrdclLogPrimaryKey(0) = dclLog
      ' Set primary key
      dtbLog.PrimaryKey = arrdclLogPrimaryKey

      ' Create UserId column
      dclLog = New DataColumn("UserId", Type.GetType("System.Int32"), "", _
         MappingType.Element)
      ' Disallow null values in column
      dclLog.AllowDBNull = False
      ' Add UserId column to Log table structure
      dtbLog.Columns.Add(dclLog)

      ' Add Log table to dataset
      dstUserMan.Tables.Add(dtbLog)

      ' Create table relations
      dtrUser2Log = New DataRelation("User2Log", dtbUser.Columns("Id"), _
         dtbLog.Columns("UserId"), True)
      Try
         ' This next line of code  will throw an exception, because 
         ' the ChildKeyConstraint property hasn't been set yet
         MsgBox(dtrUser2Log.ChildKeyConstraint.ConstraintName.ToString)
      Catch objE As NullReferenceException
         MsgBox(obje.Message, MsgBoxStyle.Information, _
            "Accessing ChildConstraint property")
      End Try

      ' Add relationships to DataSet
      dstUserMan.Relations.Add(dtrUser2Log)
      ' Now, after adding the DataRelation to the DataSet, you can
      ' read the ChildKeyConstraint property
      MsgBox("ChildKeyConstraint Name = " & _
         dtrUser2Log.ChildKeyConstraint.ConstraintName.ToString)
      ' Display the default action to take in the relation,
      ' for updated and deleted rows in the parent table
      MsgBox("ChildKeyConstraint AcceptRejectRule = " & _
         dtrUser2Log.ChildKeyConstraint.AcceptRejectRule.ToString, _
         MsgBoxStyle.Information, "Default Value")
      ' Make sure updated and deleted rows in the parent table are cascaded
      ' to the child table
      dtrUser2Log.ChildKeyConstraint.AcceptRejectRule = AcceptRejectRule.Cascade
      ' Display the explicit action to take in the relation,
      ' for updated and deleted rows in the parent table
      MsgBox("ChildKeyConstraint AcceptRejectRule = " & _
         dtrUser2Log.ChildKeyConstraint.AcceptRejectRule.ToString, _
         MsgBoxStyle.Information, "Explicit Value")
      ' Display the default action to take in the child table,
      ' for for updated and deleted rows in the parent table
      MsgBox("ChildKeyConstraint DeleteRule = " & _
         dtrUser2Log.ChildKeyConstraint.DeleteRule.ToString & vbCrLf & _
         "ChildKeyConstraint UpdateRule = " & _
         dtrUser2Log.ChildKeyConstraint.UpdateRule.ToString, _
         MsgBoxStyle.Information, "Default Value")
      ' Make sure updated rows in the parent table are changed accordingly
      ' in the child table, and rows related to deleted rows, are 
      ' set to null in the child table
      dtrUser2Log.ChildKeyConstraint.UpdateRule = Rule.Cascade
      dtrUser2Log.ChildKeyConstraint.DeleteRule = Rule.SetNull
      ' Display the explicit action to take in the child table,
      ' for deleted rows in the parent table
      MsgBox("ChildKeyConstraint DeleteRule = " & _
         dtrUser2Log.ChildKeyConstraint.DeleteRule.ToString & vbCrLf & _
         "ChildKeyConstraint UpdateRule = " & _
         dtrUser2Log.ChildKeyConstraint.UpdateRule.ToString, _
         MsgBoxStyle.Information, "Explicit Value")
      ' Add data to the parent table
      drwUser = dtbUser.NewRow()
      dtbUser.Rows.Add(drwUser)
      ' Display number of rows in parent table
      MsgBox("Rows #" & dtbUser.Rows.Count.ToString, _
         MsgBoxStyle.Information, "Parent Table")
      ' Add related data to the child table
      drwLog = dtbLog.NewRow()
      ' I need to specify the id of an existing row
      ' in the parent table or an exception is thrown,
      ' because of the ForeignKeyConstraint
      drwLog("UserId") = drwUser("Id")
      dtbLog.Rows.Add(drwLog)
      ' Display number of rows in child table
      MsgBox("Rows #" & dtbLog.Rows.Count.ToString, _
         MsgBoxStyle.Information, "Child Table")
      Try
         ' Delete the row from the parent table
         ' This will throw an exception, because the ForeignKeyConstraint
         ' specifies that the value of foreign key column should be set 
         ' to null
         dtbUser.Rows.Remove(drwUser)
      Catch objE As NoNullAllowedException
         ' Allow null values in the UserId column
         ' Disallow null values in column
         dtbLog.Columns("UserId").AllowDBNull = True
         ' Delete row
         dtbUser.Rows.Remove(drwUser)
      End Try

      ' Check if the UserId column of the related row in the child
      ' table has been set to null
      If dtbLog.Rows(0)("UserId") Is DBNull.Value Then
         MsgBox("The UserId column of related row in child table is null.")
      End If
   End Sub

   ' Listing 12-5
   Public Sub AddRowsToUserManDatabase(Optional ByRef rdstUserMan As DataSet = Nothing)
      Dim dstUserMan As DataSet
      Dim drwUser, drwUserRights, drwRights As DataRow

      ' Build in-memory database
      BuildUserManDatabase(dstUserMan)
      ' Add rows to user table
      dstUserMan.Tables("tblUser").Rows.Add(New Object(6) _
         {Nothing, Nothing, Nothing, "John", "Doe", "UserMan", "userman"})
      dstUserMan.Tables("tblUser").Rows.Add(New Object(6) _
         {Nothing, Nothing, Nothing, Nothing, Nothing, "User1", "password"})
      dstUserMan.Tables("tblUser").Rows.Add(New Object(6) _
         {Nothing, Nothing, Nothing, Nothing, Nothing, "User2", "password"})
      dstUserMan.Tables("tblUser").Rows.Add(New Object(6) _
         {Nothing, Nothing, Nothing, Nothing, Nothing, "User3", "password"})
      dstUserMan.Tables("tblUser").Rows.Add(New Object(6) _
         {Nothing, Nothing, Nothing, Nothing, Nothing, "User99", "password"})
      ' Add rows to rights table
      dstUserMan.Tables("tblRights").Rows.Add(New Object(2) _
         {Nothing, "AddUser", _
         "Gives the user the right to add users to the database"})
      dstUserMan.Tables("tblRights").Rows.Add(New Object(2) _
         {Nothing, "DeleteUser", _
         "Gives the user the right to delete users from the database"})
      dstUserMan.Tables("tblRights").Rows.Add(New Object(2) _
         {Nothing, "ClearLog", _
         "Gives the user the right to clear the log"})
      ' Add rows to user rights table
      dstUserMan.Tables("tblUserRights").Rows.Add(New Object(1) {1, 1})
      dstUserMan.Tables("tblUserRights").Rows.Add(New Object(1) {1, 2})
      dstUserMan.Tables("tblUserRights").Rows.Add(New Object(1) {1, 3})

      ' Return new DataSet
      rdstUserMan = dstUserMan
   End Sub

   ' Listing 12-6
   Public Sub NavigateRelatedRows()
      Const STR_PARENT_TABLE_NAME As String = "tblUser"

      Dim dstUserMan As DataSet
      Dim dtrUser As DataRelation
      Dim arrdclParent(), dclParent As DataColumn
      Dim arrdclChild(), dclChild As DataColumn
      Dim drwParent, drwChild As DataRow
      Dim arrdrwParent, arrdrwChild() As DataRow
      Dim strRelated As String

      ' Retrieve populated in-memory database
      AddRowsToUserManDatabase(dstUserMan)
      ' Locate all relations that the parent user table is part of
      For Each dtrUser In dstUserMan.Relations
         If dtrUser.ParentTable.TableName = STR_PARENT_TABLE_NAME Then
            ' Build related data string
            strRelated += "Child table: " & _
               dtrUser.ChildTable.TableName & vbCrLf & vbCrLf
            ' Lookup parent key
            strRelated += "Parent Key = "
            ' Find all parent key columns
            For Each dclParent In dtrUser.ParentColumns()
               strRelated += dclParent.ColumnName & ", "
            Next

            ' Remove last separating comma and add hyphen
            strRelated = strRelated.Remove(strRelated.Length - 2, 2) & " -- "

            ' Lookup child key
            strRelated += "Child Key = "
            ' Find all child key columns
            For Each dclChild In dtrUser.ChildColumns()
               strRelated += dclChild.ColumnName & ", "
            Next

            ' Remove last separating comma and add CR
            strRelated = strRelated.Remove(strRelated.Length - 2, 2) & _
               vbCrLf & vbCrLf

            ' Find related rows in child table
            For Each drwParent In dstUserMan.Tables(STR_PARENT_TABLE_NAME).Rows
               ' Lookup related columns
               arrdrwChild = drwParent.GetChildRows(dtrUser)
               ' Check if any child rows exist
               If arrdrwChild.GetLength(0) > -1 Then
                  ' Display parent key column values
                  strRelated += vbTab & "Parent Key Column Value(s) : "
                  For Each dclParent In dtrUser.ParentColumns()
                     strRelated += drwParent(dclParent.ColumnName).ToString & ", "
                  Next

                  ' Remove last separating comma and add CR
                  strRelated = strRelated.Remove(strRelated.Length - 2, 2) & vbCrLf

                  ' Display child key column values
                  strRelated += vbTab & "Child Key Column Value(s) : "
                  For Each drwChild In drwParent.GetChildRows(dtrUser)
                     For Each dclChild In dtrUser.ChildColumns()
                        strRelated += drwChild(dclChild.ColumnName).ToString & ", "
                     Next
                  Next

                  ' Remove last separating comma and add CR
                  strRelated = strRelated.Remove(strRelated.Length - 2, 2) & vbCrLf
               End If

               strRelated += vbCrLf
            Next
         End If
      Next

      ' Display related data
      MsgBox(strRelated, MsgBoxStyle.Information, STR_PARENT_TABLE_NAME & _
         " Relationships")
   End Sub
End Module