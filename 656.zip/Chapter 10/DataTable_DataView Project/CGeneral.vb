Option Strict On
Imports System.Data.SqlClient

Public Class CGeneral
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   ' Listing 10-8-1
   Private Shared Sub OnColumnChanging(ByVal sender As Object, _
      ByVal e As DataColumnChangeEventArgs)
      ' Display a message showing some of the Column properties
      MsgBox("Column Properties:" & vbCrLf & vbCrLf & _
         "ColumnName: " & e.Column.ColumnName & vbCrLf & _
         "DataType: " & e.Column.DataType.ToString() & vbCrLf & _
         "CommandType: " & e.Column.Table.TableName & vbCrLf & _
         "Original Value: " & e.Row(e.Column.ColumnName, _
         DataRowVersion.Original).ToString() & vbCrLf & _
         "Proposed Value: " & e.ProposedValue.ToString(), _
         MsgBoxStyle.Information, "ColumnChanging")
   End Sub

   ' Listing 10-8-2
   Private Shared Sub OnColumnChanged(ByVal sender As Object, _
      ByVal e As DataColumnChangeEventArgs)
      ' Display a message showing some of the Column properties
      MsgBox("Column Properties:" & vbCrLf & vbCrLf & _
         "ColumnName: " & e.Column.ColumnName & vbCrLf & _
         "DataType: " & e.Column.DataType.ToString() & vbCrLf & _
         "CommandType: " & e.Column.Table.TableName & vbCrLf & _
         "Original Value: " & e.Row(e.Column.ColumnName, _
         DataRowVersion.Original).ToString() & vbCrLf & _
         "Proposed Value: " & e.ProposedValue.ToString(), _
         MsgBoxStyle.Information, "ColumnChanged")
   End Sub

   ' Listing 10-8-3
   Public Shared Sub TriggerColumnChangeEvents()
      Dim dadUserMan As SqlDataAdapter
      Dim dtbUser As New DataTable("tblUser")
      ' Declare and instantiate data adapter
      dadUserMan = New SqlDataAdapter("SELECT * FROM tblUser", PR_STR_CONNECTION_STRING)
      ' Set up event handlers
      AddHandler dtbUser.ColumnChanging, AddressOf OnColumnChanging
      AddHandler dtbUser.ColumnChanged, AddressOf OnColumnChanged

      ' Populate the data table
      dadUserMan.Fill(dtbUser)
      ' Modify first row, this triggers the Column Change events
      dtbUser.Rows(0)("FirstName") = "Tom"
   End Sub

   ' Listing 10-9-1
   Private Shared Sub OnRowChanging(ByVal sender As Object, _
      ByVal e As DataRowChangeEventArgs)
      ' Display a message showing some of the Row properties
      MsgBox("Row Properties:" & vbCrLf & vbCrLf & _
         "RowState: " & e.Row.RowState.ToString() & vbCrLf & _
         "Table: " & e.Row.Table.TableName & vbCrLf & _
         "Action: " & e.Action.ToString(), _
         MsgBoxStyle.Information, "RowChanging")
   End Sub

   ' Listing 10-9-2
   Private Shared Sub OnRowChanged(ByVal sender As Object, _
      ByVal e As DataRowChangeEventArgs)
      ' Display a message showing some of the Row properties
      MsgBox("Row Properties:" & vbCrLf & vbCrLf & _
         "RowState: " & e.Row.RowState.ToString() & vbCrLf & _
         "Table: " & e.Row.Table.TableName & vbCrLf & _
         "Action: " & e.Action.ToString(), _
         MsgBoxStyle.Information, "RowChanged")
   End Sub

   ' Listing 10-9-3
   Public Shared Sub TriggerRowChangeEvents()
      Dim dtbUser As New DataTable("tblUser")
      ' Declare and instantiate data adapter
      Dim dadUserMan As New SqlDataAdapter("SELECT * FROM tblUser", _
         PR_STR_CONNECTION_STRING)
      ' Set up event handlers
      AddHandler dtbUser.RowChanging, AddressOf OnRowChanging
      AddHandler dtbUser.RowChanged, AddressOf OnRowChanged

      ' Populate the data table
      dadUserMan.Fill(dtbUser)
      ' Modify first row, this triggers the Column Change events
      dtbUser.Rows(0)("FirstName") = "Tom"
   End Sub

   ' Listing 10-10-1
   Private Shared Sub OnRowDeleting(ByVal sender As Object, _
      ByVal e As DataRowChangeEventArgs)
      ' Display a message showing some of the Row properties
      MsgBox("Row Properties:" & vbCrLf & vbCrLf & _
         "RowState: " & e.Row.RowState.ToString() & vbCrLf & _
         "Table: " & e.Row.Table.ToString() & vbCrLf & _
         "Action: " & e.Action.ToString(), _
         MsgBoxStyle.Information, "RowDeleting")
   End Sub

   ' Listing 10-10-2
   Private Shared Sub OnRowDeleted(ByVal sender As Object, _
      ByVal e As DataRowChangeEventArgs)
      ' Display a message showing some of the Row properties
      MsgBox("Row Properties:" & vbCrLf & vbCrLf & _
         "RowState: " & e.Row.RowState.ToString() & vbCrLf & _
         "Table: " & e.Row.Table.ToString() & vbCrLf & _
         "Action: " & e.Action.ToString(), _
         MsgBoxStyle.Information, "RowDeleted")
   End Sub

   ' Listing 10-10-3
   Public Shared Sub TriggerRowDeleteEvents()
      Dim dtbUser As New DataTable("tblUser")
      ' Declare and instantiate data adapter
      Dim dadUserMan As New SqlDataAdapter("SELECT * FROM tblUser", _
         PR_STR_CONNECTION_STRING)
      ' Set up event handlers
      AddHandler dtbUser.RowDeleting, AddressOf OnRowDeleting
      AddHandler dtbUser.RowDeleted, AddressOf OnRowDeleted

      ' Populate the data table
      dadUserMan.Fill(dtbUser)
      ' Delete second row, this triggers the row delete events
      dtbUser.Rows(1).Delete()
   End Sub

   ' Listing 10-11-1
   Protected Shared Sub OnListChanged(ByVal sender As Object, _
      ByVal args As System.ComponentModel.ListChangedEventArgs)
      ' Display a message showing some of the List properties
      MsgBox("List Properties:" & vbCrLf & vbCrLf & _
         "ListChangedType: " & args.ListChangedType.ToString() & vbCrLf & _
         "OldIndex: " & args.OldIndex.ToString() & vbCrLf & _
         "NewIndex: " & args.NewIndex.ToString(), _
         MsgBoxStyle.Information, "ListChanged")
   End Sub

   ' Listing 10-11-2
   Public Shared Sub TriggerListChangeEvent()
      Dim dtbUser As New DataTable("tblUser")
      ' Declare and instantiate data adapter
      Dim dadUserMan As New SqlDataAdapter("SELECT * FROM tblUser", _
         PR_STR_CONNECTION_STRING)

      ' Populate the data table
      dadUserMan.Fill(dtbUser)
      ' Declare and instantiate data view
      Dim dvwUser As New DataView(dtbUser)
      ' Set up event handler
      AddHandler dvwUser.ListChanged, New _
         System.ComponentModel.ListChangedEventHandler(AddressOf OnListChanged)
      ' Trigger list change event by adding new item/row
      dvwUser.AddNew()
   End Sub
End Class