Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnInstantiateDataTable As System.Windows.Forms.Button
   Friend WithEvents btnPopulateDataTable As System.Windows.Forms.Button
   Friend WithEvents btnSearchDataTable As System.Windows.Forms.Button
   Friend WithEvents btnCopyRowsInDataTable As System.Windows.Forms.Button
   Friend WithEvents btnBuildDataTable As System.Windows.Forms.Button
   Friend WithEvents btnTestCultureSettings As System.Windows.Forms.Button
   Friend WithEvents btnTriggerColumnChangeEvents As System.Windows.Forms.Button
   Friend WithEvents btnTriggerRowChangeEvents As System.Windows.Forms.Button
   Friend WithEvents btnTriggerRowDeleteEvents As System.Windows.Forms.Button
   Friend WithEvents btnTriggerListChangeEvent As System.Windows.Forms.Button
   Friend WithEvents btnInstantiateDataView As System.Windows.Forms.Button
   Friend WithEvents btnSearchDataView As System.Windows.Forms.Button
   Friend WithEvents btnSortDataView As System.Windows.Forms.Button
   Friend WithEvents btnManipulateDataViewData As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnInstantiateDataTable = New System.Windows.Forms.Button()
      Me.btnPopulateDataTable = New System.Windows.Forms.Button()
      Me.btnSearchDataTable = New System.Windows.Forms.Button()
      Me.btnCopyRowsInDataTable = New System.Windows.Forms.Button()
      Me.btnBuildDataTable = New System.Windows.Forms.Button()
      Me.btnTestCultureSettings = New System.Windows.Forms.Button()
      Me.btnTriggerColumnChangeEvents = New System.Windows.Forms.Button()
      Me.btnTriggerRowChangeEvents = New System.Windows.Forms.Button()
      Me.btnTriggerRowDeleteEvents = New System.Windows.Forms.Button()
      Me.btnTriggerListChangeEvent = New System.Windows.Forms.Button()
      Me.btnInstantiateDataView = New System.Windows.Forms.Button()
      Me.btnSearchDataView = New System.Windows.Forms.Button()
      Me.btnSortDataView = New System.Windows.Forms.Button()
      Me.btnManipulateDataViewData = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnInstantiateDataTable
      '
      Me.btnInstantiateDataTable.Location = New System.Drawing.Point(8, 14)
      Me.btnInstantiateDataTable.Name = "btnInstantiateDataTable"
      Me.btnInstantiateDataTable.Size = New System.Drawing.Size(267, 23)
      Me.btnInstantiateDataTable.TabIndex = 0
      Me.btnInstantiateDataTable.Text = "Instantiate DataTable"
      '
      'btnPopulateDataTable
      '
      Me.btnPopulateDataTable.Location = New System.Drawing.Point(8, 98)
      Me.btnPopulateDataTable.Name = "btnPopulateDataTable"
      Me.btnPopulateDataTable.Size = New System.Drawing.Size(267, 23)
      Me.btnPopulateDataTable.TabIndex = 3
      Me.btnPopulateDataTable.Text = "Populate DataTable"
      '
      'btnSearchDataTable
      '
      Me.btnSearchDataTable.Location = New System.Drawing.Point(8, 126)
      Me.btnSearchDataTable.Name = "btnSearchDataTable"
      Me.btnSearchDataTable.Size = New System.Drawing.Size(267, 23)
      Me.btnSearchDataTable.TabIndex = 4
      Me.btnSearchDataTable.Text = "Search DataTable"
      '
      'btnCopyRowsInDataTable
      '
      Me.btnCopyRowsInDataTable.Location = New System.Drawing.Point(8, 154)
      Me.btnCopyRowsInDataTable.Name = "btnCopyRowsInDataTable"
      Me.btnCopyRowsInDataTable.Size = New System.Drawing.Size(267, 23)
      Me.btnCopyRowsInDataTable.TabIndex = 5
      Me.btnCopyRowsInDataTable.Text = "Copy Rows In DataTable"
      '
      'btnBuildDataTable
      '
      Me.btnBuildDataTable.Location = New System.Drawing.Point(8, 42)
      Me.btnBuildDataTable.Name = "btnBuildDataTable"
      Me.btnBuildDataTable.Size = New System.Drawing.Size(267, 23)
      Me.btnBuildDataTable.TabIndex = 1
      Me.btnBuildDataTable.Text = "Build DataTable"
      '
      'btnTestCultureSettings
      '
      Me.btnTestCultureSettings.Location = New System.Drawing.Point(8, 70)
      Me.btnTestCultureSettings.Name = "btnTestCultureSettings"
      Me.btnTestCultureSettings.Size = New System.Drawing.Size(267, 23)
      Me.btnTestCultureSettings.TabIndex = 2
      Me.btnTestCultureSettings.Text = "Test Culture Settings"
      '
      'btnTriggerColumnChangeEvents
      '
      Me.btnTriggerColumnChangeEvents.Location = New System.Drawing.Point(8, 182)
      Me.btnTriggerColumnChangeEvents.Name = "btnTriggerColumnChangeEvents"
      Me.btnTriggerColumnChangeEvents.Size = New System.Drawing.Size(267, 23)
      Me.btnTriggerColumnChangeEvents.TabIndex = 6
      Me.btnTriggerColumnChangeEvents.Text = "Trigger Column Change Events"
      '
      'btnTriggerRowChangeEvents
      '
      Me.btnTriggerRowChangeEvents.Location = New System.Drawing.Point(8, 210)
      Me.btnTriggerRowChangeEvents.Name = "btnTriggerRowChangeEvents"
      Me.btnTriggerRowChangeEvents.Size = New System.Drawing.Size(267, 23)
      Me.btnTriggerRowChangeEvents.TabIndex = 7
      Me.btnTriggerRowChangeEvents.Text = "Trigger Row Change Events"
      '
      'btnTriggerRowDeleteEvents
      '
      Me.btnTriggerRowDeleteEvents.Location = New System.Drawing.Point(8, 238)
      Me.btnTriggerRowDeleteEvents.Name = "btnTriggerRowDeleteEvents"
      Me.btnTriggerRowDeleteEvents.Size = New System.Drawing.Size(267, 23)
      Me.btnTriggerRowDeleteEvents.TabIndex = 8
      Me.btnTriggerRowDeleteEvents.Text = "Trigger Row Delete Events"
      '
      'btnTriggerListChangeEvent
      '
      Me.btnTriggerListChangeEvent.Location = New System.Drawing.Point(8, 266)
      Me.btnTriggerListChangeEvent.Name = "btnTriggerListChangeEvent"
      Me.btnTriggerListChangeEvent.Size = New System.Drawing.Size(267, 23)
      Me.btnTriggerListChangeEvent.TabIndex = 9
      Me.btnTriggerListChangeEvent.Text = "Trigger List Change Event"
      '
      'btnInstantiateDataView
      '
      Me.btnInstantiateDataView.Location = New System.Drawing.Point(8, 294)
      Me.btnInstantiateDataView.Name = "btnInstantiateDataView"
      Me.btnInstantiateDataView.Size = New System.Drawing.Size(267, 23)
      Me.btnInstantiateDataView.TabIndex = 10
      Me.btnInstantiateDataView.Text = "Instantiate DataView"
      '
      'btnSearchDataView
      '
      Me.btnSearchDataView.Location = New System.Drawing.Point(8, 322)
      Me.btnSearchDataView.Name = "btnSearchDataView"
      Me.btnSearchDataView.Size = New System.Drawing.Size(267, 23)
      Me.btnSearchDataView.TabIndex = 11
      Me.btnSearchDataView.Text = "Search DataView"
      '
      'btnSortDataView
      '
      Me.btnSortDataView.Location = New System.Drawing.Point(8, 350)
      Me.btnSortDataView.Name = "btnSortDataView"
      Me.btnSortDataView.Size = New System.Drawing.Size(267, 23)
      Me.btnSortDataView.TabIndex = 12
      Me.btnSortDataView.Text = "Sort DataView"
      '
      'btnManipulateDataViewData
      '
      Me.btnManipulateDataViewData.Location = New System.Drawing.Point(8, 378)
      Me.btnManipulateDataViewData.Name = "btnManipulateDataViewData"
      Me.btnManipulateDataViewData.Size = New System.Drawing.Size(267, 23)
      Me.btnManipulateDataViewData.TabIndex = 13
      Me.btnManipulateDataViewData.Text = "Manipulate DataView Data"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(282, 408)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnManipulateDataViewData, Me.btnSortDataView, Me.btnSearchDataView, Me.btnInstantiateDataView, Me.btnTriggerListChangeEvent, Me.btnTriggerRowDeleteEvents, Me.btnTriggerRowChangeEvents, Me.btnTriggerColumnChangeEvents, Me.btnTestCultureSettings, Me.btnBuildDataTable, Me.btnCopyRowsInDataTable, Me.btnSearchDataTable, Me.btnPopulateDataTable, Me.btnInstantiateDataTable})
      Me.Name = "Form1"
      Me.Text = "DataTable_DataView Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnInstantiateDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataTable.Click
      InstantiateDataTable()
   End Sub

   Private Sub btnPopulateDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateDataTable.Click
      PopulateDataTable()
   End Sub

   Private Sub btnSearchDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchDataTable.Click
      'SearchDataTableUsingSelect()
      SearchDataTableUsingDefaultView()
   End Sub

   Private Sub btnCopyRowsInDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyRowsInDataTable.Click
      CopyRowsInDataTable()
   End Sub

   Private Sub btnBuildDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuildDataTable.Click
      BuildDataTable()
   End Sub

   Private Sub btnTestCultureSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTestCultureSettings.Click
      TestCultureSettings()
   End Sub

   Private Sub btnTriggerColumnChangeEvents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerColumnChangeEvents.Click
      CGeneral.TriggerColumnChangeEvents()
   End Sub

   Private Sub btnTriggerRowChangeEvents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerRowChangeEvents.Click
      CGeneral.TriggerRowChangeEvents()
   End Sub

   Private Sub btnTriggerRowDeleteEvents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerRowDeleteEvents.Click
      CGeneral.TriggerRowDeleteEvents()
   End Sub

   Private Sub btnTriggerListChangeEvent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerListChangeEvent.Click
      CGeneral.TriggerListChangeEvent()
   End Sub

   Private Sub btnInstantiateDataView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataView.Click
      InstantiateDataView()
   End Sub

   Private Sub btnSearchDataView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchDataView.Click
      'SearchDataViewUsingFind()
      SearchDataViewUsingFindRows()
   End Sub

   Private Sub btnSortDataView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSortDataView.Click
      SortDataView()
   End Sub

   Private Sub btnManipulateDataViewData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManipulateDataViewData.Click
      ManipulateRowsInDataView()
   End Sub
End Class