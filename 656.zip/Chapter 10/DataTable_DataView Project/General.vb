Option Strict On

Imports System.Data.SqlClient
Imports System.Xml
Imports System.IO
Imports System.Globalization
Imports System.Threading

Module General
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   Public Sub InstantiateDataTable()
      Dim dtbNoArgumentsWithInitialize As New DataTable()
      Dim dtbTableNameArgumentWithInitialize As New DataTable("TableName")

      Dim dtbNoArgumentsWithoutInitialize As DataTable
      Dim dtbTableNameArgumentWithoutInitialize As DataTable

      dtbNoArgumentsWithoutInitialize = New DataTable()
      dtbTableNameArgumentWithoutInitialize = New DataTable("TableName")
   End Sub

   ' Listing 10-1
   Public Sub BuildDataTable()
      Dim dtbUser As DataTable
      Dim dclUser As DataColumn
      Dim arrdclPrimaryKey(0) As DataColumn

      ' Instantiate DataTable
      dtbUser = New DataTable("tblUser")

      ' Create table structure
      ' Id column
      dclUser = New DataColumn()
      dclUser.ColumnName = "Id"
      dclUser.DataType = Type.GetType("System.Int32")
      dclUser.AutoIncrement = True
      dclUser.AutoIncrementSeed = 1
      dclUser.AutoIncrementStep = 1
      dclUser.AllowDBNull = False
      ' Add column to data table structure
      dtbUser.Columns.Add(dclUser)
      ' Add column to Primary key array
      arrdclPrimaryKey(0) = dclUser
      ' Set primary key
      dtbUser.PrimaryKey = arrdclPrimaryKey

      ' ADName column
      dclUser = New DataColumn()
      dclUser.ColumnName = "ADName"
      dclUser.DataType = Type.GetType("System.String")
      ' Add column to data table structure
      dtbUser.Columns.Add(dclUser)

      ' ADSID column
      dclUser = New DataColumn()
      dclUser.ColumnName = "ADSID"
      dclUser.DataType = Type.GetType("System.String")
      ' Add column to data table structure
      dtbUser.Columns.Add(dclUser)

      ' FirstName column
      dclUser = New DataColumn()
      dclUser.ColumnName = "FirstName"
      dclUser.DataType = Type.GetType("System.String")
      ' Add column to data table structure
      dtbUser.Columns.Add(dclUser)

      ' LastName column
      dclUser = New DataColumn()
      dclUser.ColumnName = "LastName"
      dclUser.DataType = Type.GetType("System.String")
      ' Add column to data table structure
      dtbUser.Columns.Add(dclUser)

      ' LoginName column
      dclUser = New DataColumn()
      dclUser.ColumnName = "LoginName"
      dclUser.DataType = Type.GetType("System.String")
      dclUser.AllowDBNull = False
      dclUser.Unique = True
      ' Add column to data table structure
      dtbUser.Columns.Add(dclUser)

      ' Password column
      dclUser = New DataColumn()
      dclUser.ColumnName = "Password"
      dclUser.DataType = Type.GetType("System.String")
      dclUser.AllowDBNull = False
      ' Add column to data table structure
      dtbUser.Columns.Add(dclUser)
   End Sub

   ' Listing 10-2
   Public Sub TestCultureSettings()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim intCounter As Integer

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      ' Set the culture of the current thread as this will be used when
      ' you instantiate the DataTable
      Thread.CurrentThread.CurrentCulture = New CultureInfo("en-US")
      ' Instantiate data table
      dtbUser = New DataTable("tblUser")
      ' Set culture to US
      dtbUser.Locale = New CultureInfo("en-US")
      ' Fill the DataTable
      dadUser.Fill(dtbUser)
      ' Apply sorting to the default view
      dtbUser.DefaultView.Sort = "LastName DESC"

      ' Loop through all the rows in the default view
      For intCounter = 0 To dtbUser.DefaultView.Count - 1
         ' Display the Id of the current row in the default view
         MsgBox(dtbUser.DefaultView(intCounter).Row("Id").ToString(), _
            MsgBoxStyle.Information, dtbUser.Locale.DisplayName)
      Next

      ' Set culture to Danish
      dtbUser.Locale = New CultureInfo("da-DK")

      ' Loop through all the rows in the default view
      For intCounter = 0 To dtbUser.DefaultView.Count - 1
         ' Display the Id of the current row in the default view
         MsgBox(dtbUser.DefaultView(intCounter).Row("Id").ToString(), _
            MsgBoxStyle.Information, dtbUser.Locale.DisplayName)
      Next
   End Sub

   ' Listing 10-3
   Public Sub PopulateDataTable()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      ' Instantiate data table
      dtbUser = New DataTable("tblUser")
      ' Fill the data table
      dadUser.Fill(dtbUser)
   End Sub

   ' Listing 10-4
   Public Sub ClearDataTable()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      ' Instantiate data table
      dtbUser = New DataTable("tblUser")
      ' Fill the data table
      dadUser.Fill(dtbUser)
      ' Do your stuff
      ' ...
      Try
         ' Clear the data from the data table
         dtbUser.Clear()
      Catch objDataException As DataException
         ' There was a problem clearing the data table,
         ' probably because of a problem with
         ' orphaned rows in a child table
         MsgBox(objDataException.Message)
      End Try
   End Sub

   ' Listing 10-5
   Public Sub SearchDataTableUsingSelect()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim arrdrwSelect() As DataRow
      Dim drwSelect As DataRow

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()
      ' Instantiate the command and data table
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      ' Create the data table schema
      dadUser.FillSchema(dtbUser, SchemaType.Source)
      ' Fill the data table
      dadUser.Fill(dtbUser)
      ' Search the data table
      arrdrwSelect = dtbUser.Select("FirstName = 'John' AND LastName='Doe'")

      ' Loop through all the selected rows
      For Each drwSelect In arrdrwSelect
         ' Display the Id of the retrieved rows
         MsgBox(drwSelect("Id").ToString())
      Next
   End Sub

   ' Listing 10-6
   Public Sub SearchDataTableUsingDefaultView()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim intCounter As Integer

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()
      ' Instantiate the command and data table
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      ' Fill the data table
      dadUser.Fill(dtbUser)
      ' Filter the data table view
      dtbUser.DefaultView.RowFilter = _
         "LastName = 'Doe' AND FirstName='John'"

      ' Loop through all the rows in the data table view
      For intCounter = 0 To dtbUser.DefaultView.Count - 1
         MsgBox(dtbUser.DefaultView(intCounter).Row("LastName").ToString())
      Next
   End Sub

   ' Listing 10-7
   Public Sub CopyRowsInDataTable()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim cmbUser As SqlCommandBuilder
      Dim intCounter As Integer

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()
      ' Instantiate the command and data table
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      cmbUser = New SqlCommandBuilder(dadUser)
      ' Fill the data table
      dadUser.Fill(dtbUser)

      ' Copy a row from the same table using ImportRow method
      dtbUser.ImportRow(dtbUser.Rows(0))
      ' Make sure the Update method detects the new row
      dtbUser.Rows(dtbUser.Rows.Count - 1)("LoginName") = "NewLogin1"

      ' Copy the first row from the same table using the LoadDataRow
      ' If you change the last argument of this method to true, the
      ' RowState property will be set to Unchanged
      dtbUser.LoadDataRow(New Object(6) {Nothing, dtbUser.Rows(0)("ADName"), _
         dtbUser.Rows(0)("ADSID"), dtbUser.Rows(0)("FirstName"), _
         dtbUser.Rows(0)("LastName"), "NewLogin2", _
         dtbUser.Rows(0)("Password")}, False)

      ' Loop through all the rows in the data table,
      ' displaying the Id and RowState value
      For intCounter = 0 To dtbUser.Rows.Count - 1
         MessageBox.Show(dtbUser.Rows(intCounter)("Id").ToString() & _
            " " & dtbUser.Rows(intCounter).RowState.ToString())
      Next

      ' Update the data source
      dadUser.Update(dtbUser)
   End Sub

   Public Sub InstantiateDataView()
      Dim dstUser As New DataSet()

      Dim dvwNoArgumentsWithInitializer As New DataView()
      Dim dvwTableArgumentWithInitializer _
         As New DataView(dstUser.Tables("tblUser"))

      Dim dvwNoArgumentsWithoutInitializer As DataView
      Dim dvwTableArgumentWithoutInitializer As DataView

      dvwNoArgumentsWithoutInitializer = New DataView()
      dvwTableArgumentWithoutInitializer = _
         New DataView(dstUser.Tables("tblUser"))
   End Sub

   ' Listing 10-12
   Public Sub SearchDataViewUsingFind()
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim dvwUser As DataView
      Dim intIndex As Integer

      ' Instantiate the data table
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", _
         PR_STR_CONNECTION_STRING)
      ' Fill the data table
      dadUser.Fill(dtbUser)
      ' Create the new data view
      dvwUser = dtbUser.DefaultView
      ' Specify a sort order
      dvwUser.Sort = "Id ASC"
      ' Find the user with an id of 1
      intIndex = dvwUser.Find(CObj(1))
      MsgBox(dvwUser(intIndex).Row("LastName").ToString())
   End Sub

   ' Listing 10-13
   Public Sub SearchDataViewUsingFindRows()
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim dvwUser As DataView
      Dim arrdrvRows() As DataRowView
      Dim drvFound As DataRowView

      ' Instantiate the data table
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", _
         PR_STR_CONNECTION_STRING)
      ' Fill the data table
      dadUser.Fill(dtbUser)
      ' Create the new data view
      dvwUser = dtbUser.DefaultView
      ' Specify a sort order
      dvwUser.Sort = "LastName ASC"
      ' Find the users with no LastName
      arrdrvRows = dvwUser.FindRows(CObj(DBNull.Value))

      ' Loop through collection
      For Each drvFound In arrdrvRows
         ' Display LoginName column value
         MsgBox(drvFound("LoginName").ToString)
      Next
   End Sub

   ' Listing 10-14
   Public Sub SortDataView()
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim intCounter As Integer

      ' Instantiate the data table
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", _
         PR_STR_CONNECTION_STRING)
      ' Fill the data table
      dadUser.Fill(dtbUser)
      ' Sort the data table view after LoginName in ascending order
      dtbUser.DefaultView.Sort = "LoginName ASC"

      ' Loop through all the rows in the data view,
      ' displaying the LoginName
      For intCounter = 0 To dtbUser.DefaultView.Count - 1
         MsgBox(dtbUser.DefaultView(intCounter)("LoginName").ToString())
      Next
   End Sub

   ' Listing 10-15
   Public Sub ManipulateRowsInDataView()
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As DataTable
      Dim drvUser As DataRowView

      ' Instantiate the data table
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", _
         PR_STR_CONNECTION_STRING)
      ' Fill the data table
      dadUser.FillSchema(dtbUser, SchemaType.Source)
      dadUser.Fill(dtbUser)
      ' Make sure we can manipulate the rows in the default view
      dtbUser.DefaultView.AllowDelete = True
      dtbUser.DefaultView.AllowEdit = True
      dtbUser.DefaultView.AllowNew = True
      ' Apply row filter 
      dtbUser.DefaultView.RowFilter = "LastName IS NULL"

      Try
         ' Update existing row
         dtbUser.DefaultView(0).BeginEdit()
         dtbUser.DefaultView(0)("LastName") = "NewLastName"
         dtbUser.DefaultView(0).EndEdit()
         ' Delete existing row
         dtbUser.DefaultView.Delete(2)
         ' Insert new row
         drvUser = dtbUser.DefaultView.AddNew()
         ' Begin edit of the new row
         drvUser.BeginEdit()
         ' Add values to the new row
         drvUser("LoginName") = "NewLogin"
         drvUser("Password") = "password"
         drvUser("LastName") = "NewLastName2"
         ' End row edit and update row in data view
         drvUser.EndEdit()
      Catch objE As DataException
         MsgBox(objE.Message)
      End Try

      Dim intCounter As Integer
      ' Loop through all the rows in the data view,
      ' displaying the LoginName
      For intCounter = 0 To dtbUser.DefaultView.Count - 1
         MsgBox(dtbUser.DefaultView(intCounter)("LoginName").ToString())
      Next
   End Sub
End Module