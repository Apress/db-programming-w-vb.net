Option Strict On

Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Xml
Imports System.IO
Imports ADODB

Module General
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   ' Listing 9-2
   Public Sub InstantiateDataSet()
      ' Declare and instantiate
      Dim dstUnnamed1 As New DataSet()
      Dim dstNamed1 As New DataSet("UserManDataSet")

      ' Declare
      Dim dstUnnamed2 As DataSet
      Dim dstNamed2 As DataSet

      ' Instantiate
      dstUnnamed2 = New DataSet()
      dstNamed2 = New DataSet("UserManDataSet")

      ' Name DataSets
      dstUnnamed1.DataSetName = "Unnamed1"
      dstUnnamed2.DataSetName = "Unnamed2"
   End Sub

   ' Listing 9-3
   Public Sub FillDataSetFromRecordset()
      Const STR_CONNECTION_STRING As String = "Provider=SQLOLEDB;" & _
         "Data Source=10.8.1.11;User ID=UserMan;Password=userman;" & _
         "Initial Catalog=UserMan"
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As OleDbConnection
      Dim dadUserMan As OleDbDataAdapter
      Dim dstUserMan As DataSet

      Dim rstUser As ADODB.Recordset
      Dim cnnADOUserMan As ADODB.Connection

      Dim intNumRows As Integer

      ' Instantiate the connections
      cnnUserMan = New OleDbConnection(STR_CONNECTION_STRING)
      cnnADOUserMan = New ADODB.Connection()
      ' Open the connection
      cnnADOUserMan.Open(STR_CONNECTION_STRING)

      ' Instantiate data adapter
      dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, _
         cnnUserMan)

      ' Instantiate dataset
      dstUserMan = New DataSet()
      ' Instantiate recordset
      rstUser = New ADODB.Recordset()

      ' Populate recordset
      rstUser.Open(STR_SQL_USER_SELECT, cnnADOUserMan)
      ' Fill dataset
      intNumRows = dadUserMan.Fill(dstUserMan, rstUser, _
         "tblUser")
   End Sub

   ' Listing 9-4
   Public Sub MergeDataSetWithDataRows()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dstUser As DataSet
      Dim dtbUser As DataTable
      Dim arrdrwUser(0) As DataRow
      Dim drwUser As DataRow

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command, data set and data table
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dstUser = New DataSet()
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      ' Fill the data set
      dadUser.Fill(dstUser, "tblUser")
      ' Create new row and fill with data
      drwUser = dstUser.Tables("tblUser").NewRow()
      drwUser("LoginName") = "NewUser1"
      drwUser("FirstName") = "New"
      drwUser("LastName") = "User"
      arrdrwUser.SetValue(drwUser, 0)
      ' Merge the data set with the data row array
      dstUser.Merge(arrdrwUser)
   End Sub

   ' Listing 9-5
   Public Sub MergeDataSets()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dstUser As DataSet
      Dim dstCopy As DataSet

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command and data set
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dstUser = New DataSet()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      ' Fill the data set
      dadUser.Fill(dstUser, "tblUser")
      ' Copy the data set
      dstCopy = dstUser.Copy()
      ' Do your stuff with the data sets
      ' ...
      ' Merge the two data sets
      dstUser.Merge(dstCopy)
   End Sub

   ' Listing 9-6
   Public Sub MergeDataSetWithDataTable()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dstUser As DataSet
      Dim dtbUser As DataTable

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command, data set and data table
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dstUser = New DataSet()
      dtbUser = New DataTable()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      ' Fill the data set and data table
      dadUser.Fill(dstUser, "tblUser")
      dadUser.Fill(dtbUser)
      ' Do your stuff with the data set and the data table
      ' ...
      ' Merge the data set with the data table
      dstUser.Merge(dtbUser)
   End Sub

   ' Listing 9-8
   Public Sub DetectDataSetChanges()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dstUser As DataSet
      Dim dstAllChanges, dstChanges As DataSet
      Dim dstAdditions, dstDeletions As DataSet

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command and data set
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dstUser = New DataSet()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      ' Fill the data set
      dadUser.Fill(dstUser, "tblUser")
      ' Do your stuff with the data set
      ' ...
      ' Check if any errors exist in the DataSet
      If Not dstUser.HasErrors Then
         ' Check if any data has changed in the data set
         If dstUser.HasChanges() Then
            ' Save all changes in a new data set
            dstAllChanges = dstUser.GetChanges()
            ' Save all modified rows in a new data set
            dstChanges = dstUser.GetChanges(DataRowState.Modified)
            ' Save all added rows in a new data set
            dstAdditions = dstUser.GetChanges(DataRowState.Added)
            ' Save all deleted rows in a new data set
            dstDeletions = dstUser.GetChanges(DataRowState.Deleted)
         End If
      Else
         ' Deal with errors in DataSet
      End If
   End Sub

   ' Listing 9-9
   Public Sub AcceptOrRejectDataSetChanges()
      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter
      Dim dstUser, dstChanges As DataSet
      Dim drwUser As DataRow
      Dim intCounter As Integer

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command and the data set
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      dstUser = New DataSet()
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)
      dadUser.SelectCommand = cmmUser
      ' Fill the data set
      dadUser.Fill(dstUser, "tblUser")
      ' Create a new data row with the schema from the user table
      drwUser = dstUser.Tables("tblUser").NewRow()
      ' Enter values in the data row columns
      drwUser("LoginName") = "NewUser1"
      drwUser("FirstName") = "New"
      drwUser("LastName") = "User"
      ' Add the data row to the user table
      dstUser.Tables("tblUser").Rows.Add(drwUser)
      ' Check if any data has changed in the data set
      If dstUser.HasChanges() Then
         ' Save all changed rows in a new data set
         dstChanges = dstUser.GetChanges()
         ' Check if the changed rows contains any errors
         If dstChanges.HasErrors() Then
            ' Display the row state of all rows before rejecting changes
            For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
               MsgBox("HasErrors=True, Before RejectChanges, RowState=" & _
                dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
                ", LoginName=" & _
                dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
            Next
            ' Reject the changes to the data set
            dstUser.RejectChanges()
            ' Display the row state of all rows after rejecting changes
            For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
               MsgBox("HasErrors=True, After RejectChanges, RowState=" & _
                dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
                ", LoginName=" & _
                dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
            Next
         Else
            ' Display the row state of all rows before accepting changes
            For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
               MsgBox("HasErrors=False, Before AcceptChanges, RowState=" & _
                dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
                ", LoginName=" & _
                dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
            Next
            ' Accept the changes to the data set
            dstUser.AcceptChanges()
            ' Display the row state of all rows after accepting changes
            For intCounter = 0 To dstUser.Tables(0).Rows.Count - 1
               MsgBox("HasErrors=False, After AcceptChanges, RowState=" & _
                dstUser.Tables(0).Rows(intCounter).RowState.ToString & _
                ", LoginName=" & _
                dstUser.Tables(0).Rows(intCounter)("LoginName").ToString)
            Next
         End If
      End If
   End Sub

   ' Listing 9-10
   Public Sub UpdateDataSet()
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser"
      Const STR_SQL_USER_DELETE As String = _
         "DELETE FROM tblUser WHERE Id=@Id"
      Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(" & _
         "ADName, ADSID, FirstName, LastName, LoginName, Password) " & _
         "VALUES(@ADName, @ADSID, @FirstName, @LastName, @LoginName, " & _
         "@Password)"
      Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET " & _
         "ADName=@ADName, ADSID=@ADSID, FirstName=@FirstName, " & _
         "LastName=@LastName, LoginName=@LoginName, Password=@Password " & _
         "WHERE Id=@Id"

      Dim cnnUserMan As SqlConnection
      Dim cmmUserSelect As SqlCommand
      Dim cmmUserDelete As SqlCommand
      Dim cmmUserInsert As SqlCommand
      Dim cmmUserUpdate As SqlCommand
      Dim dadUserMan As SqlDataAdapter
      Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As SqlParameter
      Dim dstUserMan, dstChanges As DataSet
      Dim drwUser As DataRow

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the commands
      cmmUserSelect = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
      cmmUserDelete = New SqlCommand(STR_SQL_USER_DELETE, cnnUserMan)
      cmmUserInsert = New SqlCommand(STR_SQL_USER_INSERT, cnnUserMan)
      cmmUserUpdate = New SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan)

      ' Instantiate data adapter
      dadUserMan = New SqlDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
      ' Set data adapter command properties
      dadUserMan.SelectCommand = cmmUserSelect
      dadUserMan.InsertCommand = cmmUserInsert
      dadUserMan.DeleteCommand = cmmUserDelete
      dadUserMan.UpdateCommand = cmmUserUpdate

      ' Add Delete command parameters
      prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", _
         SqlDbType.Int, Nothing, "Id")
      prmSQLDelete.Direction = ParameterDirection.Input
      prmSQLDelete.SourceVersion = DataRowVersion.Original

      ' Add Update command parameters
      cmmUserUpdate.Parameters.Add("@ADName", SqlDbType.VarChar, 100, _
         "ADName")
      cmmUserUpdate.Parameters.Add("@ADSID", SqlDbType.VarChar, 50, _
         "ADSID")
      cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, _
         "FirstName")
      cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, _
         "LastName")
      cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, _
         "LoginName")
      cmmUserUpdate.Parameters.Add("@Password", SqlDbType.VarChar, 50, _
         "Password")

      prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", _
         SqlDbType.Int, Nothing, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original

      ' Add insert command parameters
      cmmUserInsert.Parameters.Add("@ADName", SqlDbType.VarChar, 100, _
         "ADName")
      cmmUserInsert.Parameters.Add("@ADSID", SqlDbType.VarChar, 50, _
         "ADSID")
      cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, _
         "FirstName")
      cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, _
         "LastName")
      cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, _
         "LoginName")
      cmmUserInsert.Parameters.Add("@Password", SqlDbType.VarChar, 50, _
         "Password")

      ' Instantiate dataset
      dstUserMan = New DataSet()
      ' Populate the data set
      dadUserMan.Fill(dstUserMan, "tblUser")

      ' Add new row
      drwUser = dstUserMan.Tables("tblUser").NewRow()
      drwUser("FirstName") = "New User"
      drwUser("LastName") = "New User LastName"
      drwUser("LoginName") = "NewUser"
      drwUser("Password") = "password"
      dstUserMan.Tables("tblUser").Rows.Add(drwUser)

      ' Update an existing row (with index 3)
      dstUserMan.Tables("tblUser").Rows(3)("FirstName") = "FirstName"
      dstUserMan.Tables("tblUser").Rows(3)("LastName") = "LastName"
      dstUserMan.Tables("tblUser").Rows(3)("LoginName") = "User3"

      ' Delete row with index 4
      dstUserMan.Tables("tblUser").Rows(4).Delete()

      ' Check if any data has changed in the data set
      If dstUserMan.HasChanges() Then
         ' Save all changed rows in a new data set
         dstChanges = dstUserMan.GetChanges()
         ' Check if the changed rows contains any errors
         If dstChanges.HasErrors() Then
            ' Reject the changes
            dstUserMan.RejectChanges()
         Else
            ' Update the data source
            dadUserMan.Update(dstChanges, "tblUser")
         End If
      End If
   End Sub
End Module