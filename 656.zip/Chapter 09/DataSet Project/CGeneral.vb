Imports System.Data.SqlClient

Public Class CGeneral
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   ' Listing 9-7-1
   Private Shared Sub OnMergeFailed(ByVal sender As Object, ByVal args As MergeFailedEventArgs)
      ' Display a message detailing the merge conflict
      MsgBox("There were errors when merging the data sets:" & vbCrLf & _
         vbCrLf & args.Conflict & " The conflict happened in table " & _
         args.Table.TableName & ".")
   End Sub

   ' Listing 9-7-2
   Public Shared Sub HandleMergeFailures()
      Dim drwNew As DataRow
      ' Declare and instantiate data sets
      Dim dstUser As New DataSet("Users")
      Dim dstCopy As New DataSet("UsersCopy")
      Dim dstClone As New DataSet("UsersClone")

      ' Declare and instantiate connections
      Dim cnnUserMan As New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Declare and instantiate data adapters
      Dim prdadUserMan As New SqlDataAdapter("SELECT * FROM tblUser", _
         cnnUserMan)

      ' Set up event handler
      AddHandler dstUser.MergeFailed, AddressOf OnMergeFailed

      ' Open the connection
      cnnUserMan.Open()
      ' Populate the dataset
      prdadUserMan.Fill(dstUser, "tblUser")
      ' Close the connection
      cnnUserMan.Close()
      ' Copy dataset
      dstCopy = dstUser.Copy()

      Try
         ' Add new string column to user table in
         ' dataset copy
         dstCopy.Tables("tblUser").Columns.Add("NewColumn", _
            Type.GetType("System.String"))
         ' Merge the data sets
         dstUser.Merge(dstCopy, True, MissingSchemaAction.Error)
      Catch objE As Exception
         MsgBox("An exception was thrown when merging the data sets:" & vbCrLf & _
            vbCrLf & objE.Message)
      End Try

      ' Clone dataset
      dstClone = dstUser.Clone
      ' Do your stuff
      ' ...
      ' Merge the data sets
      dstUser.Merge(dstClone, True)
   End Sub
End Class