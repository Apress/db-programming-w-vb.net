Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnInstantiateDataSetObject As System.Windows.Forms.Button
   Friend WithEvents btnPopulateDataSetFromRecordset As System.Windows.Forms.Button
   Friend WithEvents btnMergeDataSetWithDataRows As System.Windows.Forms.Button
   Friend WithEvents btnMergeDataSets As System.Windows.Forms.Button
   Friend WithEvents btnMergeDataSetWithDataTable As System.Windows.Forms.Button
   Friend WithEvents btnHandleMergeFailure As System.Windows.Forms.Button
   Friend WithEvents btnDetectDataSetChanges As System.Windows.Forms.Button
   Friend WithEvents btnAcceptRejectDataSetChanges As System.Windows.Forms.Button
   Friend WithEvents btnUpdateDataSet As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnInstantiateDataSetObject = New System.Windows.Forms.Button()
      Me.btnPopulateDataSetFromRecordset = New System.Windows.Forms.Button()
      Me.btnMergeDataSetWithDataRows = New System.Windows.Forms.Button()
      Me.btnMergeDataSets = New System.Windows.Forms.Button()
      Me.btnMergeDataSetWithDataTable = New System.Windows.Forms.Button()
      Me.btnHandleMergeFailure = New System.Windows.Forms.Button()
      Me.btnDetectDataSetChanges = New System.Windows.Forms.Button()
      Me.btnAcceptRejectDataSetChanges = New System.Windows.Forms.Button()
      Me.btnUpdateDataSet = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnInstantiateDataSetObject
      '
      Me.btnInstantiateDataSetObject.Location = New System.Drawing.Point(12, 14)
      Me.btnInstantiateDataSetObject.Name = "btnInstantiateDataSetObject"
      Me.btnInstantiateDataSetObject.Size = New System.Drawing.Size(210, 23)
      Me.btnInstantiateDataSetObject.TabIndex = 1
      Me.btnInstantiateDataSetObject.Text = "Instantiate DataSet Object"
      '
      'btnPopulateDataSetFromRecordset
      '
      Me.btnPopulateDataSetFromRecordset.Location = New System.Drawing.Point(12, 42)
      Me.btnPopulateDataSetFromRecordset.Name = "btnPopulateDataSetFromRecordset"
      Me.btnPopulateDataSetFromRecordset.Size = New System.Drawing.Size(210, 23)
      Me.btnPopulateDataSetFromRecordset.TabIndex = 2
      Me.btnPopulateDataSetFromRecordset.Text = "Populate DataSet from Recordset"
      '
      'btnMergeDataSetWithDataRows
      '
      Me.btnMergeDataSetWithDataRows.Location = New System.Drawing.Point(12, 70)
      Me.btnMergeDataSetWithDataRows.Name = "btnMergeDataSetWithDataRows"
      Me.btnMergeDataSetWithDataRows.Size = New System.Drawing.Size(210, 23)
      Me.btnMergeDataSetWithDataRows.TabIndex = 3
      Me.btnMergeDataSetWithDataRows.Text = "Merge DataSet with DataRows"
      '
      'btnMergeDataSets
      '
      Me.btnMergeDataSets.Location = New System.Drawing.Point(12, 98)
      Me.btnMergeDataSets.Name = "btnMergeDataSets"
      Me.btnMergeDataSets.Size = New System.Drawing.Size(210, 23)
      Me.btnMergeDataSets.TabIndex = 4
      Me.btnMergeDataSets.Text = "Merge DataSets"
      '
      'btnMergeDataSetWithDataTable
      '
      Me.btnMergeDataSetWithDataTable.Location = New System.Drawing.Point(12, 126)
      Me.btnMergeDataSetWithDataTable.Name = "btnMergeDataSetWithDataTable"
      Me.btnMergeDataSetWithDataTable.Size = New System.Drawing.Size(210, 23)
      Me.btnMergeDataSetWithDataTable.TabIndex = 5
      Me.btnMergeDataSetWithDataTable.Text = "Merge DataSet with DataTable"
      '
      'btnHandleMergeFailure
      '
      Me.btnHandleMergeFailure.Location = New System.Drawing.Point(12, 154)
      Me.btnHandleMergeFailure.Name = "btnHandleMergeFailure"
      Me.btnHandleMergeFailure.Size = New System.Drawing.Size(210, 23)
      Me.btnHandleMergeFailure.TabIndex = 6
      Me.btnHandleMergeFailure.Text = "Handle Merge Failure"
      '
      'btnDetectDataSetChanges
      '
      Me.btnDetectDataSetChanges.Location = New System.Drawing.Point(12, 182)
      Me.btnDetectDataSetChanges.Name = "btnDetectDataSetChanges"
      Me.btnDetectDataSetChanges.Size = New System.Drawing.Size(210, 23)
      Me.btnDetectDataSetChanges.TabIndex = 7
      Me.btnDetectDataSetChanges.Text = "Detect DataSet Changes"
      '
      'btnAcceptRejectDataSetChanges
      '
      Me.btnAcceptRejectDataSetChanges.Location = New System.Drawing.Point(12, 210)
      Me.btnAcceptRejectDataSetChanges.Name = "btnAcceptRejectDataSetChanges"
      Me.btnAcceptRejectDataSetChanges.Size = New System.Drawing.Size(210, 23)
      Me.btnAcceptRejectDataSetChanges.TabIndex = 8
      Me.btnAcceptRejectDataSetChanges.Text = "Accept/Reject DataSet Changes"
      '
      'btnUpdateDataSet
      '
      Me.btnUpdateDataSet.Location = New System.Drawing.Point(12, 238)
      Me.btnUpdateDataSet.Name = "btnUpdateDataSet"
      Me.btnUpdateDataSet.Size = New System.Drawing.Size(210, 23)
      Me.btnUpdateDataSet.TabIndex = 9
      Me.btnUpdateDataSet.Text = "Update DataSet"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(234, 276)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnUpdateDataSet, Me.btnAcceptRejectDataSetChanges, Me.btnDetectDataSetChanges, Me.btnHandleMergeFailure, Me.btnMergeDataSetWithDataTable, Me.btnMergeDataSets, Me.btnMergeDataSetWithDataRows, Me.btnPopulateDataSetFromRecordset, Me.btnInstantiateDataSetObject})
      Me.Name = "Form1"
      Me.Text = "DataSet Project"
      Me.ResumeLayout(False)

   End Sub

#End Region


   Private Sub btnInstantiateDataReaderObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataSetObject.Click
      InstantiateDataSet()
   End Sub

   Private Sub btnPopulateDataSetFromRecordset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopulateDataSetFromRecordset.Click
      FillDataSetFromRecordset()
   End Sub

   Private Sub btnMergeDataSetWithDataRows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSetWithDataRows.Click
      MergeDataSetWithDataRows()
   End Sub

   Private Sub btnMergeDataSets_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSets.Click
      MergeDataSets()
   End Sub

   Private Sub btnMergeDataSetWithDataTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMergeDataSetWithDataTable.Click
      MergeDataSetWithDataTable()
   End Sub

   Private Sub btnHandleMergeFailure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHandleMergeFailure.Click
      CGeneral.HandleMergeFailures()
   End Sub

   Private Sub btnDetectDataSetChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDetectDataSetChanges.Click
      DetectDataSetChanges()
   End Sub

   Private Sub btnAcceptRejectDataSetChanges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAcceptRejectDataSetChanges.Click
      AcceptOrRejectDataSetChanges()
   End Sub

   Private Sub btnUpdateDataSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateDataSet.Click
      UpdateDataSet()
   End Sub
End Class