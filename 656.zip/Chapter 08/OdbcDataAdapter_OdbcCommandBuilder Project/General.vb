Option Strict On

Imports Microsoft.Data.Odbc
Imports System.IO

#Const MySQL = 1
'#Const Oracle = 1
'#Const MSAccess = 1
'#Const SQLSERVER = 1
'#Const DB2 = 1
' You simply uncomment the line above for the DBMS you want to use

Module General
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = "DRIVER={SQL Server};SERVER=USERMANPC;" & _
      "UID=UserMan;PWD=userman;DATABASE=UserMan"
#ElseIf MSAccess Then
	' This connection string os for connecting to an Access mdb
   ' I'm not using any security, hence no specification of User Id and password. 
   ' You must edit the path to your database file
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={Microsoft Access Driver (*.mdb)};DBQ=C:\DBPWVBNET\UserMan.mdb;"
#ElseIf MySQL Then
   ' This connection string os for connecting to MySQL 3.23.51 or later
   ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={MySQL};SERVER=10.8.1.32;UID=UserMan;PWD=userman;DATABASE=UserMan"
#ElseIf Oracle Then
	' This connection string os for connecting to Oracle
   ' You must change the SERVER value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={Microsoft ODBC for Oracle};PWD=userman;UID=USERMAN;SERVER=USERMAN"
#ElseIf DB2 Then
   ' This connection string os for connecting to IBM DB2 Universal Database 7.2 EE
   ' You must change the DBALIAS value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "DRIVER={IBM DB2 ODBC DRIVER};PWD=userman;UID=USERMAN;DBALIAS=USERMAN;"
#End If

   ' Listing 8-1
   Public Sub InstantiateAndInitializeDataAdapter()
      Const STR_SQL_USER As String = "SELECT * FROM tblUser"

      Dim cnnUserMan As OdbcConnection
      Dim cmmUser As OdbcCommand
      Dim dadDefaultConstructor As OdbcDataAdapter
      Dim dadOdbcCommandArgument As OdbcDataAdapter
      Dim dadOdbcConnectionArgument As OdbcDataAdapter
      Dim dadStringArguments As OdbcDataAdapter

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command
      cmmUser = New OdbcCommand(STR_SQL_USER)

      ' Instantiate data adapters
      dadDefaultConstructor = New OdbcDataAdapter()
      dadOdbcCommandArgument = New OdbcDataAdapter(cmmUser)
      dadOdbcConnectionArgument = New OdbcDataAdapter(STR_SQL_USER, cnnUserMan)
      dadStringArguments = New OdbcDataAdapter(STR_SQL_USER, PR_STR_CONNECTION_STRING)
      ' Initialize data adapters
      dadDefaultConstructor.SelectCommand = New OdbcCommand(STR_SQL_USER)
      dadDefaultConstructor.SelectCommand.Connection = cnnUserMan
   End Sub

   ' Listing 8-3
   Public Sub SetDataAdapterCommandProperties()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
      Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=?"
      Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(ADName, " & _
         "ADSID, FirstName, LastName, LoginName, Password) " & _
         "VALUES(?, ?, ?, ?, ?, ?)"
      Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET ADName=?, " & _
         "ADSID=?, FirstName=?, LastName=?, LoginName=?, Password=? WHERE Id=?"

      Dim cnnUserMan As OdbcConnection
      Dim cmmUserSelect As OdbcCommand
      Dim cmmUserDelete As OdbcCommand
      Dim cmmUserInsert As OdbcCommand
      Dim cmmUserUpdate As OdbcCommand
      Dim dadUserMan As OdbcDataAdapter
      Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As OdbcParameter

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the commands
      cmmUserSelect = New OdbcCommand(STR_SQL_USER_SELECT, cnnUserMan)
      cmmUserDelete = New OdbcCommand(STR_SQL_USER_DELETE, cnnUserMan)
      cmmUserInsert = New OdbcCommand(STR_SQL_USER_INSERT, cnnUserMan)
      cmmUserUpdate = New OdbcCommand(STR_SQL_USER_UPDATE, cnnUserMan)

      ' Instantiate data adapter
      dadUserMan = New OdbcDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
      ' Set data adapter command properties
      dadUserMan.SelectCommand = cmmUserSelect
      dadUserMan.InsertCommand = cmmUserInsert
      dadUserMan.DeleteCommand = cmmUserDelete
      dadUserMan.UpdateCommand = cmmUserUpdate

      ' Add Delete command parameters
      prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", _
         OdbcType.Int, Nothing, "Id")
      prmSQLDelete.Direction = ParameterDirection.Input
      prmSQLDelete.SourceVersion = DataRowVersion.Original

      ' Add Update command parameters
      cmmUserUpdate.Parameters.Add("@ADName", OdbcType.VarChar, 100, _
         "ADName")
      cmmUserUpdate.Parameters.Add("@ADSID", OdbcType.VarChar, 50, _
         "ADSID")
      cmmUserUpdate.Parameters.Add("@FirstName", OdbcType.VarChar, 50, _
         "FirstName")
      cmmUserUpdate.Parameters.Add("@LastName", OdbcType.VarChar, 50, _
         "LastName")
      cmmUserUpdate.Parameters.Add("@LoginName", OdbcType.VarChar, 50, _
         "LoginName")
      cmmUserUpdate.Parameters.Add("@Password", OdbcType.VarChar, 50, _
         "Password")

      prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", _
         OdbcType.Int, Nothing, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original

      ' Add insert command parameters
      cmmUserInsert.Parameters.Add("@ADName", OdbcType.VarChar, 100, _
         "ADName")
      cmmUserInsert.Parameters.Add("@ADSID", OdbcType.VarChar, 50, _
         "ADSID")
      cmmUserInsert.Parameters.Add("@FirstName", OdbcType.VarChar, 50, _
         "FirstName")
      cmmUserInsert.Parameters.Add("@LastName", OdbcType.VarChar, 50, _
         "LastName")
      cmmUserInsert.Parameters.Add("@LoginName", OdbcType.VarChar, 50, _
         "LoginName")
      cmmUserInsert.Parameters.Add("@Password", OdbcType.VarChar, 50, _
         "Password")
   End Sub

   ' Listing 8-5
   Public Sub GetSelectParameters()
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser WHERE LoginName=@LoginName"

      Dim cnnUserMan As OdbcConnection
      Dim cmmUserSelect As OdbcCommand
      Dim dadUserMan As OdbcDataAdapter
      Dim prmSQLSelect As OdbcParameter
      Dim arrprmSelect() As Object
      Dim prmSelect As OdbcParameter

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the select command
      cmmUserSelect = New OdbcCommand(STR_SQL_USER_SELECT, cnnUserMan)

      ' Instantiate data adapter
      dadUserMan = New OdbcDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
      ' Set data adapter select command property
      dadUserMan.SelectCommand = cmmUserSelect

      ' Add Select command parameter
      prmSQLSelect = dadUserMan.SelectCommand.Parameters.Add("@LoginName", _
         OdbcType.VarChar, 50, "LoginName")
      prmSQLSelect.Direction = ParameterDirection.Input
      prmSQLSelect.SourceVersion = DataRowVersion.Current
      prmSQLSelect.Value = "UserMan"
      ' Retrieve select statement parameters
      arrprmSelect = dadUserMan.GetFillParameters()

      ' Loop through all the parameters
      For Each prmSelect In arrprmSelect
         ' Display some of the properties
         MsgBox("Name = " & prmSelect.ParameterName & vbCrLf & _
            "Value = " & prmSQLSelect.Value.ToString & vbCrLf & _
            "DB Data Type = " & prmSQLSelect.DbType.ToString & vbCrLf & _
            "Parameter Type = " & prmSQLSelect.Direction.ToString)
      Next
   End Sub

   ' Listing 8-6
   Public Sub GetSimpleTableSchema()
      Const STR_SQL_USER_SELECT_ALL As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As OdbcConnection
      Dim dadUserMan As OdbcDataAdapter
      Dim dtbUser As New DataTable()
      Dim dtcUser As DataColumn

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate data adapter
      dadUserMan = New OdbcDataAdapter(STR_SQL_USER_SELECT_ALL, _
         cnnUserMan)
      ' Retrieve table schema from data source
      dadUserMan.FillSchema(dtbUser, SchemaType.Source)

      ' Loop through all the columns in the data table
      For Each dtcUser In dtbUser.Columns
         ' Display the name of the column
         MsgBox(dtcUser.ColumnName)
      Next
   End Sub

   ' Listing 8-7
   Public Sub GetTableSchema()
      Const STR_SQL_USER_SELECT_LOG As String = _
         "SELECT * FROM tblLog"
      Const STR_SQL_USER_SELECT_USER As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As OdbcConnection
      Dim dadUserMan As OdbcDataAdapter
      Dim dstUserMan As New DataSet("UserMan")
      Dim dtbSchema() As DataTable
      Dim dtbUser As DataTable

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate data adapter
      dadUserMan = New OdbcDataAdapter(STR_SQL_USER_SELECT_LOG, _
         cnnUserMan)
      ' Populate the DataSet with the Log table
      dadUserMan.Fill(dstUserMan, "tblLog")
      ' Set the 
      dadUserMan.SelectCommand.CommandText = _
         STR_SQL_USER_SELECT_USER
      ' Retrieve table schema from data source
      dtbSchema = dadUserMan.FillSchema(dstUserMan, _
         SchemaType.Source)

      ' Display the name of the tables that
      ' had a schema returned
      For Each dtbUser In dtbSchema
         MsgBox(dtbUser.TableName, MsgBoxStyle.OKOnly, "DataTable Array Reference")
      Next

      ' Display the name of the tables in
      ' the DataSet
      For Each dtbUser In dstUserMan.Tables
         MsgBox(dtbUser.TableName, MsgBoxStyle.OKOnly, "DataSet Tables")
      Next
   End Sub

   ' Listing 8-8
   Public Sub GetFullTableSchema()
#If SQLSERVER Then
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser;SELECT * FROM tblLog"
#Else
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser"
#End If

      Dim cnnUserMan As OdbcConnection
      Dim dadUserMan As OdbcDataAdapter
      Dim dstUserMan As New DataSet("UserMan")
      Dim dtbSchema() As DataTable
      Dim dtbUser As DataTable

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate data adapter
      dadUserMan = New OdbcDataAdapter(STR_SQL_USER_SELECT, _
         cnnUserMan)
      ' Retrieve table schema from data source
      dtbSchema = dadUserMan.FillSchema(dstUserMan, _
         SchemaType.Source, "tblUser")

      ' Display the name of the tables
      For Each dtbUser In dtbSchema
         MsgBox(dtbUser.TableName)
      Next
   End Sub

   ' Listing 8-10
   Public Sub SetDataAdapterCommandPropertiesUsingCommandBuilder()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

      Dim cnnUserMan As OdbcConnection
      Dim cmmUserSelect As OdbcCommand
      Dim dadUserMan As OdbcDataAdapter
      Dim cmbUser As New OdbcCommandBuilder(dadUserMan)

      ' Instantiate the connection
      cnnUserMan = New OdbcConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the select command
      cmmUserSelect = New OdbcCommand(STR_SQL_USER_SELECT, cnnUserMan)

      ' Instantiate data adapter
      dadUserMan = New OdbcDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
      ' Set data adapter select command property
      dadUserMan.SelectCommand = cmmUserSelect
   End Sub
End Module