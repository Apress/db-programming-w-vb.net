Option Strict On

Imports eInfoDesigns.dbProvider.MySqlClient
Imports System.Xml
Imports System.IO

Module General
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.32;" & _
      "User ID=UserMan;Password=userman;Database=UserMan"

   ' Listing 8-1
   Public Sub InstantiateAndInitializeDataAdapter()
      Const STR_SQL_USER As String = "SELECT * FROM tblUser"

      Dim cnnUserMan As MySqlConnection
      Dim cmmUser As MySqlCommand
      Dim dadDefaultConstructor As MySqlDataAdapter

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command
      cmmUser = New MySqlCommand(STR_SQL_USER)

      ' Instantiate data adapters
      dadDefaultConstructor = New MySqlDataAdapter()
      ' Initialize data adapters
      dadDefaultConstructor.SelectCommand = cmmUser
      dadDefaultConstructor.SelectCommand.Connection = cnnUserMan
   End Sub

   ' Listing 8-2
   Public Sub SetDataAdapterCommandProperties()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
      Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=@Id"
      Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(ADName, ADSID, " & _
         "FirstName, LastName, LoginName, Password) VALUES(@ADName, @ADSID, " & _
         "@FirstName, @LastName, @LoginName, @Password)"
      Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET ADName=@ADName, " & _
         "ADSID=@ADSID, FirstName=@FirstName, LastName=@LastName, " & _
         "LoginName=@LoginName, Password=@Password WHERE Id=@Id"

      Dim cnnUserMan As MySqlConnection
      Dim cmmUserSelect As MySqlCommand
      Dim cmmUserDelete As MySqlCommand
      Dim cmmUserInsert As MySqlCommand
      Dim cmmUserUpdate As MySqlCommand
      Dim dadUserMan As MySqlDataAdapter
      Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As MySqlParameter

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the commands
      cmmUserSelect = New MySqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
      cmmUserDelete = New MySqlCommand(STR_SQL_USER_DELETE, cnnUserMan)
      cmmUserInsert = New MySqlCommand(STR_SQL_USER_INSERT, cnnUserMan)
      cmmUserUpdate = New MySqlCommand(STR_SQL_USER_UPDATE, cnnUserMan)

      ' Instantiate and initialize data adapter
      dadUserMan = New MySqlDataAdapter()
      dadUserMan.SelectCommand = cmmUserSelect
      dadUserMan.SelectCommand.Connection = cnnUserMan
      ' Set data adapter command properties
      dadUserMan.SelectCommand = cmmUserSelect
      dadUserMan.InsertCommand = cmmUserInsert
      dadUserMan.DeleteCommand = cmmUserDelete
      dadUserMan.UpdateCommand = cmmUserUpdate

      ' Add Delete command parameters
      prmSQLDelete = New MySqlParameter("@Id", DbType.Int32, "Id")
      prmSQLDelete.Direction = ParameterDirection.Input
      prmSQLDelete.SourceVersion = DataRowVersion.Original
      dadUserMan.DeleteCommand.Parameters.Add(prmSQLDelete)

      ' Add Update command parameters
      prmSQLUpdate = New MySqlParameter("@ADName", DbType.String, "ADName")
      cmmUserUpdate.Parameters.Add(prmSQLUpdate)
      prmSQLUpdate = New MySqlParameter("@ADSID", DbType.String, "ADSID")
      cmmUserUpdate.Parameters.Add(prmSQLUpdate)
      prmSQLUpdate = New MySqlParameter("@FirstName", DbType.String, "FirstName")
      cmmUserUpdate.Parameters.Add(prmSQLUpdate)
      prmSQLUpdate = New MySqlParameter("@LastName", DbType.String, "LastName")
      cmmUserUpdate.Parameters.Add(prmSQLUpdate)
      prmSQLUpdate = New MySqlParameter("@LoginName", DbType.String, "LoginName")
      cmmUserUpdate.Parameters.Add(prmSQLUpdate)
      prmSQLUpdate = New MySqlParameter("@Password", DbType.String, "Password")
      cmmUserUpdate.Parameters.Add(prmSQLUpdate)
      prmSQLUpdate = New MySqlParameter("@Id", DbType.Int32, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original
      cmmUserUpdate.Parameters.Add(prmSQLUpdate)

      ' Add insert command parameters
      prmSQLInsert = New MySqlParameter("@ADName", DbType.String, "ADName")
      cmmUserUpdate.Parameters.Add(prmSQLInsert)
      prmSQLInsert = New MySqlParameter("@ADSID", DbType.String, "ADSID")
      cmmUserUpdate.Parameters.Add(prmSQLInsert)
      prmSQLInsert = New MySqlParameter("@FirstName", DbType.String, "FirstName")
      cmmUserUpdate.Parameters.Add(prmSQLInsert)
      prmSQLInsert = New MySqlParameter("@LastName", DbType.String, "LastName")
      cmmUserUpdate.Parameters.Add(prmSQLInsert)
      prmSQLInsert = New MySqlParameter("@LoginName", DbType.String, "LoginName")
      cmmUserUpdate.Parameters.Add(prmSQLInsert)
      prmSQLInsert = New MySqlParameter("@Password", DbType.String, "Password")
      cmmUserUpdate.Parameters.Add(prmSQLInsert)
   End Sub

   ' Listing 8-5
   Public Sub GetSelectParameters()
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser WHERE LoginName=@LoginName"

      Dim cnnUserMan As MySqlConnection
      Dim cmmUserSelect As MySqlCommand
      Dim dadUserMan As MySqlDataAdapter
      Dim prmSQLSelect As MySqlParameter
      Dim arrprmSelect() As Object
      Dim prmSelect As MySqlParameter

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the select command
      cmmUserSelect = New MySqlCommand(STR_SQL_USER_SELECT, cnnUserMan)

      ' Instantiate and initialize data adapter
      dadUserMan = New MySqlDataAdapter()
      ' Set data adapter select command property
      dadUserMan.SelectCommand = cmmUserSelect
      dadUserMan.SelectCommand.Connection = cnnUserMan

      ' Add Select command parameter
      prmSQLSelect = New MySqlParameter("@LoginName", DbType.String, "LoginName")
      prmSQLSelect.Direction = ParameterDirection.Input
      prmSQLSelect.SourceVersion = DataRowVersion.Current
      prmSQLSelect.Value = "UserMan"
      dadUserMan.SelectCommand.Parameters.Add(prmSQLSelect)
      ' Retrieve select statement parameters
      arrprmSelect = dadUserMan.GetFillParameters()

      ' Loop through all the parameters
      For Each prmSelect In arrprmSelect
         ' Display some of the properties
         MsgBox("Name = " & prmSelect.ParameterName & vbCrLf & _
            "Value = " & prmSQLSelect.Value.ToString & vbCrLf & _
            "DB Data Type = " & prmSQLSelect.DbType.ToString & vbCrLf & _
            "Parameter Type = " & prmSQLSelect.Direction.ToString)
      Next
   End Sub

   ' Listing 8-6
   Public Sub GetSimpleTableSchema()
      Const STR_SQL_USER_SELECT_ALL As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As MySqlConnection
      Dim dadUserMan As MySqlDataAdapter
      Dim dtbUser As New DataTable()
      Dim dtcUser As DataColumn

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate and initialize data adapter
      dadUserMan = New MySqlDataAdapter()
      dadUserMan.SelectCommand = New MySqlCommand(STR_SQL_USER_SELECT_ALL)
      dadUserMan.SelectCommand.Connection = cnnUserMan
      ' Retrieve table schema from data source
      dadUserMan.FillSchema(dtbUser, SchemaType.Source)

      ' Loop through all the columns in the data table
      For Each dtcUser In dtbUser.Columns
         ' Display the name of the column
         MsgBox(dtcUser.ColumnName)
      Next
   End Sub

   ' Listing 8-7
   Public Sub GetTableSchema()
      Const STR_SQL_USER_SELECT_LOG As String = _
         "SELECT * FROM tblLog"
      Const STR_SQL_USER_SELECT_USER As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As MySqlConnection
      Dim dadUserMan As MySqlDataAdapter
      Dim dstUserMan As New DataSet("UserMan")
      Dim dtbSchema() As DataTable
      Dim dtbUser As DataTable

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate and initialize data adapter
      dadUserMan = New MySqlDataAdapter()
      dadUserMan.SelectCommand = New MySqlCommand(STR_SQL_USER_SELECT_LOG)
      dadUserMan.SelectCommand.Connection = cnnUserMan
      ' Populate the DataSet with the Log table
      dadUserMan.Fill(dstUserMan, "tblLog")
      ' Set the Command text to retrieve from User table
      dadUserMan.SelectCommand.CommandText = _
         STR_SQL_USER_SELECT_USER
      ' Retrieve table schema from data source
      dtbSchema = dadUserMan.FillSchema(dstUserMan, _
         SchemaType.Source)

      ' Display the name of the tables that
      ' had a schema returned
      For Each dtbUser In dtbSchema
         MsgBox(dtbUser.TableName, MsgBoxStyle.OKOnly, _
            "DataTable Array Reference")
      Next

      ' Display the name of the tables in
      ' the DataSet
      For Each dtbUser In dstUserMan.Tables
         MsgBox(dtbUser.TableName, MsgBoxStyle.OKOnly, _
            "DataSet Tables")
      Next
   End Sub

   ' Listing 8-8
   Public Sub GetFullTableSchema()
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As MySqlConnection
      Dim dadUserMan As MySqlDataAdapter
      Dim dstUserMan As New DataSet("UserMan")
      Dim dtbSchema() As DataTable
      Dim dtbUser As DataTable

      ' Instantiate the connection
      cnnUserMan = New MySqlConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate and initialize data adapter
      dadUserMan = New MySqlDataAdapter()
      dadUserMan.SelectCommand = New MySqlCommand(STR_SQL_USER_SELECT)
      dadUserMan.SelectCommand.Connection = cnnUserMan
      ' Retrieve table schema from data source
      dtbSchema = dadUserMan.FillSchema(dstUserMan, _
         SchemaType.Source, "tblUser")

      ' Display the name of the tables
      For Each dtbUser In dtbSchema
         MsgBox(dtbUser.TableName)
      Next
   End Sub
End Module