Imports eInfoDesigns.dbProvider.MySqlClient

Public Class CGeneral
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.32;" & _
      "User ID=UserMan;Password=userman;Database=UserMan"

   ' Listing 8-4-1
   Private Shared Sub OnFillError(ByVal sender As Object, _
      ByVal args As FillErrorEventArgs)
      ' Display a message indicating what table an error occurred in and
      ' let the user decided whether to continue populating the dataset
      args.Continue = (MsgBox("There were errors filling the Data Table: " & _
         args.DataTable.ToString & ". Do you want to continue?", _
         MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Continue Updating") _
         = DialogResult.Yes)
   End Sub

   ' Listing 8-4-2
   Public Shared Sub TriggerFillErrorEvent()
      Dim dstUser As New DataSet("Users")
      ' Declare and instantiate connection
      Dim cnnUserMan As New MySqlConnection(PR_STR_CONNECTION_STRING)
      ' Declare and instantiate data adapter
      Dim prdadUserMan As New MySqlDataAdapter()
      prdadUserMan.SelectCommand = New MySqlCommand("SELECT * FROM tblUser")
      prdadUserMan.SelectCommand.Connection = cnnUserMan
      ' Set up event handler
      AddHandler prdadUserMan.FillError, AddressOf OnFillError

      ' Populate the dataset
      prdadUserMan.Fill(dstUser, "tblUser")
   End Sub
End Class