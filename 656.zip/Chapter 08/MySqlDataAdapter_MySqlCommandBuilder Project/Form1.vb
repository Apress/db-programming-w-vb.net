Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnInstantiateDataAdapterObject As System.Windows.Forms.Button
   Friend WithEvents btnSetDataAdapterCommandProperties As System.Windows.Forms.Button
   Friend WithEvents btnGetSelectParameters As System.Windows.Forms.Button
   Friend WithEvents btnGetTableSchema As System.Windows.Forms.Button
   Friend WithEvents btnTriggerFillErrorEvent As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnInstantiateDataAdapterObject = New System.Windows.Forms.Button()
      Me.btnSetDataAdapterCommandProperties = New System.Windows.Forms.Button()
      Me.btnGetSelectParameters = New System.Windows.Forms.Button()
      Me.btnGetTableSchema = New System.Windows.Forms.Button()
      Me.btnTriggerFillErrorEvent = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnInstantiateDataAdapterObject
      '
      Me.btnInstantiateDataAdapterObject.Location = New System.Drawing.Point(15, 42)
      Me.btnInstantiateDataAdapterObject.Name = "btnInstantiateDataAdapterObject"
      Me.btnInstantiateDataAdapterObject.Size = New System.Drawing.Size(269, 28)
      Me.btnInstantiateDataAdapterObject.TabIndex = 1
      Me.btnInstantiateDataAdapterObject.Text = "Instantiate DataAdapter Object"
      '
      'btnSetDataAdapterCommandProperties
      '
      Me.btnSetDataAdapterCommandProperties.Location = New System.Drawing.Point(15, 76)
      Me.btnSetDataAdapterCommandProperties.Name = "btnSetDataAdapterCommandProperties"
      Me.btnSetDataAdapterCommandProperties.Size = New System.Drawing.Size(269, 29)
      Me.btnSetDataAdapterCommandProperties.TabIndex = 2
      Me.btnSetDataAdapterCommandProperties.Text = "Set DataAdapter Command Properties"
      '
      'btnGetSelectParameters
      '
      Me.btnGetSelectParameters.Location = New System.Drawing.Point(15, 146)
      Me.btnGetSelectParameters.Name = "btnGetSelectParameters"
      Me.btnGetSelectParameters.Size = New System.Drawing.Size(269, 28)
      Me.btnGetSelectParameters.TabIndex = 4
      Me.btnGetSelectParameters.Text = "Get Select Parameters"
      '
      'btnGetTableSchema
      '
      Me.btnGetTableSchema.Location = New System.Drawing.Point(15, 180)
      Me.btnGetTableSchema.Name = "btnGetTableSchema"
      Me.btnGetTableSchema.Size = New System.Drawing.Size(269, 29)
      Me.btnGetTableSchema.TabIndex = 5
      Me.btnGetTableSchema.Text = "Get Table Schema"
      '
      'btnTriggerFillErrorEvent
      '
      Me.btnTriggerFillErrorEvent.Location = New System.Drawing.Point(15, 111)
      Me.btnTriggerFillErrorEvent.Name = "btnTriggerFillErrorEvent"
      Me.btnTriggerFillErrorEvent.Size = New System.Drawing.Size(269, 28)
      Me.btnTriggerFillErrorEvent.TabIndex = 3
      Me.btnTriggerFillErrorEvent.Text = "Trigger FillError Event"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
      Me.ClientSize = New System.Drawing.Size(299, 223)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnTriggerFillErrorEvent, Me.btnGetTableSchema, Me.btnGetSelectParameters, Me.btnSetDataAdapterCommandProperties, Me.btnInstantiateDataAdapterObject})
      Me.Name = "Form1"
      Me.Text = "MySqlDataAdapter_MySqlCommandBuilder Project"
      Me.ResumeLayout(False)

   End Sub

#End Region


   Private Sub btnInstantiateDataReaderObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataAdapterObject.Click
      InstantiateAndInitializeDataAdapter()
   End Sub

   Private Sub btnSetDataAdapterCommandProperties_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetDataAdapterCommandProperties.Click
      SetDataAdapterCommandProperties()
      'SetDataAdapterCommandPropertiesUsingCommandBuilder()
   End Sub

   Private Sub btnGetSelectParameters_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetSelectParameters.Click
      GetSelectParameters()
   End Sub

   Private Sub btnGetTableSchema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetTableSchema.Click
      'GetSimpleTableSchema()
      'GetTableSchema()
      GetFullTableSchema()
   End Sub

   Private Sub btnTriggerFillErrorEvent_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTriggerFillErrorEvent.Click
      CGeneral.TriggerFillErrorEvent()
   End Sub
End Class