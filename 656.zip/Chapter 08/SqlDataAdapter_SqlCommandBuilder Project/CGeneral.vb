Imports System.Data.SqlClient

Public Class CGeneral
   Private Const PR_STR_CONNECTION_STRING As String = "Address=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   ' Listing 8-4-1
   Private Shared Sub OnFillError(ByVal sender As Object, _
      ByVal args As FillErrorEventArgs)
      ' Display a message indicating what table an error occurred in and
      ' let the user decided whether to continue populating the dataset
      args.Continue = (MsgBox("There were errors filling the Data Table: " & _
         args.DataTable.ToString & ". Do you want to continue?", _
         MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Continue Updating") _
         = DialogResult.Yes)
   End Sub

   ' Listing 8-4-2
   Public Shared Sub TriggerFillErrorEvent()
      Dim dstUser As New DataSet("Users")
      ' Declare and instantiate connection
      Dim cnnUserMan As New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Declare and instantiate data adapter
      Dim prdadUserMan As New SqlDataAdapter("SELECT * FROM tblUser", _
         cnnUserMan)
      ' Set up event handler
      AddHandler prdadUserMan.FillError, AddressOf OnFillError

      ' Populate the dataset
      prdadUserMan.Fill(dstUser, "tblUser")
   End Sub

   ' Listing 8-9-1
   Protected Shared Sub OnRowUpdating(ByVal sender As Object, _
      ByVal e As SqlRowUpdatingEventArgs)
      ' Display a message showing all the Command properties
      ' if a command exists
      If Not e.Command Is Nothing Then
         MessageBox.Show("Command Properties:" & vbCrLf & _
            vbCrLf & "CommandText: " & _
            e.Command.CommandText & vbCrLf & _
            "CommandTimeout: " & _
            e.Command.CommandTimeout.ToString() & _
            vbCrLf & "CommandType: " & _
            e.Command.CommandType.ToString(), _
            "RowUpdating", MessageBoxButtons.OK, _
            MessageBoxIcon.Information)
      End If
      ' Display a message showing all the Errors properties, 
      ' if an error exists
      If Not e.Errors Is Nothing Then
         MessageBox.Show("Errors Properties:" & vbCrLf & _
            vbCrLf & "HelpLink: " & e.Errors.HelpLink & _
            vbCrLf & "Message: " & e.Errors.Message & _
            vbCrLf & "Source: " & e.Errors.Source & _
            vbCrLf & "StackTrace: " & _
            e.Errors.StackTrace & vbCrLf & _
            "TargetSite: " & _
            e.Errors.TargetSite.ToString, _
            "RowUpdating", MessageBoxButtons.OK, _
            MessageBoxIcon.Information)
      End If
      ' Display a message showing other misc. properties
      MessageBox.Show("Misc. Properties:" & vbCrLf & _
         vbCrLf & "StatementType: " & _
         e.StatementType.ToString & vbCrLf & _
         "Status: " & e.Status.ToString, _
         "RowUpdating", MessageBoxButtons.OK, _
         MessageBoxIcon.Information)
   End Sub

   ' Listing 8-9-2
   Protected Shared Sub OnRowUpdated(ByVal sender As Object, _
      ByVal e As SqlRowUpdatedEventArgs)
      ' Display a message showing all the Command properties
      ' if a command exists
      If Not e.Command Is Nothing Then
         MessageBox.Show("Command Properties:" & vbCrLf & _
            vbCrLf & "CommandText: " & _
            e.Command.CommandText & vbCrLf & _
            "CommandTimeout: " & _
            e.Command.CommandTimeout.ToString() & _
            vbCrLf & "CommandType: " & _
            e.Command.CommandType.ToString(), _
            "RowUpdated", MessageBoxButtons.OK, _
            MessageBoxIcon.Information)
      End If
      ' Display a message showing all the Errors properties, 
      ' if an error exists
      If Not e.Errors Is Nothing Then
         MessageBox.Show("Errors Properties:" & vbCrLf & _
            vbCrLf & "HelpLink: " & e.Errors.HelpLink & _
            vbCrLf & "Message: " & e.Errors.Message & _
            vbCrLf & "Source: " & e.Errors.Source & _
            vbCrLf & "StackTrace: " & _
            e.Errors.StackTrace & vbCrLf & _
            "TargetSite: " & _
            e.Errors.TargetSite.ToString, _
            "RowUpdated", MessageBoxButtons.OK, _
            MessageBoxIcon.Information)
      End If
      ' Display a message showing other misc. properties
      MessageBox.Show("Misc. Properties:" & vbCrLf & _
         vbCrLf & "StatementType: " & _
         e.StatementType.ToString & vbCrLf & _
         "Status: " & e.Status.ToString, _
         "RowUpdated", MessageBoxButtons.OK, _
         MessageBoxIcon.Information)
   End Sub

   ' Listing 8-9-3
   Public Shared Sub TriggerRowUpdateEvents()
      Dim dstUser As New DataSet("Users")
      ' Declare and instantiate connection
      Dim cnnUserMan As New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Declare and instantiate data adapter
      Dim dadUserMan As New SqlDataAdapter("SELECT * FROM tblUser", _
         cnnUserMan)
      ' Declare and instantiate command builder
      Dim cmbUser As New SqlCommandBuilder(dadUserMan)
      ' Set up event handlers
      AddHandler dadUserMan.RowUpdating, AddressOf OnRowUpdating
      AddHandler dadUserMan.RowUpdated, AddressOf OnRowUpdated

      ' Populate the dataset
      dadUserMan.Fill(dstUser, "tblUser")
      ' Modify second row
      dstUser.Tables("tblUser").Rows(1)("FirstName") = "Tom"
      ' Populate the data source
      dadUserMan.Update(dstUser, "tblUser")
   End Sub
End Class