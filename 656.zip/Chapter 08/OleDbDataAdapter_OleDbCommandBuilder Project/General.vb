Option Strict On

Imports System.Data.OleDb
Imports System.Xml
Imports ADODB
Imports System.IO

'#Const Oracle = 1
'#Const DB2 = 1
'#Const MSAccess = 1
#Const SQLSERVER = 1
' You simply uncomment the line above for the DBMS you want to use

Module General
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = "Provider=SQLOLEDB;Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
#ElseIf MSAccess Then
   ' This connection string os for connecting to an Access mdb
   ' I'm not using any security, hence the blank User Id and password. I'm also
   ' Opening the mdb in shared mode. You must edit the path to your database file
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\DBPWVBNET\UserMan.mdb;" & _
      "Mode=Share Deny None;"
#ElseIf Oracle Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
	Private Const PR_STR_CONNECTION_STRING as String  = _
		"Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#ElseIf DB2 Then
	' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Listing 8-1
   Public Sub InstantiateAndInitializeDataAdapter()
      Const STR_SQL_USER As String = "SELECT * FROM tblUser"

      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim dadDefaultConstructor As OleDbDataAdapter
      Dim dadOleDbCommandArgument As OleDbDataAdapter
      Dim dadOleDbConnectionArgument As OleDbDataAdapter
      Dim dadStringArguments As OleDbDataAdapter

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the command
      cmmUser = New OleDbCommand(STR_SQL_USER)

      ' Instantiate data adapters
      dadDefaultConstructor = New OleDbDataAdapter()
      dadOleDbCommandArgument = New OleDbDataAdapter(cmmUser)
      dadOleDbConnectionArgument = New OleDbDataAdapter(STR_SQL_USER, cnnUserMan)
      dadStringArguments = New OleDbDataAdapter(STR_SQL_USER, PR_STR_CONNECTION_STRING)
      ' Initialize data adapters
      dadDefaultConstructor.SelectCommand = cmmUser
      dadDefaultConstructor.SelectCommand.Connection = cnnUserMan
   End Sub

   ' Listing 8-3
   Public Sub SetDataAdapterCommandProperties()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"
      Const STR_SQL_USER_DELETE As String = "DELETE FROM tblUser WHERE Id=?"
      Const STR_SQL_USER_INSERT As String = "INSERT INTO tblUser(ADName, " & _
         "ADSID, FirstName, LastName, LoginName, Password) " & _
         "VALUES(?, ?, ?, ?, ?, ?)"
      Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser SET ADName=?, " & _
         "ADSID=?, FirstName=?, LastName=?, LoginName=?, Password=? WHERE Id=?"

      Dim cnnUserMan As OleDbConnection
      Dim cmmUserSelect As OleDbCommand
      Dim cmmUserDelete As OleDbCommand
      Dim cmmUserInsert As OleDbCommand
      Dim cmmUserUpdate As OleDbCommand
      Dim dadUserMan As OleDbDataAdapter
      Dim prmSQLDelete, prmSQLUpdate, prmSQLInsert As OleDbParameter

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the commands
      cmmUserSelect = New OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan)
      cmmUserDelete = New OleDbCommand(STR_SQL_USER_DELETE, cnnUserMan)
      cmmUserInsert = New OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan)
      cmmUserUpdate = New OleDbCommand(STR_SQL_USER_UPDATE, cnnUserMan)

      ' Instantiate data adapter
      dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
      ' Set data adapter command properties
      dadUserMan.SelectCommand = cmmUserSelect
      dadUserMan.InsertCommand = cmmUserInsert
      dadUserMan.DeleteCommand = cmmUserDelete
      dadUserMan.UpdateCommand = cmmUserUpdate

      ' Add Delete command parameters
      prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", _
         OleDbType.Integer, Nothing, "Id")
      prmSQLDelete.Direction = ParameterDirection.Input
      prmSQLDelete.SourceVersion = DataRowVersion.Original

      ' Add Update command parameters
      cmmUserUpdate.Parameters.Add("@ADName", OleDbType.VarChar, 100, _
         "ADName")
      cmmUserUpdate.Parameters.Add("@ADSID", OleDbType.VarChar, 50, _
         "ADSID")
      cmmUserUpdate.Parameters.Add("@FirstName", OleDbType.VarChar, 50, _
         "FirstName")
      cmmUserUpdate.Parameters.Add("@LastName", OleDbType.VarChar, 50, _
         "LastName")
      cmmUserUpdate.Parameters.Add("@LoginName", OleDbType.VarChar, 50, _
         "LoginName")
      cmmUserUpdate.Parameters.Add("@Password", OleDbType.VarChar, 50, _
         "Password")

      prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", _
         OleDbType.Integer, Nothing, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original

      ' Add insert command parameters
      cmmUserInsert.Parameters.Add("@ADName", OleDbType.VarChar, 100, _
         "ADName")
      cmmUserInsert.Parameters.Add("@ADSID", OleDbType.VarChar, 50, _
         "ADSID")
      cmmUserInsert.Parameters.Add("@FirstName", OleDbType.VarChar, 50, _
         "FirstName")
      cmmUserInsert.Parameters.Add("@LastName", OleDbType.VarChar, 50, _
         "LastName")
      cmmUserInsert.Parameters.Add("@LoginName", OleDbType.VarChar, 50, _
         "LoginName")
      cmmUserInsert.Parameters.Add("@Password", OleDbType.VarChar, 50, _
         "Password")
   End Sub

   ' Listing 8-5
   Public Sub GetSelectParameters()
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser WHERE LoginName=@LoginName"

      Dim cnnUserMan As OleDbConnection
      Dim cmmUserSelect As OleDbCommand
      Dim dadUserMan As OleDbDataAdapter
      Dim prmSQLSelect As OleDbParameter
      Dim arrprmSelect() As Object
      Dim prmSelect As OleDbParameter

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the select command
      cmmUserSelect = New OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan)

      ' Instantiate data adapter
      dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
      ' Set data adapter select command property
      dadUserMan.SelectCommand = cmmUserSelect

      ' Add Select command parameter
      prmSQLSelect = dadUserMan.SelectCommand.Parameters.Add("@LoginName", _
         OleDbType.VarChar, 50, "LoginName")
      prmSQLSelect.Direction = ParameterDirection.Input
      prmSQLSelect.SourceVersion = DataRowVersion.Current
      prmSQLSelect.Value = "UserMan"
      ' Retrieve select statement parameters
      arrprmSelect = dadUserMan.GetFillParameters()

      ' Loop through all the parameters
      For Each prmSelect In arrprmSelect
         ' Display some of the properties
         MsgBox("Name = " & prmSelect.ParameterName & vbCrLf & _
            "Value = " & prmSQLSelect.Value.ToString & vbCrLf & _
            "DB Data Type = " & prmSQLSelect.DbType.ToString & vbCrLf & _
            "Parameter Type = " & prmSQLSelect.Direction.ToString)
      Next
   End Sub

   ' Listing 8-6
   Public Sub GetSimpleTableSchema()
      ' Doesn't work with MS Access
#If Not MSAccess Then
      Const STR_SQL_USER_SELECT_ALL As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As OleDbConnection
      Dim dadUserMan As OleDbDataAdapter
      Dim dtbUser As New DataTable()
      Dim dtcUser As DataColumn

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate data adapter
      dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT_ALL, _
         cnnUserMan)
      ' Retrieve table schema from data source
      dadUserMan.FillSchema(dtbUser, SchemaType.Source)

      ' Loop through all the columns in the data table
      For Each dtcUser In dtbUser.Columns
         ' Display the name of the column
         MsgBox(dtcUser.ColumnName)
      Next
#End If
   End Sub

   ' Listing 8-7
   Public Sub GetTableSchema()
      Const STR_SQL_USER_SELECT_LOG As String = _
         "SELECT * FROM tblLog"
      Const STR_SQL_USER_SELECT_USER As String = _
         "SELECT * FROM tblUser"

      Dim cnnUserMan As OleDbConnection
      Dim dadUserMan As OleDbDataAdapter
      Dim dstUserMan As New DataSet("UserMan")
      Dim dtbSchema() As DataTable
      Dim dtbUser As DataTable

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate data adapter
      dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT_LOG, _
         cnnUserMan)
      ' Populate the DataSet with the Log table
      dadUserMan.Fill(dstUserMan, "tblLog")
      ' Set the 
      dadUserMan.SelectCommand.CommandText = _
         STR_SQL_USER_SELECT_USER
      ' Retrieve table schema from data source
      dtbSchema = dadUserMan.FillSchema(dstUserMan, _
         SchemaType.Source)

      ' Display the name of the tables that
      ' had a schema returned
      For Each dtbUser In dtbSchema
         MsgBox(dtbUser.TableName, MsgBoxStyle.OKOnly, "DataTable Array Reference")
      Next

      ' Display the name of the tables in
      ' the DataSet
      For Each dtbUser In dstUserMan.Tables
         MsgBox(dtbUser.TableName, MsgBoxStyle.OKOnly, "DataSet Tables")
      Next
   End Sub

   ' Listing 8-8
   Public Sub GetFullTableSchema()
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser;SELECT * FROM tblLog"

      Dim cnnUserMan As OleDbConnection
      Dim dadUserMan As OleDbDataAdapter
      Dim dstUserMan As New DataSet("UserMan")
      Dim dtbSchema() As DataTable
      Dim dtbUser As DataTable

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)

      ' Instantiate data adapter
      dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, _
         cnnUserMan)
      ' Retrieve table schema from data source
      dtbSchema = dadUserMan.FillSchema(dstUserMan, _
         SchemaType.Source, "tblUser")

      ' Display the name of the tables
      For Each dtbUser In dtbSchema
         MsgBox(dtbUser.TableName)
      Next
   End Sub

   ' Listing 8-10
   Public Sub SetDataAdapterCommandPropertiesUsingCommandBuilder()
      Const STR_SQL_USER_SELECT As String = "SELECT * FROM tblUser"

      Dim cnnUserMan As OleDbConnection
      Dim cmmUserSelect As OleDbCommand
      Dim dadUserMan As OleDbDataAdapter
      Dim cmbUser As New OleDbCommandBuilder(dadUserMan)

      ' Instantiate the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate the select command
      cmmUserSelect = New OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan)

      ' Instantiate data adapter
      dadUserMan = New OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan)
      ' Set data adapter select command property
      dadUserMan.SelectCommand = cmmUserSelect
   End Sub
End Module