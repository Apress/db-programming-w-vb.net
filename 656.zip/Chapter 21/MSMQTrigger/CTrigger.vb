' Listing 21-37
Imports System.Data.SqlClient

Public Class CTrigger
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   Public Sub DeleteRows(ByVal LastName As String)
      Dim cnnUserMan As SqlConnection
      Dim cmmUserMan As SqlCommand
      Dim strSQL As String

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Open the connection
      cnnUserMan.Open()
      ' Build delete query string
      strSQL = "DELETE FROM tblUser WHERE LastName='" & LastName & "'"
      ' Instantiate and execute the delete command
      cmmUserMan = New SqlCommand(strSQL, cnnUserMan)
      cmmUserMan.ExecuteNonQuery()
   End Sub
End Class