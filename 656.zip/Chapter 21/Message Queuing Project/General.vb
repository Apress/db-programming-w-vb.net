Imports System.Messaging
Imports System.ComponentModel
Imports MSMQ

Module General
   ' Listing 21-1
   Public Sub CreatePrivateQueueWithName()
      MessageQueue.Create("USERMANPC\Private$\UserMan")
   End Sub

   ' Listing 21-2
   Public Sub CreatePrivateQueue()
      MessageQueue.Create(".\Private$\UserMan")
   End Sub

   ' Listing 21-3
   Public Sub CreatePublicQueue()
      MessageQueue.Create(".\UserMan")
   End Sub

   ' Listing 21-4
   Public Sub CreateTransactionalPrivateQueue()
      MessageQueue.Create(".\Private$\UserMan", True)
   End Sub

   ' Listing 21-5
   Public Sub ChangeQueueLabel()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")

      queUserMan.Label = "USERMAN1"
   End Sub

   ' Listing 21-6
   Public Sub RetrieveQueueId()
      Dim queUserMan As New MessageQueue(".\UserMan")
      Dim uidMessageQueue As Guid

      uidMessageQueue = queUserMan.Id
   End Sub

   ' Listing 21-7
   Public Sub BindToExistingQueue()
      Dim queUserManNoArguments As New MessageQueue()
      Dim queUserManPath As New _
         MessageQueue(".\Private$\UserMan")
      Dim queUserManPathAndAccess As New _
         MessageQueue(".\Private$\UserMan", True)

      ' Initialize the queue
      queUserManNoArguments.Path = ".\Private$\UserMan"
   End Sub

   ' Listing 21-8
   Public Sub BindToExistingQueueUsingFormat()
      Dim queUserManFormatTCP As New _
         MessageQueue("FormatName:DIRECT=TCP:10.8.1.18\Private$\UserMan")
      Dim queUserManFormatOS As New _
         MessageQueue("FormatName:DIRECT=OS:USERMANPC\UserMan")
      Dim queUserManFormatPublic As New _
         MessageQueue( _
         "FormatName:Public=AB6B9EF6-B167-43A4-8116-5B72D5C1F81C")
   End Sub

   ' Listing 21-9
   Public Sub BindToExistingQueueUsingLabel()
      Dim queUserManLabel As New MessageQueue("Label:Userman")
   End Sub

   ' Listing 21-10
   Public Sub SendSimpleMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")

      ' Send simple message to queue
      queUserMan.Send("Test")
   End Sub

   ' Listing 21-11
   Public Sub RetrieveSimpleMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As Message

      ' Retrieve first message from queue
      msgUserMan = queUserMan.Receive()
   End Sub

   ' Listing 21-12
   Public Sub RetrieveMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As Message
      Dim strBody As String

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

      ' Retrieve first message from queue
      msgUserMan = queUserMan.Receive
      ' Save the message body
      strBody = msgUserMan.Body.ToString
   End Sub

   ' Listing 21-13-1
   Public Sub SendDifferentMessages()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String), GetType(Integer)})

      ' Create body as a text message
      msgUserMan.Body = "Test"
      ' Send message to queue
      queUserMan.Send(msgUserMan)
      ' Create body as an integer
      msgUserMan.Body = 12
      ' Send message to queue
      queUserMan.Send(msgUserMan)
   End Sub

   ' Listing 21-13-2
   Public Sub RetrieveDifferentMessages()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As Message
      Dim strBody As String
      Dim intBody As Integer

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String), GetType(Integer)})

      ' Retrieve first message from queue
      msgUserMan = queUserMan.Receive
      ' Save the message body
      strBody = msgUserMan.Body.ToString
      ' Retrieve next message from queue
      msgUserMan = queUserMan.Receive
      ' Save the message body
      intBody = msgUserMan.Body
   End Sub

   ' Listing 21-14
   Public Sub PeekMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As Message
      Dim strBody As String

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Peek first message from queue
      msgUserMan = queUserMan.Peek
      ' Save the message body
      strBody = msgUserMan.Body.ToString
   End Sub

   ' Listing 21-15
   Public Sub RetrieveMessageById()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()
      Dim strId As String

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

      ' Create body as a text message
      msgUserMan.Body = "Test 1"
      ' Send message to queue
      queUserMan.Send(msgUserMan)

      ' Create body as a text message
      msgUserMan.Body = "Test 2"
      ' Send message to queue
      queUserMan.Send(msgUserMan)
      strId = msgUserMan.Id

      ' Create body as a text message
      msgUserMan.Body = "Test 3"
      ' Send message to queue
      queUserMan.Send(msgUserMan)

      msgUserMan = queUserMan.ReceiveById(strId)
      MsgBox("Saved Id=" & strId & vbCrLf & "Retrieved Id=" & msgUserMan.Id)
   End Sub

   ' Listing 21-16
   Public Function RetrieveMessageByIdSafe(ByVal vstrId As String) As Message
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      Try
         msgUserMan = queUserMan.ReceiveById(vstrId)
      Catch objE As InvalidOperationException
         ' Message not found, return a Null value
         RetrieveMessageByIdSafe = Nothing

         Exit Function
      End Try

      ' Return message
      RetrieveMessageByIdSafe = msgUserMan
   End Function

   ' Listing 21-17-1
   Public Sub MessageReceiveCompleteEvent(ByVal vobjSource As Object, _
    ByVal vobjEventArgs As ReceiveCompletedEventArgs)
      Dim msgUserMan As New Message()
      Dim queUserMan As New MessageQueue()

      ' Make sure we bind to the right message queue
      queUserMan = CType(vobjSource, MessageQueue)

      ' End async receive
      msgUserMan = queUserMan.EndReceive(vobjEventArgs.AsyncResult)
   End Sub

   ' Listing 21-17-2
   Public Sub RetrieveMessagesAsync()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter(New Type() {GetType(String)})

      ' Add an event handler
      AddHandler queUserMan.ReceiveCompleted, AddressOf _
         MessageReceiveCompleteEvent

      queUserMan.BeginReceive(New TimeSpan(0, 0, 10))
   End Sub

   ' Listing 21-18-1
   Public Sub MessagePeekCompleteEvent(ByVal vobjSource As Object, _
    ByVal vobjEventArgs As PeekCompletedEventArgs)
      Dim msgUserMan As New Message()
      Dim queUserMan As New MessageQueue()

      ' Make sure we bind to the right message queue
      queUserMan = CType(vobjSource, MessageQueue)

      ' End async peek
      msgUserMan = queUserMan.EndPeek(vobjEventArgs.AsyncResult)
   End Sub

   ' Listing 21-18-2
   Public Sub PeekMessagesAsync()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Add an event handler
      AddHandler queUserMan.PeekCompleted, AddressOf _
         MessagePeekCompleteEvent

      queUserMan.BeginPeek(New TimeSpan(0, 0, 10))
   End Sub

   Public Sub ClearMessageQueue()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As Message

      ' Clear all messages from queue
      queUserMan.Purge()
   End Sub

   ' Listing 21-19-1
   Public Sub SendPriorityMessages()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgFirst As New Message()
      Dim msgSecond As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String), GetType(Integer)})

      ' Create first body 
      msgFirst.Body = "First Message"
      ' Send message to queue
      queUserMan.Send(msgFirst)

      ' Create second body 
      msgSecond.Body = "Second Message"
      ' Set priority to highest
      msgSecond.Priority = MessagePriority.Highest
      ' Send message to queue
      queUserMan.Send(msgSecond)
   End Sub

   ' Listing 21-19-2
   Public Sub RetrievePriorityMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As Message

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Retrieve first message from queue
      msgUserMan = queUserMan.Receive
      ' Display the message body
      MsgBox(msgUserMan.Body.ToString)
   End Sub

   Public Function CheckQueueExists(ByVal vstrPath As String) As Boolean
      CheckQueueExists = MessageQueue.Exists(vstrPath)
   End Function

   ' Listing 21-20
   Public Sub BrowsePrivateQueues()
      Dim arrquePrivate() As MessageQueue = _
         MessageQueue.GetPrivateQueuesByMachine("USERMANPC")
      Dim queUserMan As MessageQueue

      ' Display the path of all the private queues on the machine
      For Each queUserMan In arrquePrivate
         MsgBox(queUserMan.Path)
      Next
   End Sub

   Public Sub BrowsePublicQueuesMachineWide()
      Dim arrquePublic() As MessageQueue = _
         MessageQueue.GetPublicQueuesByMachine("USERMANPC")
      Dim queUserMan As MessageQueue

      ' Display the path of all the public queues on the machine
      For Each queUserMan In arrquePublic
         MsgBox(queUserMan.Path)
      Next
   End Sub

   ' Listing 21-21
   Public Sub BrowsePublicQueuesNetworkWide()
      Dim arrquePublic() As MessageQueue = _
         MessageQueue.GetPublicQueues()
      Dim queUserMan As MessageQueue

      ' Display the name of all the public queues on the network
      For Each queUserMan In arrquePublic
         MsgBox(queUserMan.QueueName)
      Next
   End Sub

   ' Listing 21-22
   Public Sub BrowsePublicQueuesByCategoryNetworkWide()
      Dim arrquePublic() As MessageQueue = _
         MessageQueue.GetPublicQueuesByCategory(New _
         Guid("00000000-0000-0000-0000-000000000001"))
      Dim queUserMan As MessageQueue

      ' Display the name of all the public queues 
      ' on the network within a specific category
      For Each queUserMan In arrquePublic
         MsgBox(queUserMan.QueueName)
      Next
   End Sub

   ' Listing 21-23
   Public Sub BrowsePublicQueuesByLabelNetworkWide()
      Dim arrquePublic() As MessageQueue = _
         MessageQueue.GetPublicQueuesByLabel("USERMAN")
      Dim queUserMan As MessageQueue

      ' Display the machine name for all the public queues 
      ' on the network with a specific label
      For Each queUserMan In arrquePublic
         MsgBox(queUserMan.MachineName)
      Next
   End Sub

   Public Sub RemoveMessageQueue(ByVal vstrPath As String)
      MessageQueue.Delete(vstrPath)
   End Sub

   ' Listing 21-24
   Public Sub RemoveMessageQueueSafely(ByVal vstrPath As String)
      Try
         MessageQueue.Delete(vstrPath)
      Catch objE As Exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 21-25
   Public Sub UseMQTransactions()
      Dim qtrUserMan As New MessageQueueTransaction()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Set up the queue formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Clear the message queue
      queUserMan.Purge()
      ' Start the transaction
      qtrUserMan.Begin()

      Try
         ' Create message body
         msgUserMan.Body = "First Message"
         ' Send message to queue
         queUserMan.Send(msgUserMan, qtrUserMan)

         ' Create message body
         msgUserMan.Body = "Second Message"
         ' Send message to queue
         queUserMan.Send(msgUserMan, qtrUserMan)

         ' Retrieve message from queue
         'msgUserMan = queUserMan.Receive(qtrUserMan)
         ' Display message body
         'MsgBox(msgUserMan.Body)

         ' Commit transaction
         qtrUserMan.Commit()

         ' Retrieve message from queue
         msgUserMan = queUserMan.Receive(qtrUserMan)
         ' Display message body
         MsgBox(msgUserMan.Body)

         ' Retrieve message from queue
         msgUserMan = queUserMan.Receive(qtrUserMan)
         ' Display message body
         MsgBox(msgUserMan.Body)
      Catch objE As Exception
         ' Abort the transaction
         qtrUserMan.Abort()
      End Try
   End Sub

   Public Sub EnableMQJournaling()
      Dim queUserMan As New MessageQueue("USERMANPC\UserMan")

      queUserMan.UseJournalQueue = True
   End Sub

   ' Listing 21-26
   Public Sub EnableMessageJournaling()
      Dim queUserMan As New MessageQueue("USERMANPC\UserMan")
      Dim queUserManJournal As New _
         MessageQueue("USERMANPC\UserMan\Journal$")
      Dim queSystemJournal As New MessageQueue(".\Journal$")
      Dim msgUserMan As New Message()

      ' Enable journaling on message queue
      queUserMan.UseJournalQueue = True

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Create message body 
      msgUserMan.Body = "Message"
      ' Enable message journaling
      msgUserMan.UseJournalQueue = True
      ' Send message to remote UserMan queue
      queUserMan.Send(msgUserMan)

      ' Retrieve message from remote UserMan queue
      msgUserMan = queUserMan.Receive()

      ' Retrieve message from local system journal
      msgUserMan = queSystemJournal.Receive()
      ' Retrieve message from remote UserMan journal
      msgUserMan = queUserManJournal.Receive()
   End Sub

   Public Sub RetrieveMessageFromQueueJournal()
      Dim queUserMan As New MessageQueue("USERMANPC\Journal$")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      Try
         ' Retrieve message from journal
         msgUserMan = queUserMan.Receive()
      Catch objE As Exception
         MsgBox(objE.Message)
      End Try
   End Sub

   Public Sub EnableQueueAuthentication()
      Dim queUserMan As New MessageQueue("USERMANPC\UserMan")

      ' Enable queue authentication
      queUserMan.Authenticate = True
   End Sub

   ' Listing 21-27
   Public Sub RejectNonauthenticatedMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Enable queue authentication
      queUserMan.Authenticate = True
      ' Set up the queue formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Create message body
      msgUserMan.Body = "Message Body"
      ' Make sure a rejected message is placed in 
      ' the dead-letter queue
      msgUserMan.UseDeadLetterQueue = True

      ' Send message to queue
      queUserMan.Send(msgUserMan)
   End Sub

   ' Listing 21-28
   Public Sub SendDeadLetterMessage()
      Dim queUserMan As New MessageQueue(".\UserMan")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Create message body 
      msgUserMan.Body = "Message"
      ' Set max time to be in queue
      msgUserMan.TimeToBeReceived = New TimeSpan(0, 0, 20)
      ' Make sure that a dead-letter ends up in 
      ' dead-letter queue
      msgUserMan.UseDeadLetterQueue = True
      ' Send message to queue
      queUserMan.Send(msgUserMan)
   End Sub

   Public Sub RetrieveMessageFromDeadLetterQueue()
      Dim queUserMan As New MessageQueue(".\DeadLetter$")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      Try
         ' Retrieve message from dead letter queue
         msgUserMan = queUserMan.Receive()
      Catch objE As Exception
         MsgBox(objE.Message)
      End Try
   End Sub

   ' Listing 21-29
   Public Sub PlaceNonauthenticatedMessageInAdminQueue()
      Dim queUserManAdmin As New MessageQueue( _
         ".\Private$\UserManAdmin")
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Enable queue authentication
      queUserMan.Authenticate = True
      ' Set up the queue formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Create message body
      msgUserMan.Body = "Message Body"
      ' Make sure a rejected message is placed in the admin queue
      msgUserMan.AdministrationQueue = queUserManAdmin
      ' These types of rejected messages
      msgUserMan.AcknowledgeType = _
         AcknowledgeTypes.NotAcknowledgeReachQueue

      ' Send message to queue
      queUserMan.Send(msgUserMan)
   End Sub

   ' Listing 21-30
   Public Sub AcceptAuthenticatedMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Enable queue authentication
      queUserMan.Authenticate = True
      ' Set up the queue formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Make sure a rejected message is placed in 
      ' the dead-letter queue
      msgUserMan.UseDeadLetterQueue = True
      ' Make sure that message queuing attaches the 
      ' sender id and is digitally signed before it is sent
      msgUserMan.UseAuthentication = True
      msgUserMan.AttachSenderId = True
      ' Create message body
      msgUserMan.Body = "Message Body"

      ' Send message to queue
      queUserMan.Send(msgUserMan)
   End Sub

   Public Sub EnableRequireBodyEncryption()
      Dim queUserMan As New MessageQueue("vb-joker-ws2\UserMan")
      Dim msgUserMan As New Message()

      ' Enable body encryption requirement
      queUserMan.EncryptionRequired = EncryptionRequired.Body
   End Sub

   ' Listing 21-31
   Public Sub SendAndReceiveEncryptedMessage()
      Dim queUserMan As New MessageQueue("USERMANPC\UserMan")
      Dim msgUserMan As New Message()

      ' Require message body encryption
      queUserMan.EncryptionRequired = EncryptionRequired.Body
      ' Set up the queue formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Make sure that message is encrypted before it is sent
      msgUserMan.UseEncryption = True
      ' Create message body
      msgUserMan.Body = "Message Body"

      ' Send message to queue
      queUserMan.Send(msgUserMan)

      ' Retrieve message from queue
      msgUserMan = queUserMan.Receive()
      ' Show decrypted message body
      MsgBox(msgUserMan.Body.ToString)
   End Sub

   ' Listing 21-32
   Public Sub SetUserPermissions()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()
      Dim aclUserMan As New AccessControlList()

      ' Give UserMan user full control over 
      ' private UserMan queue
      queUserMan.SetPermissions("UserMan", _
         MessageQueueAccessRights.FullControl)
      ' Give UserMan user full control over private 
      ' UserMan queue
      queUserMan.SetPermissions(New _
         MessageQueueAccessControlEntry(New Trustee("UserMan"), _
         MessageQueueAccessRights.FullControl))
      ' Deny UserMan deleting the private UserMan queue
      queUserMan.SetPermissions("UserMan", _
         MessageQueueAccessRights.DeleteQueue, _
         AccessControlEntryType.Deny)
      ' Deny UserMan all access rights on the private UserMan queue
      aclUserMan.Add(New AccessControlEntry(New _
         Trustee("UserMan"), _
         GenericAccessRights.All, StandardAccessRights.All, _
         AccessControlEntryType.Deny))
      queUserMan.SetPermissions(aclUserMan)
   End Sub

   ' Listing 21-33
   Public Sub SendSimpleMessageMSMQ30()
      Dim msg30 As New MSMQMessageClass()
      Dim qud30 As New MSMQDestinationClass()

      ' Bind to message queue by setting the
      ' format name
      qud30.FormatName = "DIRECT=TCP:10.8.1.16\PRIVATE$\userman"
      ' Prepare and send message
      msg30.Body = "Test Body"
      msg30.Send(qud30)
   End Sub

   ' Listing 21-34
   Public Sub SendMessageViaHTTPMSMQ30()
      Dim msg30 As New MSMQMessageClass()
      Dim qud30 As New MSMQDestinationClass()

      ' Bind to message queue by setting the
      ' format name
      qud30.FormatName = "DIRECT=HTTP://10.8.1.16/MSMQ/PRIVATE$/userman"
      ' Prepare and send message
      msg30.Body = "Test Body"
      msg30.Send(qud30)
   End Sub

   ' Listing 21-35
   Public Sub SendMessageToMultipleDestUsingFormatNameMSMQ30()
      Dim msg30 As New MSMQMessageClass()
      Dim qud30 As New MSMQDestinationClass()

      ' Bind to destination queues by specifying the
      ' format names
      qud30.FormatName = "DIRECT=HTTP://10.8.1.16/MSMQ/PRIVATE$/userman," & _
      "DIRECT=TCP:10.8.1.16\PRIVATE$\userman1," & _
      "DIRECT=OS:USERMANPC\userman"
      ' Prepare and send message
      msg30.Body = "Test Body"
      msg30.Send(qud30)
   End Sub

   ' Listing 21-36
   Public Sub SendMessageToMultipleDestUsingMulticastMSMQ30()
      Dim msg30 As New MSMQMessageClass()
      Dim qud30 As New MSMQDestinationClass()
      Dim qui30 As New MSMQQueueInfo()

      ' Set up queues with multicast address
      qui30.PathName = ".\PRIVATE$\userman"
      qui30.MulticastAddress = "224.0.0.255:0"
      qui30.Update()
      qui30.PathName = ".\PRIVATE$\userman1"
      qui30.MulticastAddress = "224.0.0.255:0"
      qui30.Update()
      qui30.PathName = "USERMANPC\userman"
      qui30.MulticastAddress = "224.0.0.255:0"
      qui30.Update()

      ' Bind to destination queues by specifying the
      ' format names
      qud30.FormatName = "MULTICAST=224.0.0.255:0"
      ' Prepare and send message
      msg30.Body = "Test Body"
      msg30.Send(qud30)
   End Sub

   ' Listing 21-38
   Public Sub SendTriggerMessage()
      Dim queUserMan As New MessageQueue(".\Private$\UserMan")
      Dim msgUserMan As New Message()

      ' Set up the formatter
      queUserMan.Formatter = New XmlMessageFormatter( _
         New Type() {GetType(String)})

      ' Make sure the trigger acts on this message
      msgUserMan.Body = "DeleteUser"
      ' This is the invocation parameter
      msgUserMan.Label = "Thomsen"
      ' Send message to queue
      queUserMan.Send(msgUserMan)
   End Sub
End Module