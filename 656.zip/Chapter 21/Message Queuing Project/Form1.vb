Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnMisc As System.Windows.Forms.Button
   Friend WithEvents btnJournaling As System.Windows.Forms.Button
   Friend WithEvents btnCreatePrivateQueue As System.Windows.Forms.Button
   Friend WithEvents btnTransactions As System.Windows.Forms.Button
   Friend WithEvents btnCreateTransactional As System.Windows.Forms.Button
   Friend WithEvents btnRemove As System.Windows.Forms.Button
   Friend WithEvents btnBrowse As System.Windows.Forms.Button
   Friend WithEvents btnExists As System.Windows.Forms.Button
   Friend WithEvents btnRetrieve As System.Windows.Forms.Button
   Friend WithEvents btnSend As System.Windows.Forms.Button
   Friend WithEvents btnMSMQ30 As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnMisc = New System.Windows.Forms.Button()
      Me.btnJournaling = New System.Windows.Forms.Button()
      Me.btnCreatePrivateQueue = New System.Windows.Forms.Button()
      Me.btnTransactions = New System.Windows.Forms.Button()
      Me.btnCreateTransactional = New System.Windows.Forms.Button()
      Me.btnRemove = New System.Windows.Forms.Button()
      Me.btnBrowse = New System.Windows.Forms.Button()
      Me.btnExists = New System.Windows.Forms.Button()
      Me.btnRetrieve = New System.Windows.Forms.Button()
      Me.btnSend = New System.Windows.Forms.Button()
      Me.btnMSMQ30 = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnMisc
      '
      Me.btnMisc.Location = New System.Drawing.Point(118, 14)
      Me.btnMisc.Name = "btnMisc"
      Me.btnMisc.TabIndex = 8
      Me.btnMisc.Text = "Misc."
      '
      'btnJournaling
      '
      Me.btnJournaling.Location = New System.Drawing.Point(14, 62)
      Me.btnJournaling.Name = "btnJournaling"
      Me.btnJournaling.Size = New System.Drawing.Size(80, 23)
      Me.btnJournaling.TabIndex = 7
      Me.btnJournaling.Text = "Journaling"
      '
      'btnCreatePrivateQueue
      '
      Me.btnCreatePrivateQueue.Location = New System.Drawing.Point(118, 62)
      Me.btnCreatePrivateQueue.Name = "btnCreatePrivateQueue"
      Me.btnCreatePrivateQueue.Size = New System.Drawing.Size(168, 23)
      Me.btnCreatePrivateQueue.TabIndex = 9
      Me.btnCreatePrivateQueue.Text = "Create Private Queue"
      '
      'btnTransactions
      '
      Me.btnTransactions.Location = New System.Drawing.Point(14, 94)
      Me.btnTransactions.Name = "btnTransactions"
      Me.btnTransactions.Size = New System.Drawing.Size(80, 23)
      Me.btnTransactions.TabIndex = 11
      Me.btnTransactions.Text = "Transactions"
      '
      'btnCreateTransactional
      '
      Me.btnCreateTransactional.Location = New System.Drawing.Point(118, 94)
      Me.btnCreateTransactional.Name = "btnCreateTransactional"
      Me.btnCreateTransactional.Size = New System.Drawing.Size(168, 23)
      Me.btnCreateTransactional.TabIndex = 10
      Me.btnCreateTransactional.Text = "Create Transactional"
      '
      'btnRemove
      '
      Me.btnRemove.Location = New System.Drawing.Point(214, 166)
      Me.btnRemove.Name = "btnRemove"
      Me.btnRemove.TabIndex = 6
      Me.btnRemove.Text = "Remove"
      '
      'btnBrowse
      '
      Me.btnBrowse.Location = New System.Drawing.Point(214, 134)
      Me.btnBrowse.Name = "btnBrowse"
      Me.btnBrowse.TabIndex = 2
      Me.btnBrowse.Text = "Browse"
      '
      'btnExists
      '
      Me.btnExists.Location = New System.Drawing.Point(118, 134)
      Me.btnExists.Name = "btnExists"
      Me.btnExists.TabIndex = 1
      Me.btnExists.Text = "Exists"
      '
      'btnRetrieve
      '
      Me.btnRetrieve.Location = New System.Drawing.Point(14, 166)
      Me.btnRetrieve.Name = "btnRetrieve"
      Me.btnRetrieve.TabIndex = 5
      Me.btnRetrieve.Text = "Retrieve"
      '
      'btnSend
      '
      Me.btnSend.Location = New System.Drawing.Point(14, 134)
      Me.btnSend.Name = "btnSend"
      Me.btnSend.TabIndex = 4
      Me.btnSend.Text = "Send"
      '
      'btnMSMQ30
      '
      Me.btnMSMQ30.Location = New System.Drawing.Point(118, 166)
      Me.btnMSMQ30.Name = "btnMSMQ30"
      Me.btnMSMQ30.TabIndex = 12
      Me.btnMSMQ30.Text = "MSMQ 3.0"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(304, 209)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnMSMQ30, Me.btnMisc, Me.btnJournaling, Me.btnCreatePrivateQueue, Me.btnTransactions, Me.btnCreateTransactional, Me.btnRemove, Me.btnBrowse, Me.btnExists, Me.btnRetrieve, Me.btnSend})
      Me.Name = "Form1"
      Me.Text = "Message Queuing Project"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
      SendSimpleMessage()
      'SendDifferentMessages()
      'SendPriorityMessages()
      'SendDeadLetterMessage()
      'SendTriggerMessage()
   End Sub

   Private Sub btnRetrieve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetrieve.Click
      'RetrieveSimpleMessage()
      'RetrieveMessage()
      'RetrieveDifferentMessages()
      'RetrieveMessageById()
      'RetrieveMessageByIdSafe("c95e6822-1b48-43da-b46d-1bf3f198636d\4108")
      'RetrieveMessagesAsync()
      'RetrievePriorityMessage()
      RetrieveMessageFromDeadLetterQueue()
   End Sub

   Private Sub btnExists_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExists.Click
      MsgBox(CheckQueueExists(".\Private$\UserMan"))
   End Sub

   Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
      'BrowsePrivateQueues()
      'BrowsePublicQueuesMachineWide()
      'BrowsePublicQueuesNetworkWide()
      'BrowsePublicQueuesByCategoryNetworkWide()
      BrowsePublicQueuesByLabelNetworkWide()
   End Sub

   Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
      'RemoveMessageQueue(".\userman")
      RemoveMessageQueueSafely(".\userman")
   End Sub

   Private Sub btnCreateTransactional_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateTransactional.Click
      CreateTransactionalPrivateQueue()
   End Sub

   Private Sub btnTransactions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTransactions.Click
      UseMQTransactions()
   End Sub

   Private Sub btnCreatePrivateQueue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreatePrivateQueue.Click
      'CreatePrivateQueueWithName()
      CreatePrivateQueue()
   End Sub

   Private Sub btnJournaling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnJournaling.Click
      EnableMessageJournaling()
   End Sub

   Private Sub btnMisc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMisc.Click
      'CreatePublicQueue()
      'ChangeQueueLabel()
      'RetrieveQueueId()
      'BindToExistingQueue()
      'BindToExistingQueueUsingFormat()
      'BindToExistingQueueUsingLabel()
      'PeekMessage()
      'PeekMessagesAsync()
      'ClearMessageQueue()
      'EnableMQJournaling()
      'RetrieveMessageFromQueueJournal()
      'EnableQueueAuthentication()
      'RejectNonauthenticatedMessage()
      'PlaceNonauthenticatedMessageInAdminQueue()
      'AcceptAuthenticatedMessage()
      'EnableRequireBodyEncryption()
      'SendAndReceiveEncryptedMessage()
      SetUserPermissions()
   End Sub

   Private Sub btnMSMQ30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMSMQ30.Click
      'SendSimpleMessageMSMQ30()
      'SendMessageViaHTTPMSMQ30()
      'SendMessageToMultipleDestUsingFormatNameMSMQ30()
      SendMessageToMultipleDestUsingMulticastMSMQ30()
   End Sub
End Class