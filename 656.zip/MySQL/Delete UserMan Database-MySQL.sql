-- Drop an existing UserMan database
DROP DATABASE IF EXISTS UserMan;
