-- Drop an existing UserMan database
DROP DATABASE IF EXISTS UserMan;

-- Create new UserMan database
CREATE DATABASE UserMan;

-- Switch to the new UserMan database
USE UserMan

-- Create new tblUserRights table 
CREATE TABLE tblUserRights (
	UserId INTEGER NOT NULL,
	RightsId INTEGER NOT NULL, CONSTRAINT PK_tblUserRights PRIMARY KEY (UserId, RightsId));

-- Create new tblUser table 
CREATE TABLE tblUser (
	Id INTEGER NOT NULL AUTO_INCREMENT,
	ADName VARCHAR(100) NULL,
	ADSID VARCHAR(50) NULL,
	FirstName VARCHAR(50) NULL,
	LastName VARCHAR(50) NULL,
	LoginName VARCHAR(50) NOT NULL,
	Password VARCHAR(50) DEFAULT 'password' NOT NULL, CONSTRAINT PK_tblUser PRIMARY KEY (Id));

-- Create new tblRights table 
CREATE TABLE tblRights (
	Id INTEGER NOT NULL AUTO_INCREMENT,
	Name VARCHAR(50) NOT NULL,
	Description VARCHAR(255) NOT NULL, CONSTRAINT PK_tblRights PRIMARY KEY (Id)); 

# Create new tblLog table
CREATE TABLE tblLog (
	Id INTEGER NOT NULL AUTO_INCREMENT,
	Logged DATETIME NOT NULL,
	Description VARCHAR(255) NOT NULL,
	UserId INTEGER NOT NULL, CONSTRAINT PK_tblLog PRIMARY KEY (Id));

# Add the remaining keys, constraints and indexes for the tblUser table 
ALTER TABLE tblUser ADD CONSTRAINT IX_tblUser UNIQUE (LoginName);


# Add foreign key constraints to tblUserRights table 
ALTER TABLE tblUserRights
	ADD CONSTRAINT FK_tblUserRights_tblRights FOREIGN KEY (RightsId)
	 REFERENCES tblRights (Id);
ALTER TABLE tblUserRights
	ADD CONSTRAINT FK_tblUserRights_tblUser FOREIGN KEY (UserId)
	 REFERENCES tblUser (Id);

# Add foreign key constraints to tblLog table 
ALTER TABLE tblLog
	ADD CONSTRAINT FK_tblLog_tblUser FOREIGN KEY (UserId)
	 REFERENCES tblUser (Id);


# Insert example data into tables 
INSERT INTO tblUser (FirstName, LastName, LoginName, Password)
	VALUES ('John', 'Doe', 'UserMan', 'userman');

INSERT INTO tblUser (LoginName, Password)
	VALUES ('User1', 'password');

INSERT INTO tblUser (LoginName, Password)
	VALUES ('User2', 'password');

INSERT INTO tblUser (LoginName, Password)
	VALUES ('User3', 'password');

INSERT INTO tblUser (LoginName, Password)
	VALUES ('User99', 'password');

INSERT INTO tblRights (Name, Description)
	VALUES ('AddUser', 'Gives the user the right to add users to the database');

INSERT INTO tblRights (Name, Description)
	VALUES ('DeleteUser', 'Gives the user the right to delete users from the database');

INSERT INTO tblRights (Name, Description)
	VALUES ('ClearLog', 'Gives the user the right to clear the log');

INSERT INTO tblUserRights (UserId, RightsId)
	VALUES (1, 1);

INSERT INTO tblUserRights (UserId, RightsId)
	VALUES (1, 2);

INSERT INTO tblUserRights (UserId, RightsId)
	VALUES (1, 3);

# Add the UserMan user and give GRANT options to UserMan database
GRANT ALL PRIVILEGES ON UserMan TO UserMan@localhost
           IDENTIFIED BY 'userman' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON UserMan TO UserMan@'%'
           IDENTIFIED BY 'userman' WITH GRANT OPTION;
