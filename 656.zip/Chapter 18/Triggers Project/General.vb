Option Strict On

Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OleDb

#Const Oracle = 0
#Const SQLSERVER = 1
#Const DB2 = 0
' Make sure you enable the correct data source, by setting it to 1

Module General
#If SQLSERVER Then
   ' This connection string os for connecting to SQL Server
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"
#ElseIf ORACLE Then
   ' This connection string os for connecting to Oracle
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN"
#ElseIf DB2 Then
   ' This connection string os for connecting to DB2
   ' You must change the Data Source value
   Private Const PR_STR_CONNECTION_STRING As String = _
      "Provider=IBMDADB2;Password=userman;User ID=USERMAN;Data Source=USERMAN;"
#End If

   ' Listing 18-3
   Public Sub TestUpdateTrigger()
      Const STR_SQL_USER_SELECT As String = _
         "SELECT * FROM tblUser"

      Dim dstUser As DataSet
#If SQLSERVER Then
      Const STR_SQL_USER_DELETE As String = _
         "DELETE FROM tblUser WHERE Id=@Id"
      Const STR_SQL_USER_INSERT As String = _
         "INSERT INTO tblUser(FirstName, LastName, LoginName) " & _
         "VALUES(@FirstName, @LastName, @LoginName)"
      Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser " & _
         "SET FirstName=@FirstName, LastName=@LastName, LoginName=@LoginName " & _
         "WHERE Id=@Id"

      Dim cnnUserMan As SqlConnection
      Dim cmmUser As SqlCommand
      Dim dadUser As SqlDataAdapter

      Dim cmmUserSelect As SqlCommand
      Dim cmmUserDelete As SqlCommand
      Dim cmmUserInsert As SqlCommand
      Dim cmmUserUpdate As SqlCommand

      Dim prmSQLDelete, prmSQLUpdate As SqlParameter

      ' Instantiate and open the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New SqlCommand("SELECT * FROM tblUser", cnnUserMan)
      ' Instantiate the commands
      cmmUserSelect = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
      cmmUserDelete = New SqlCommand(STR_SQL_USER_DELETE, cnnUserMan)
      cmmUserInsert = New SqlCommand(STR_SQL_USER_INSERT, cnnUserMan)
      cmmUserUpdate = New SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan)
      ' Instantiate command and data set
      cmmUser = New SqlCommand(STR_SQL_USER_SELECT, cnnUserMan)
      dstUser = New DataSet()

      dadUser = New SqlDataAdapter()
      dadUser.SelectCommand = cmmUserSelect
      dadUser.InsertCommand = cmmUserInsert
      dadUser.DeleteCommand = cmmUserDelete
      dadUser.UpdateCommand = cmmUserUpdate

      ' Add parameters
      prmSQLDelete = dadUser.DeleteCommand.Parameters.Add("@Id", _
         SqlDbType.Int, 0, "Id")
      prmSQLDelete.Direction = ParameterDirection.Input
      prmSQLDelete.SourceVersion = DataRowVersion.Original

      cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, _
         "FirstName")
      cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, _
         "LastName")
      cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, _
         "LoginName")
      prmSQLUpdate = dadUser.UpdateCommand.Parameters.Add("@Id", _
         SqlDbType.Int, 0, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original

      cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, _
         "FirstName")
      cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, _
         "LastName")
      cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, _
         "LoginName")
#Else
      Const STR_SQL_USER_DELETE As String = _
         "DELETE FROM tblUser WHERE Id=?"
      Const STR_SQL_USER_INSERT As String = _
         "INSERT INTO tblUser(FirstName, LastName, LoginName) " & _
         "VALUES(?, ?, ?)"
      Const STR_SQL_USER_UPDATE As String = "UPDATE tblUser " & _
         "SET FirstName=?, LastName=?, LoginName=? WHERE Id=?"

      Dim cnnUserMan As OleDbConnection
      Dim cmmUser As OleDbCommand
      Dim dadUser As OleDbDataAdapter

      Dim cmmUserSelect As OleDbCommand
      Dim cmmUserDelete As OleDbCommand
      Dim cmmUserInsert As OleDbCommand
      Dim cmmUserUpdate As OleDbCommand

      Dim prmSQLDelete, prmSQLUpdate As OleDbParameter

      ' Instantiate and open the connection
      cnnUserMan = New OleDbConnection(PR_STR_CONNECTION_STRING)
      cnnUserMan.Open()

      ' Instantiate and initialize command
      cmmUser = New OleDbCommand("SELECT * FROM tblUser", cnnUserMan)
      ' Instantiate the commands
      cmmUserSelect = New OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan)
      cmmUserDelete = New OleDbCommand(STR_SQL_USER_DELETE, cnnUserMan)
      cmmUserInsert = New OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan)
      cmmUserUpdate = New OleDbCommand(STR_SQL_USER_UPDATE, cnnUserMan)
      ' Instantiate command and data set
      cmmUser = New OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan)
      dstUser = New DataSet()

      dadUser = New OleDbDataAdapter()
      dadUser.SelectCommand = cmmUserSelect
      dadUser.InsertCommand = cmmUserInsert
      dadUser.DeleteCommand = cmmUserDelete
      dadUser.UpdateCommand = cmmUserUpdate

      ' Add parameters
      prmSQLDelete = dadUser.DeleteCommand.Parameters.Add("@Id", _
         OleDbType.Integer, 0, "Id")
      prmSQLDelete.Direction = ParameterDirection.Input
      prmSQLDelete.SourceVersion = DataRowVersion.Original

      cmmUserUpdate.Parameters.Add("@FirstName", OleDbType.VarChar, 50, _
         "FirstName")
      cmmUserUpdate.Parameters.Add("@LastName", OleDbType.VarChar, 50, _
         "LastName")
      cmmUserUpdate.Parameters.Add("@LoginName", OleDbType.VarChar, 50, _
         "LoginName")
      prmSQLUpdate = dadUser.UpdateCommand.Parameters.Add("@Id", _
         OleDbType.Integer, 0, "Id")
      prmSQLUpdate.Direction = ParameterDirection.Input
      prmSQLUpdate.SourceVersion = DataRowVersion.Original

      cmmUserInsert.Parameters.Add("@FirstName", OleDbType.VarChar, 50, _
         "FirstName")
      cmmUserInsert.Parameters.Add("@LastName", OleDbType.VarChar, 50, _
         "LastName")
      cmmUserInsert.Parameters.Add("@LoginName", OleDbType.VarChar, 50, _
         "LoginName")
#End If

      ' Populate the data set from the view
      dadUser.Fill(dstUser, "tblUser")

      ' Change the name of user in the second row
      dstUser.Tables("tblUser").Rows(2)("LastName") = "Thomsen"
      dstUser.Tables("tblUser").Rows(2)("FirstName") = DBNull.Value

      Try
         ' Propagate changes back to the data source
         dadUser.Update(dstUser, "tblUser")
      Catch objE As Exception
         MsgBox(objE.Message)
      End Try
   End Sub
End Module