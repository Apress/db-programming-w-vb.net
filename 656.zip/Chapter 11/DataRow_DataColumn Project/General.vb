Option Strict On

Imports System.Data.SqlClient
Imports System.Xml
Imports System.IO

Module General
   Private Const PR_STR_CONNECTION_STRING As String = "Data Source=10.8.1.11;" & _
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan"

   Public Sub InstantiateDataRow()
      Dim dtbUser As New DataTable()
      Dim drwUser As DataRow

      drwUser = dtbUser.NewRow()
   End Sub

   ' Listing 11-1
   Public Sub ManipulateRowState()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As New DataTable("tblUser")
      Dim drwNewRow, drwExisting As DataRow

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)

      ' Fill the DataTable
      dadUser.Fill(dtbUser)

      ' Set RowState to Detached
      drwNewRow = dtbUser.NewRow()
      MsgBox(drwNewRow.RowState.ToString)
      ' No changes to the row state when changing column values 
      ' if row state is Detached
      drwNewRow(3) = "FirstName"
      MsgBox(drwNewRow.RowState.ToString)

      ' Row state is Unchanged, because no changes since
      ' DataTable was loaded or populated
      drwExisting = dtbUser.Rows(1)
      MsgBox(drwExisting.RowState.ToString)
      ' Set row state to modified
      drwExisting(3) = "FirstName"
      MsgBox(drwExisting.RowState.ToString)
      ' Reset row state
      drwExisting.AcceptChanges()
      MsgBox(drwExisting.RowState.ToString)
      ' Change row state to Deleted
      drwExisting.Delete()
      MsgBox(drwExisting.RowState.ToString)
      ' Reset row state
      drwExisting.RejectChanges()
      MsgBox(drwExisting.RowState.ToString)
      ' Change row state to Deleted
      drwExisting.Delete()
      ' Remove row from collection
      drwExisting.AcceptChanges()
      MsgBox(drwExisting.RowState.ToString)
   End Sub

   ' Listing 11-2
   Public Sub CheckAccessibleRowVersions()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As New DataTable("tblUser")
      Dim drwExisting As DataRow

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)

      ' Fill the DataTable
      dadUser.Fill(dtbUser)

      ' Reference row in table
      drwExisting = dtbUser.Rows(1)
      ' Display accesible row versions
      MsgBox("Current Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Current).ToString & vbCrLf & _
         "Default Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Default).ToString & vbCrLf & _
         "Original Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Original).ToString & vbCrLf & _
         "Proposed Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Proposed).ToString, _
         MsgBoxStyle.Information, "Accessible Row Versions - No Edit Mode")
      ' Enter edit mode
      drwExisting.BeginEdit()
      ' Display accesible row versions
      MsgBox("Current Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Current).ToString & vbCrLf & _
         "Default Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Default).ToString & vbCrLf & _
         "Original Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Original).ToString & vbCrLf & _
         "Proposed Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Proposed).ToString, _
         MsgBoxStyle.Information, "Accessible Row Versions - In Edit Mode")
      ' End edit mode
      drwExisting.CancelEdit()
      drwExisting.EndEdit()
      ' Display accesible row versions
      MsgBox("Current Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Current).ToString & vbCrLf & _
         "Default Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Default).ToString & vbCrLf & _
         "Original Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Original).ToString & vbCrLf & _
         "Proposed Row version = " & drwExisting.HasVersion( _
         DataRowVersion.Proposed).ToString, _
         MsgBoxStyle.Information, "Accessible Row Versions - After Edit Mode")
   End Sub

   ' Listing 11-3
   Public Sub WorkWithDataRowErrors()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As New DataTable("tblUser")
      Dim drwExisting As DataRow

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)

      ' Fill the DataTable
      dadUser.Fill(dtbUser)

      ' Reference row in table
      drwExisting = dtbUser.Rows(1)
      ' Indicate a row error
      drwExisting.RowError = "This row is in error"
      MsgBox(drwExisting.HasErrors)
      ' Reset the row error
      drwExisting.RowError = ""
      MsgBox(drwExisting.HasErrors)
      ' Indicate a column error
      drwExisting.SetColumnError(0, "This column is in error")
      MsgBox(drwExisting.HasErrors)
      ' Reset the column error
      drwExisting.SetColumnError(0, "")
      MsgBox(drwExisting.HasErrors)

      ' Set row error
      drwExisting.RowError = "This row is in error."
      ' Detect row error
      If drwExisting.HasErrors Then ' Fix the error(s)
         ' Retrieve columns in error
         Dim arrdtcError() As DataColumn = drwExisting.GetColumnsInError()
         Dim dtcError As DataColumn
         ' Loop through error column, if any
         For Each dtcError In arrdtcError
            ' Do what's needed to fix column error
            ' ...
         Next
         ' Check for a general row error
         Select Case drwExisting.RowError
            Case ""
               ' No general row error, so do nothing
            Case "This row is in error."
               ' Do what's needed to fix error
               ' ...
            Case Else
               ' Do what's needed to fix error
               ' ...
         End Select

         ' Clear the errors
         drwExisting.ClearErrors()
      End If
   End Sub

   ' Listing 11-4
   Public Sub InstantiateDataColumn()
      Dim dtcDefaultValues As New DataColumn()
      Dim dtcColumnName As New DataColumn("ColumnName")
      Dim dtcColumnNameAndDataType As New DataColumn("ColumnName", _
         Type.GetType("System.String"))
      Dim dtcColumnNameAndDataTypeAndExpression As New DataColumn("ColumnName", _
         Type.GetType("System.String"), "ColumnName + 'Extra Text'")
      Dim dtcColumnNameAndDataTypeAndExpressionAndMappingType As New _
         DataColumn("ColumnName", Type.GetType("System.Int32"), _
         "ColumName + 10", MappingType.Attribute)
   End Sub

   ' Listing 11-5
   Public Sub WorkWithAutoIncrementColumns()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As New DataTable("tblUser")
      Dim dclId As DataColumn

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)

      ' Fill the DataTable Schema
      ' (this will set the AutoIncrement, AllowDBNull, and ReadOnly 
      ' properties)
      dadUser.FillSchema(dtbUser, SchemaType.Source)
      ' Fill the DataTable 
      ' (this won't set the AutoIncrement, AllowDBNull, and ReadOnly 
      ' properties)
      dadUser.Fill(dtbUser)

      ' Reference column in table
      dclId = dtbUser.Columns("Id")
      ' Display AutoIncrement properties
      MsgBox("AutoIncrement = " & dclId.AutoIncrement.ToString & vbCrLf & _
         "AutoIncrementSeed = " & dclId.AutoIncrementSeed.ToString & vbCrLf & _
         "AutoIncrementStep = " & dclId.AutoIncrementStep.ToString, _
         MsgBoxStyle.Information, "AutoIncrement DataColumn")
      ' Set autoincrement properties
      ' (not needed when FillSchema is used)
      dclId.AutoIncrement = True
      dclId.AutoIncrementSeed = 1
      dclId.AutoIncrementStep = 1
      ' Display AutoIncrement properties
      MsgBox("AutoIncrement = " & dclId.AutoIncrement.ToString & vbCrLf & _
         "AutoIncrementSeed = " & dclId.AutoIncrementSeed.ToString & vbCrLf & _
         "AutoIncrementStep = " & dclId.AutoIncrementStep.ToString, _
         MsgBoxStyle.Information, "AutoIncrement DataColumn")
      ' Set other related properties
      ' (only needed when you create the column yourself)
      dclId.AllowDBNull = False
      dclId.ReadOnly = True
   End Sub

   ' Listing 11-6
   Public Sub WorkWithNullValueColumns()
      Dim cnnUserMan As SqlConnection
      Dim dadUser As SqlDataAdapter
      Dim dtbUser As New DataTable("tblUser")
      Dim drwUser As DataRow
      Dim dclId As DataColumn

      ' Instantiate the connection
      cnnUserMan = New SqlConnection(PR_STR_CONNECTION_STRING)
      ' Instantiate and initialize the data adapter
      dadUser = New SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan)

      ' Fill the DataTable Schema
      ' (this will set the AllowDBNull property)
      dadUser.FillSchema(dtbUser, SchemaType.Source)
      ' Fill the DataTable 
      ' (this won't set the AllowDBNull property)
      dadUser.Fill(dtbUser)

      ' Reference row in table
      drwUser = dtbUser.Rows(1)

      ' Reference Id column in table
      dclId = dtbUser.Columns("Id")
      ' Disallow null values in Id column
      ' (only needed when you create the column yourself,
      ' or you don't use FillSchema)
      dclId.AllowDBNull = True

      ' Check if the LastName column holds a null value
      If drwUser.IsNull("LastName") Then
         MsgBox("DataColumn value is Null")
      Else
         MsgBox(drwUser("LastName"))
      End If

      ' This will throw an exception if a null value
      ' is stored in the LastName column
      MsgBox(drwUser("LastName"))
      ' Make sure a null value in a string column
      ' doesn't throw an exception
      MsgBox(drwUser("LastName").ToString)
   End Sub
End Module