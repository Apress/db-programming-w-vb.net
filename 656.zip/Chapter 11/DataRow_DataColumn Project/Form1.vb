Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnInstantiateDataRowObject As System.Windows.Forms.Button
   Friend WithEvents btnManipulateRowState As System.Windows.Forms.Button
   Friend WithEvents btnCheckingAccessibleRowVersions As System.Windows.Forms.Button
   Friend WithEvents btnWorkWithDataRowErrors As System.Windows.Forms.Button
   Friend WithEvents Button1 As System.Windows.Forms.Button
   Friend WithEvents Button2 As System.Windows.Forms.Button
   Friend WithEvents btnWorkWithNullValueDataColumnObjects As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnInstantiateDataRowObject = New System.Windows.Forms.Button()
      Me.btnManipulateRowState = New System.Windows.Forms.Button()
      Me.btnCheckingAccessibleRowVersions = New System.Windows.Forms.Button()
      Me.btnWorkWithDataRowErrors = New System.Windows.Forms.Button()
      Me.Button1 = New System.Windows.Forms.Button()
      Me.Button2 = New System.Windows.Forms.Button()
      Me.btnWorkWithNullValueDataColumnObjects = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'btnInstantiateDataRowObject
      '
      Me.btnInstantiateDataRowObject.Location = New System.Drawing.Point(12, 18)
      Me.btnInstantiateDataRowObject.Name = "btnInstantiateDataRowObject"
      Me.btnInstantiateDataRowObject.Size = New System.Drawing.Size(272, 23)
      Me.btnInstantiateDataRowObject.TabIndex = 0
      Me.btnInstantiateDataRowObject.Text = "Instantiate DataRow Object"
      '
      'btnManipulateRowState
      '
      Me.btnManipulateRowState.Location = New System.Drawing.Point(11, 46)
      Me.btnManipulateRowState.Name = "btnManipulateRowState"
      Me.btnManipulateRowState.Size = New System.Drawing.Size(272, 23)
      Me.btnManipulateRowState.TabIndex = 1
      Me.btnManipulateRowState.Text = "Manipulate RowState"
      '
      'btnCheckingAccessibleRowVersions
      '
      Me.btnCheckingAccessibleRowVersions.Location = New System.Drawing.Point(11, 74)
      Me.btnCheckingAccessibleRowVersions.Name = "btnCheckingAccessibleRowVersions"
      Me.btnCheckingAccessibleRowVersions.Size = New System.Drawing.Size(272, 23)
      Me.btnCheckingAccessibleRowVersions.TabIndex = 2
      Me.btnCheckingAccessibleRowVersions.Text = "Checking Accessible Row Versions"
      '
      'btnWorkWithDataRowErrors
      '
      Me.btnWorkWithDataRowErrors.Location = New System.Drawing.Point(11, 102)
      Me.btnWorkWithDataRowErrors.Name = "btnWorkWithDataRowErrors"
      Me.btnWorkWithDataRowErrors.Size = New System.Drawing.Size(272, 23)
      Me.btnWorkWithDataRowErrors.TabIndex = 4
      Me.btnWorkWithDataRowErrors.Text = "Work with DataRow Errors"
      '
      'Button1
      '
      Me.Button1.Location = New System.Drawing.Point(11, 130)
      Me.Button1.Name = "Button1"
      Me.Button1.Size = New System.Drawing.Size(272, 23)
      Me.Button1.TabIndex = 5
      Me.Button1.Text = "Instantiate DataColumn Object"
      '
      'Button2
      '
      Me.Button2.Location = New System.Drawing.Point(11, 158)
      Me.Button2.Name = "Button2"
      Me.Button2.Size = New System.Drawing.Size(272, 23)
      Me.Button2.TabIndex = 6
      Me.Button2.Text = "Work with AutoIncrement DataColumn Objects"
      '
      'btnWorkWithNullValueDataColumnObjects
      '
      Me.btnWorkWithNullValueDataColumnObjects.Location = New System.Drawing.Point(11, 186)
      Me.btnWorkWithNullValueDataColumnObjects.Name = "btnWorkWithNullValueDataColumnObjects"
      Me.btnWorkWithNullValueDataColumnObjects.Size = New System.Drawing.Size(272, 23)
      Me.btnWorkWithNullValueDataColumnObjects.TabIndex = 7
      Me.btnWorkWithNullValueDataColumnObjects.Text = "Work with Null Value DataColumn Objects"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(294, 256)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnWorkWithNullValueDataColumnObjects, Me.Button2, Me.Button1, Me.btnWorkWithDataRowErrors, Me.btnCheckingAccessibleRowVersions, Me.btnManipulateRowState, Me.btnInstantiateDataRowObject})
      Me.Name = "Form1"
      Me.Text = "DataRow_DataColumn Project"
      Me.ResumeLayout(False)

   End Sub

#End Region


   Private Sub btnInstantiateDataRowObject_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstantiateDataRowObject.Click
      InstantiateDataRow()
   End Sub

   Private Sub btnManipulateRowState_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManipulateRowState.Click
      ManipulateRowState()
   End Sub

   Private Sub btnCheckingRowVersion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCheckingAccessibleRowVersions.Click
      CheckAccessibleRowVersions()
   End Sub

   Private Sub btnWorkWithDataRowErrors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWorkWithDataRowErrors.Click
      WorkWithDataRowErrors()
   End Sub

   Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
      InstantiateDataColumn()
   End Sub

   Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
      WorkWithAutoIncrementColumns()
   End Sub

   Private Sub btnWorkWithNullValueDataColumnObjects_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWorkWithNullValueDataColumnObjects.Click
      WorkWithNullValueColumns()
   End Sub
End Class